#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 505
using namespace std;
int dp[N][100005],d,n1,n2,c1,c2,tc,t[N],sum;
int main()
{
	freopen("toys.in","r",stdin);
	freopen("toys.out","w",stdout);
	scanf("%d%d%d%d%d",&d,&n1,&n2,&c1,&c2,&tc);
	for (int i=1;i<=d;i++)
		scanf("%d",&t[i]),sum+=t[i];
	printf("%d",sum*tc);
	return 0;
}
