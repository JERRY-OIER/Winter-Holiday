#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 100005
using namespace std;
int n,w[N],l=0,r,mid,ans,sum[N],wzh;
int check(int x)
{
	int tot=0,height=1,tmp=0,i=n;
	for (;i>n-x;i--)
		tot+=w[i];
	if (n-x+1<ans) return -1;
	while (i>0)
	{
		while (tmp+w[i]<tot && i>0) 
			tmp+=w[i],i--;
		if (i==0 && tmp<tot) return -1;
		tmp+=w[i--];
		height++;tot=tmp;tmp=0;
		if (tot>sum[i]) return height;
	}
	return height;
}
int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	scanf("%d",&n);
	w[0]=23333333;
	for (int i=1;i<=n;i++)
		scanf("%d",&w[i]),sum[i]=sum[i-1]+w[i],wzh+=(w[i]<w[i-1]);
	if (wzh==n)
		printf("%d\n",n);
	else
	{
		if (n>=20000)
			ans=check(1);
		else
			for (int i=1;i<=n;i++)
				ans=max(ans,check(i));
		printf("%d\n",ans);
	}
	return 0;
}
