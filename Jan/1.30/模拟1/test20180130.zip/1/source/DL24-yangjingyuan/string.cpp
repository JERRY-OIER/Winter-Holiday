#include<cstdio>
#include<algorithm>
#include<cstring>
#define C 27
#define N 300005
using namespace std;
int n,tot=1,rank[C],vis[C],ans,cnt;
char s[N];
struct node
{
	int son[C],end;
	node()
	{memset(son,0,sizeof(son));}
}t[N];
void insert(char s[],int num)
{
	int now=1;
	int len=strlen(s+1);
	for (int i=1;i<=len;i++)
		if (t[now].son[s[i]-'a']==0)
			t[now].son[s[i]-'a']=++tot,now=tot;
		else now=t[now].son[s[i]-'a'];
	t[now].end=num;
}
int find(int x,int appear)
{
	int mxrk=233,tmp;
	if (t[x].end!=0) return ans++;
	for (int i=0;i<26;i++)
		if (t[x].son[i]!=0)
			if (vis[i]==0)
				vis[i]=1,rank[i]=appear+1,find(t[x].son[i],rank[i]),vis[i]=0,rank[i]=0;
			else if (vis[i]==1 && rank[i]<mxrk && rank[i]!=0)
				tmp=i,mxrk=rank[i];
	find(t[x].son[tmp],appear);			
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	printf("%d\n",n);
	for (int i=1;i<=n;i++)
		scanf("%s",s+1),puts(s+1);
	return 0;
}
/*
4
omm
mom
moo
ommnom
*/
