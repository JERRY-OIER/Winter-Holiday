#include <bits/stdc++.h>

using namespace std;
const int MAXN = 100000;

int W[MAXN + 1];

int main() {
#ifndef HAND_TEST
	freopen("stack.in", "r", stdin);
	freopen("stack.out", "w", stdout);
#endif
	int N;
	scanf("%d", &N);
	for (int i = 1; i <= N; i++) scanf("%d", &W[i]);
	int fw = W[N];
	int tw = 0;
	int tall = 1;
	for (int i = N - 1; i >= 1; i--) {
		if (tw < fw) tw += W[i];
		if (tw >= fw) {
			fw = tw;
			tw = 0;
			tall++;
		}
	}
	printf("%d\n", tall);
	return 0;
}
