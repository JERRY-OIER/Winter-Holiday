#include <bits/stdc++.h>

using namespace std;
const int MAXN = 30000;
const int MAXLEN = 300000;

char s[MAXN + 1][1000 + 1];

int top = 0;
int fi[26 + 1];
int ne[MAXN + 1];
int to[MAXN + 1];
bool arrive[26 + 1];

void add(int, int);

int main() {
#ifndef HAND_TEST
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
#endif
	int N;
	scanf("%d", &N);
	for (int i = 1; i <= N; i++) scanf("%s", s[i]);
	vector<int>ans;
	for (int i = 1; i <= N; i++) {
		top = 0;
		memset(fi, 0, sizeof(fi));
		memset(ne, 0, sizeof(ne));
		memset(to, 0, sizeof(to));
		bool ok = true;
		for (int j = 1; j <= N && ok; j++) {
			for (int k = 0; k < strlen(s[i]) && ok; k++) {
				if (k >= strlen(s[j])) ok = false;
				if (s[i][k] != s[j][k]) {
					add(s[i][k] - 'a' + 1, s[j][k] - 'a' + 1);
					break;
				}
			}
		}
		for (int j = 1; j <= 26 && ok; j++) {
			memset(arrive, false, sizeof(arrive));
			arrive[j] = true;
			queue<int>q;
			q.push(j);
			while (!q.empty() && ok) {
				int f = q.front();
				q.pop();
				for (int k = fi[f]; k && ok; k = ne[k]) {
					if (arrive[to[k]]) ok = false;
					q.push(to[k]);
				}
				for (int k = fi[j]; k && ok; k = ne[k]) arrive[to[k]] = true;
			}
		}
		if (!ok) continue;
		ans.push_back(i);
	}
	printf("%d\n", ans.size());
	for (int i = 0; i < ans.size(); i++) printf("%s\n", s[ans.at(i)]);
	return 0;
}

void add(int u, int v) {
	top++;
	ne[top] = fi[u];
	fi[u] = top;
	to[top] = v;
}
