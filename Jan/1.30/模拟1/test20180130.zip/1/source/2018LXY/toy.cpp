#include <bits/stdc++.h>

using namespace std;
const int MAXD = 100000;

int T[MAXD + 1];

int main() {
#ifndef HAND_TEST
	freopen("toy.in", "r", stdin);
	freopen("toy.out", "w", stdout);
#endif
	int D;
	int N1;
	int N2;
	int C1;
	int C2;
	int Tc;
	scanf("%d%d%d%d%d%d", &D, &N1, &N2, &C1, &C2, &Tc);
	if (C2 < C1) {
		swap(C1, C2);
		swap(N1, N2);
	}
	for (int i = 1; i <= D; i++) scanf("%d", &T[i]);
	if (Tc <= C1) {
		long long ans = 0;
		for (int i = 1; i <= D; i++) ans += (long long)T[i] * (long long)Tc;
		printf("%lld\n", ans);
		return 0;
	}
	if (Tc <= C2) {
		N2 = N1;
		C2 = C1;
	}
	long long ans = 0;
	int used = 0;
	for (int i = 1; i <= D; i++) {
		int nT = T[i];
		long long tM = 0;
		for (int j = used + 1; j <= i - min(N1, N2) && nT; j++) {
			if (i - j >= N1) {
				if (T[j] > nT) {
					tM += (long long)nT * (long long)C1;
					T[j] -= nT;
					nT = 0;
				}
				else {
					tM += (long long)T[j] * (long long)C1;
					nT -= T[j];
					T[j] = 0;
					used = j;
				}
			}
			else {
				if (T[j] > nT) {
					tM += (long long)nT * (long long)C2;
					T[j] -= nT;
					nT = 0;
				}
				else {
					tM += (long long)T[j] * (long long)C2;
					nT -= T[j];
					T[j] = 0;
					used = j; 
				}
			}
		}
		ans += tM + (long long)nT * (long long)Tc;
	}
	printf("%lld\n", ans);
	return 0;
}
