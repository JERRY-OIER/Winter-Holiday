#include<iostream>
#include<cstdio>
using namespace std;
int n,w[100001],ans=1,sum;
int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		scanf("%d",&w[i]);
	for(int i=1;i<=n;i++)
	{
		if(sum<w[i])
			sum+=w[i];
		else
		{
			sum=w[i];
			ans++;
		}
	}
	cout<<ans<<endl;
	return 0;
}
