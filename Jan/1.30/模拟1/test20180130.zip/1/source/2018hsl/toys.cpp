#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#define INF 0x7fffffff
using namespace std;
void sp(int &a,int &b)
{
	int c=a;
	a=b;
	b=c;
}
int d,t[100001],n1,c1,n2,c2,tc,s,e,fir[100005],sum,tot,ans,hei[100005],jsq,dis[100005];
struct{
	int to,last,cost,lim;
}line[410000];
bool vis[100001];
int DFS(int x,int flow,int cost)
{
	int f;
	if(x==e)
	{
		sum+=flow*(d-1);
		ans+=cost;
		return flow;
	}	
	for(int next=fir[x];next;next=line[next].last)
		if(line[next].lim&&hei[line[next].to]==hei[x]+1)
			if(f=DFS(line[next].to,min(line[next].lim,flow),flow!=INF?cost+line[next].cost*flow:cost))
			{
				line[next].lim-=f;
				if(x!=s)
					line[next+1].lim+=f;
				return f;
			}
	return 0;
}
bool BFS(int x)
{
	bool mark=false;
	queue<int>nx;
	nx.push(s);
	memset(hei,0,sizeof(hei));
	memset(dis,0,sizeof(dis));
	while(!nx.empty())
	{	
		x=nx.front();
		nx.pop();
		for(int next=fir[x];next;next=line[next].last)
			if(line[next].lim&&(!dis[line[next].to]||dis[x]+line[next].cost<dis[line[next].to]))
			{
				if(line[next].to==e)
					mark=true;
				nx.push(line[next].to);
				dis[line[next].to]=dis[x]+line[next].cost;
				hei[line[next].to]=hei[x]+1;
			}
	}
	while(DFS(s,INF,0)){}
	return mark;
}
void con(int u,int v,int w,int r)
{
	line[++jsq].to=v;
	line[jsq].last=fir[u];
	fir[u]=jsq;
	line[jsq].cost=w;
	line[jsq].lim=r;
}
int main()
{
	int x;
	freopen("toys.in","r",stdin);
	//freopen("toys.out","w",stdout);
	cin>>d>>n1>>n2>>c1>>c2>>tc;
	e=d;
	if(n1>n2)
	{
		sp(n1,n2);
		sp(c1,c2);
	}
	if(tc<=c1)
	{
		for(int i=1;i<=d;i++)
			ans+=tc*t[i];
		cout<<ans<<endl;
		return 0;
	}
	if(tc<=c2)
	{
		for(int i=1;i<=d;i++)
		{
			ans+=tc*t[i];
			ans+=c1*min(t[i],t[i+n1]);
			t[i+n1]-=min(t[i],t[i+n1]);
		}
		cout<<ans<<endl;
		return 0;
	}
	for(int i=1;i<=d;i++)
	{
		scanf("%d",&t[i]);
		tot+=t[i];
		con(i,i+n1,c1,t[i]);
		con(i+n1,i,-c1,0);
		con(i,i+n2,c2,t[i]);
		con(i+n2,i,-c2,0);
	}
	for(int i=1;i<=n1;i++)
		con(s,i,0,INF);	
	while(BFS(s)){}
	cout<<(tot-sum)*tc+ans<<endl;
	return 0;
}
