#include<bits/stdc++.h>
using namespace std;
int zhen[100010];
int ans,n;
void dfs(int x,int now,int last,int ceng)
{
	if(x>n)
	{
		ans=max(ans , ceng);
		return ;
	}
	if(ceng+n-x+1<=ans) return ;
	if(zhen[x]<=now) dfs(x+1,zhen[x],now,ceng+1);
	if(now+zhen[x]<=last || ceng==1) dfs(x+1,now+zhen[x],last,ceng);
	return ;
}
int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&zhen[i]);
	}
	dfs(1,0,0,1);
	printf("%d\n",ans);
	return 0;
}
