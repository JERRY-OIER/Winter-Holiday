#include<bits/stdc++.h>
using namespace std;
int toy[100010];
int main()
{
	freopen("toys.in","r",stdin);
	freopen("toys.out","w",stdout);
	int n,day1,day2,pay1,pay2,pay0;
	scanf("%d %d %d %d %d %d",&n,&day1,&day2,&pay1,&pay2,&pay0);
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&toy[i]);
		if(i>day1) toy[i-day1]+=toy[i-day1-1];
		if(i>day2) toy[i-day2]+=toy[i-day2-1];
		if(pay0<=pay1 && pay0<=pay2) ans+=toy[i]*pay0;
		else if((pay1<=pay2 || i<=day2) && i>day1)
		{
			ans+=min(toy[i] , toy[i-day1])*pay1;
			if(toy[i-day1]<toy[i])
				if(pay2<=pay0 && i>day2)
				{
					ans+=min(toy[i]-toy[i-day1] , toy[i-day2])*pay2;
					if(toy[i-day1]+toy[i-day2]<toy[i]) ans+=(toy[i]-toy[i-day1]-toy[i-day2])*pay0;
					int d2=min(toy[i]-toy[i-day1] , toy[i-day2]);
					if(day2>day1)
						for(int j=i-day2+1;j<=i-day1;j++) toy[j]-=d2;
					toy[i-day2]-=d2;
				}
				else ans+=(toy[i]-toy[i-day1])*pay0;
			int d1=min(toy[i] , toy[i-day1]);
			if(day1>day2)
				for(int j=i-day1+1;j<=i-day2;j++) toy[j]-=d1;
			toy[i-day1]-=d1;
		}
		else if(i>day2)
		{
			ans+=min(toy[i] , toy[i-day2])*pay2;
			if(toy[i-day2]<toy[i])
				if(pay1<=pay0 && i>day1)
				{
					ans+=min(toy[i]-toy[i-day2] , toy[i-day1])*pay1;
					if(toy[i-day1]+toy[i-day2]<toy[i]) ans+=(toy[i]-toy[i-day1]-toy[i-day2])*pay0;
					int d1=min(toy[i]-toy[i-day2] , toy[i-day1]);
					if(day1>day2)
						for(int j=i-day1+1;j<=i-day2;j++) toy[j]-=d1;
					toy[i-day1]-=d1;
				}
				else ans+=(toy[i]-toy[i-day2])*pay0;
			int d2=min(toy[i] , toy[i-day2]);
			if(day2>day1)
				for(int j=i-day2+1;j<=i-day1;j++) toy[j]-=d2;
			toy[i-day2]-=d2;
		}
		else ans+=toy[i]*pay0;
	}
	printf("%d\n",ans);
	return 0;
}
	
