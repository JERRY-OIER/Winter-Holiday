#include<bits/stdc++.h>
using namespace std;
int ch[300010][26] , tr[300010];
int end[300010],ans[300010];
char s[30010][30010];
int main()
{

	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int n;
	int p=0;
	scanf("%d",&n);
	for(int i=1,r=0;i<=n;i++)
	{
		scanf("%s",s[i]);
		int m=strlen(s[i]);
		int getr[26],g=0;
		memset(getr,0,sizeof(getr));
		for(int j=0,now=0;j<m;j++)
		{
			int sj=s[i][j]-'a';
			int &next=ch[now][sj];
			if(!next)
			{
				next=++p;
			}
			if(j+1==m) end[next]=++r;
			if(!getr[sj]) getr[sj]=++g;
			tr[next]=getr[sj];
			now=next;
		}
	}
	queue<int> q;
	q.push(0);
	p=0;
//	for(int i=0;i<=20;i++) cout<<end[i];
//	cout<<'\n';
	//for(int i=0;i<=20;i++) cout<<tr[i];
	while(!q.empty())
	{
		int now=q.front(),min_=100;
		q.pop();
	//	cout<<now<<' ';
		for(int i=0;i<26;i++)
		{
			int next=ch[now][i];
			if(next && tr[next]<=min_) min_=tr[next];
		}
		for(int i=0;i<26;i++)
		{
			int next=ch[now][i];
			if(next && tr[next]<=min_)
			{
		//		cout<<next<<' ';
				if(end[next]) ans[++p]=end[next];
				else q.push(next);
			}
		}
//		cout<<'\n';
	}
	sort(ans+1,ans+p+1);
	for(int i=1;i<=p;i++) printf("%s\n",s[ans[i]]);
	return 0;
}
