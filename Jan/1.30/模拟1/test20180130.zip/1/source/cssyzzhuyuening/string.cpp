#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<string>
using namespace std;
int n,ch[300300][30],mima[50][50],nd,val[300300];
int ans,isa[300300];
string s[300300];
void ins(string s,int w)
{
    int u=0,l=s.size(),v;
    for(int i=0;i<l;++i)
    {
        v=s[i]-'a';
        if(!ch[u][v])
            ch[u][v]=++nd;
        u=ch[u][v];
    }
    val[u]=w;
}
void dfs(int u)
{
    if(val[u])
    {
        ans++;
        isa[val[u]]=1;
        return;
    }
    int tmm1[30],tmm2[30];
    for(int i=0;i<26;++i)
    {   
        int j=0; 
        if(!ch[u][i])continue;
        for(j=0;j<26;++j)tmm1[j]=mima[i][j],tmm2[j]=mima[j][i];
        for(j=0;j<26;++j)
        {
            if(j==i||!ch[u][j])continue;
            if(mima[i][j]==1)break;
            mima[i][j]=-1;mima[j][i]=1;
        }
        if(j<26)continue;//shun xu?
        dfs(ch[u][i]);
        for(j=0;j<26;++j)mima[i][j]=tmm1[j],mima[j][i]=tmm2[j];
    }
}
int main()
{
    freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;++i)
    {
       cin>>s[i];
        ins(s[i],i);
    }
    dfs(0);
    printf("%d\n",ans);
    for(int i=1;i<=n;++i)
    if(isa[i])cout<<s[i]<<endl;
    return 0;
}
