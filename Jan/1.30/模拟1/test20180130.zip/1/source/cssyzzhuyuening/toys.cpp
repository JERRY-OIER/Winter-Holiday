#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int d,n1,n2,c1,c2,tc;
long long ans=0,qn1,a[500100],la[500100];
int main()
{
    freopen("toys.in","r",stdin);
    freopen("toys.out","w",stdout);
    scanf("%d%d%d%d%d%d",&d,&n1,&n2,&c1,&c2,&tc);
    for(int i=1;i<=d;++i)scanf("%lld",&a[i]);
    if(c1>c2)swap(c1,c2),swap(n1,n2);
    if(tc<=c1)
    {
        for(int i=1;i<=d;++i)ans+=tc*a[i];
        printf("%lld\n",ans);
        return 0;
    }
    else if(tc>c1&&tc<=c2)
    {
        for(int i=1;i<=d;++i)
        {
            la[i+n1]+=a[i];
            int tt=min(la[i],a[i]);
            ans+=c1*tt;
            la[i]-=tt;
            ans+=tc*(a[i]-tt);
            la[i+1]+=la[i];
        }
        printf("%lld\n",ans);return 0;
    }
    else
    {   
        for(int i=1;i<=d;++i)
        {
            qn1+=la[i];
            la[i+n1]+=a[i];
           if(i<=n1&&i<=n2){ans+=tc*a[i];continue;}
            if(qn1>=a[i])
            {
                int tt=min(qn1,a[i]);
                a[i]-=tt;
                ans+=c1*tt;
                qn1-=tt;
            }
            if(!a[i])continue;
            for(int j=1;j<=n1-n2;++j)
            {
                if(la[i+j])
                {
                    int tt=min(la[i+j],a[i]);
                    ans+=c2*tt;
                    a[i]-=tt;la[i+j]-=tt;
                    if(!a[i])break;
                }
            }
            ans+=tc*a[i];        
        }
        printf("%lld\n",ans);
        return 0;
    }
    return 0;
}
