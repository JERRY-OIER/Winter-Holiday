#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,w[1001000],ans,len,tlen;
int main()
{
    freopen("stack.in","r",stdin);
    freopen("stack.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;++i)scanf("%d",&w[i]);
    len=w[n];ans=1;
    for(int i=n-1;i;)
    {
        tlen=0;
        while(tlen<len&&i)
            tlen+=w[i],i--;
        if(tlen<len&&!i)break;
        len=tlen;
        ans++;
    }
    printf("%d\n",ans);
    return 0;
}
