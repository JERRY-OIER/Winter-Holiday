#include<iostream>
#include<cstdio>
using namespace std;
string s[303003];
int n;
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	 cin>>s[i];
	sort(s+1,s+n+1);
	cout<<1<<endl<<s[1]<<endl;
	return 0;
}
