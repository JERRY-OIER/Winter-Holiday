#include<iostream>
#include<cstdio>
using namespace std;
int d,n1,n2,c1,c2,tc;
long long qn1,qn2,t[101010],ans;
int main()
{
	freopen("toys.in","r",stdin);
	freopen("toys.out","w",stdout);
	scanf("%d%d%d%d%d%d",&d,&n1,&n2,&c1,&c2,&tc);
	if(n1>n2) swap(n1,n2),swap(c1,c2);
	for(int i=1;i<=d;i++)
	{
		scanf("%lld",&t[i]);
		if(i-n1<=0)
		{
			ans+=tc*t[i];
			continue;
		}
		if(i-n1>0)
			qn1+=t[i-n1];
		if(i-n2>0)
			qn2+=t[i-n2];
		if(tc<=c1&&tc<=c2)
		{
			ans+=tc*t[i];
			continue;
		}
		else if(c2>=c1)
		{
			if(t[i]<=qn1)
			{
				qn1-=t[i];
				ans+=c1*t[i];
				continue;
			}
			else 
			{
				ans+=c1*qn1+tc*(t[i]-qn1);
				qn1=0;
				continue;
			}
		}
		else 
		{
			if(t[i]<=qn2)
			{
				qn2-=t[i];
				qn1-=t[i];
				ans+=t[i]*c2;
				continue;
			}
			else 
			{
				if(tc>c1)
				{
					if(qn1<t[i])
					{
						ans+=c2*qn2+c1*(qn1-qn2)+tc*(t[i]-qn1);
						qn2-=qn1;
						qn1=0;
						continue;
					}
					else 
					{
						ans+=c2*qn2+c1*(t[i]-qn2);
						qn1-=t[i];
						//qn2-=t[i];
						for(int j=t[i]-qn2,k=i-n1;j;k--)
						if(j<t[k]) t[k]-=j,j=0;
						else j-=t[k],t[k]=0;
						qn2=0;
						continue;
					}
				}
				else 
				{
					ans+=c2*qn2+tc*(t[i]-qn2);
					qn1-=qn2;
					qn2=0;
					continue;
				}
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}		
						
				
				
	
