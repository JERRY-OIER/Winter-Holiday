#include<iostream>
#include<cstdio>
using namespace std;
int n,a[101010],ans,len,num;
int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	 scanf("%d",&a[i]);
	for(int i=n;i;i--)
	{
		num+=a[i];
		if(num>=len)
		{
			len=num;
			num=0;
			ans++;
		}
	}
	printf("%d\n",ans);
	return 0;
}
