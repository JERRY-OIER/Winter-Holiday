#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;

int n, ans1, ans2;
int h[100010];

void solve1()
{
	int ans = 0, top = 0;
	for(int i = 1; i <= n; i++)
	{
		for(int j = 0; j < i; j++)
		    top += h[n - j];
		int ret = 1, now = 0;
		for(int j = n - i; j >= 0; j--)
		{
			if(now < top)
			    now += h[j];
			else
			{
				top = now;
				now = h[j];
				ret++;
			}
		}
		ans = max(ans, ret);
	}
	ans1 = ans;
	printf("%d\n", ans);
	return;
}

void solve2()
{
	int mid1, mid2, top1, top2, ret1, ret2, now1, now2, l = 1, r = n, ans = 0;
	while(r - l > 5)
	{
		top1 = 0, top2 = 0, ret1 = 1, ret2 = 1, now1 = 0, now2 = 0;
		mid1 = l + (r - l) / 3;
		mid2 = r - (r - l) / 3;
		for(int i = 0; i < mid1; i++)
		    top1 += h[n - i];
		for(int i = n - mid1; i >= 0; i--)
		{
			if(now1 < top1)
			    now1 += h[i];
			else
			{
				top1 = now1;
				now1 = h[i];
				ret1++;
			}
		}
		for(int i = 0; i < mid2; i++)
		    top2 += h[n - i];
		for(int i = n - mid2; i >= 0; i--)
		{
			if(now2 < top2)
			    now2 += h[i];
			else
			{
				top2 = now2;
				now2 = h[i];
				ret2++;
			}
		}
		if(ret1 > ret2)
		    r = ret2;
		else
		    l = ret1;
	}
	int top = 0, now = 0, ret = 1;
	for(int i = l; i <= r; i++)
	{
		ret = 1, now = 0, top = 0;
		for(int j = 0; j < i; j++)
		    top += h[n - j];
		for(int j = n - i; j >= 0; j--)
		{
			if(now < top)
			    now += h[j];
			else
			{
				top = now;
				now = h[j];
				ret++;
			}
		}
		ans = max(ans, ret);
	}
	ans2 = ans;
	printf("%d\n", ans);
	return;
}

int main()
{
	freopen("stack.in", "r", stdin);
	freopen("stack.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++)
	    scanf("%d", &h[i]);
	if(n <= 2500)
		solve1();
	else
	    solve2();
	return 0;
}
