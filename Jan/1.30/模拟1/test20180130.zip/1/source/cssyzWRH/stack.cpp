#include <cstdio>

using namespace std;

long long N, w[100010];
long long wide, wide_1;
//bool dp[100010];
long long ans;

int main() {
  freopen("stack.in", "r", stdin);
  freopen("stack.out", "w", stdout);
  scanf("%lld", &N);
  for(int i = 1; i <= N; i++) 
    scanf("%lld", &w[i]);
  wide = w[N];
  wide_1 = 0;
  ans++;
  //  printf("%lld\n", w[N]);
  for(int i = N - 1; i >= 1; i--) {
    if(w[i] + wide_1 >= wide) {
      ans++;
      wide = w[i] + wide_1;
      wide_1 = 0;
      //      printf("%lld\n", w[i]);
      continue;
    } else {
      wide_1 += w[i];
      //      printf("%lld ", w[i]);
    }
  }
  printf("%lld\n", ans);
  return 0;
}
