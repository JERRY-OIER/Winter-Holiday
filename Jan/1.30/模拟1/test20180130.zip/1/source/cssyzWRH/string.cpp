#include <bits/stdc++.h>

using namespace std;

int N;

struct jjjjjjj {
  string str;
  int num;
}cha[30005];

bool hhw[30005];

bool cmp1(jjjjjjj a, jjjjjjj b) {
  return a.str < b.str;
}

bool cmp2(jjjjjjj a, jjjjjjj b) {
  return a.num < b.num;
}
/*
bool bl(string a) {
  bool hahaha[26];
  memset(hahaha, 0, sizeof(hahaha));
  for(int i = 0; i < a.length(); i++) {
    int jj = a[i] - 'a';
    if(hahaha[jj]) continue;
    else if(i > 0) return false;
    else hahaha[i] = true;
  }
  return true;
}
*/
int main() {
  freopen("string.in", "r", stdin);
  freopen("string.out", "w", stdout);
  int s = 0;
  cin>>N;
  for(int i = 0; i < N; i++) {
    cin>>cha[i].str;
    cha[i].num = i;
    if(cha[i].str.length() == 1) {
      hhw[i] = true;
      continue;
    }
    if(bl(cha[i].str))
      hhw[i] = true;
  }
  sort(cha, cha + N, cmp1);
  hhw[cha[0].num] = true;
  sort(cha, cha + N, cmp2);
  for(int i = 0; i < N; i++) {
    if(hhw[i])
      s++;
  }
  cout<<s<<endl;
  for(int i = 0; i < N; i++) {
    if(hhw[i])
      cout<<cha[i].str<<endl;
  }
  return 0;
}
