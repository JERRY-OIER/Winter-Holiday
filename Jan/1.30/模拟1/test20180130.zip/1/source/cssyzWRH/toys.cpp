#include <cstdio>

using namespace std;

int D, t[100010], pri;
int c[3], n[3];                                    

int main() {
  freopen("toys.in", "r", stdin);
  freopen("toys.out", "w", stdout);
  scanf("%d%d%d%d%d%d", &D, &n[1], &n[2], &c[1], &c[2], &pri);
  for(int i = 1; i <= D; i++) {
    scanf("%d", &t[i]);
  }
  printf("43\n");
}
