#include <bits/stdc++.h>

using namespace std;

const int N = 300000;
const int M = 30000;

struct trie {
	char ch;
	int son[26];
	int fa;
	int end;
}T[N + 1];

int n;
int jsq;
char s[N + 1];
int check[M + 1];
int res;

void build(int k) {
	int x = 0, len = strlen(s + 1);
	for(int i = 1; i <= len; i++) {
		if(!T[x].son[s[i] - 'a']) {
			T[x].son[s[i] - 'a'] = ++jsq;
			T[jsq].fa = x;
			T[jsq].ch = s[i];
			x = jsq;
		}
		else {
			x = T[x].son[s[i] - 'a'];
		}
		if(i == len) {
			T[x].end = k;
		}
	}
}

int book[26][26];
int d[2][26];

void add(int x, int k) {
	for(int i = 0; i < 26; i++)
		if(i != k && T[x].son[i]) {
			if(!book[k][i]) {
				d[0][k]++;
				d[1][i]++;
			}
			book[k][i]++;
		}
}

void del(int x, int k) {
	for(int i = 0; i < 26; i++) {
		if(!book[k][i] || !T[x].son[i] || i == k) continue;
		if(book[k][i] == 1) {
			d[0][k]--;
			d[1][i]--;
		}
		book[k][i]--;
	}
}

bool judge(int x, int k) {
	bool arrive[26];
	memset(arrive, 0, sizeof(arrive));
	queue<int>q;
	int dd[2][26], tot = 0;
	for(int i = 0; i < 26; i++) dd[0][i] = d[0][i], dd[1][i] = d[1][i];
	for(int i = 0; i < 26; i++)
		if(!dd[1][i]) q.push(i), arrive[i] = 1, tot++;
	while(!q.empty()) {
		int f = q.front(); q.pop();
		for(int i = 0; i < 26; i++)
			if(book[f][i] && !arrive[i]) {
				dd[1][i]--;
				if(!dd[1][i]) {
					q.push(i);
					arrive[i] = 1;
					tot++;
				}
			}
	}
	if(tot == 26) return 1;
	return 0;
}

void work(int node) {
	if(T[node].end) {
		res++;
		check[T[node].end] = node;
		return ;
	}
	for(int i = 0; i < 26; i++)
		if(T[node].son[i]) {
			add(node, i);
			if(judge(node, i)) work(T[node].son[i]);
			del(node, i);
		}
}

void print(int node) {
	if(!node) {
		return;
	}
	print(T[node].fa);
	putchar(T[node].ch);
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++) {
		scanf("%s", s + 1);
		build(i);
		memset(s, 0, sizeof(s));
	}
	work(0);
	printf("%d\n", res);
	for(int i = 1; i <= n; i++)
		if(check[i])
			print(check[i]), putchar('\n');
	return 0;
}
