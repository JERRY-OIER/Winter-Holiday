#include <bits/stdc++.h>

using namespace std;

int n;
long long t1, c1;
long long t2, c2;
long long per;
long long sum;
long long res;
long long q[100005];
long long d[100005];

int main() {
	freopen("toys.in", "r", stdin);
	freopen("toys.out", "w", stdout);
	cin >> n >> t1 >> t2 >> c1 >> c2 >> per;
	if(c1 > c2) swap(t1, t2), swap(c1, c2);
	for(int i = 1; i <= n; i++) {
		cin >> d[i];
		sum += d[i];
	}
	if(c1 >= per) res = sum * per;
	else if(t1 <= t2 || per <= c2) {
		sum = 0;
		for(int i = 1; i <= n; i++) {
			if(i <= t1) res += per * d[i];
			else {
				sum += d[i - t1];
				long long k = min(sum, d[i]);
				res += k * c1 + (d[i] - k) * per;
				sum -= k;
			}
		}
	}
	else {
		long long sum1 = 0; sum = 0;
		for(int i = 1; i <= n; i++) {
			if(i <= t2) res += per * d[i], q[i] = d[i];
			else if(i <= t1) {
				sum += d[i - t2];
				long long k = min(sum, d[i]);
				res += k * c2 + (d[i] - k) * per;
				sum -= k;
				for(int j = i - t2; j >= 1 && k; j--) {
					long long p = min(q[j], k);
					q[j] -= p;
					k -= p;
				}
				q[i] = d[i];
			}
			else {
				sum1 += q[i - t1]; sum -= q[i - t1 + 1];
				long long k = min(sum1, d[i]);
				res += k * c1;
				sum1 -= k;
				if(d[i] - k) {
					sum += d[i - t2 + 1];
					long long l = min(sum, d[i] - k);
					res += l * c2 + (d[i] - k - l) * per;
					sum -= k;
					for(int j = i - t2 + 1; j >= 1 && k; j--) {
						long long p = min(q[j], k);
						q[j] -= p;
						k -= p;
					}
				}
				q[i] = d[i];
			}
		}
	}
	cout << res << endl;
	return 0;
}
