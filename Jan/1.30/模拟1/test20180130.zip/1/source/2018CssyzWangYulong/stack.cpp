#include <cstdio>
#include <iostream>
using namespace std;
int a[100005];
int main() {
	freopen("stack.in", "r", stdin);
	freopen("stack.out", "w", stdout);
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);
	}
	int res = 0, tmp = 0, ans = 0;
	for (int i = n; i >= 1; --i) {
		tmp += a[i];
		if (tmp >= res) {
			ans++;
			res = tmp;
			tmp = 0;
		}
	}
	printf("%d", ans);
	return 0;
}
