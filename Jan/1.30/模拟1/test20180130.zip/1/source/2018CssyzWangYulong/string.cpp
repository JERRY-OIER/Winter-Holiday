#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;
int n;
int can[30004];

struct bag {
	int i;
	vector <char> s;
	int len;
} b[30004];

vector <char> tmp[300005];


int app[50], rank[50];
int ans;

void find(int pos, int l, int r) {
	if (pos == b[l].len + 1 || l == r) {
		ans++;
		//cout << "\n#" << l << endl;
		can[b[l].i] = b[l].len;
		return ;
	}
	
	//cout << "THERE" <<l << " " << r << " "<< pos << endl;
	
	int minrank = 100000;
	
	for (int i = l; i <= r; ++i) {
		if (app[b[i].s[pos] - 'a' + 1] == 0 || rank[b[i].s[pos] - 'a' + 1] == 0) continue;
		minrank = min(rank[b[i].s[pos] - 'a' + 1], minrank);
	}
	
	//cout <<"MINRANK" <<minrank << " " << rank['m' - 'a' + 1] << " " << app['m' - 'a' + 1] << endl;
	
	if (minrank != 100000) {
		int tn = l, tm;
		while (tn < r && rank[b[tn].s[pos] - 'a' + 1] != minrank) {
			++tn;
		}
		tm = tn;
		while (tm < r && rank[b[tm + 1].s[pos] - 'a' + 1] == minrank) {
			tm++;
		}
		app[b[tm].s[pos] - 'a' + 1] += tm - tn + 1;
		//cout << 2;
		find(pos + 1, tn, tm);
		app[b[tm].s[pos] - 'a' + 1] -= tm - tn + 1;
		return ;
	}
	
	for (int i = l; i <= r; ++i) {
		int j = i;
		while (j < r && b[j].s[pos] == b[j + 1].s[pos] ) {
		//while (b[j].s[pos] == b[j + 1].s[pos] && j < r) {
			++j;
			//cout << j;
		}
		
		//cout << "CAA";
		app[b[j].s[pos] - 'a' + 1] += j - i + 1;
		rank[b[j].s[pos] - 'a' + 1] = pos;
		
		//cout << 3;
		find(pos + 1, i, j);
		//cout << 4 << endl;
	//cout << "HERE" << l << " " << r << " "<< pos << endl;
		app[b[j].s[pos]] -= j - i + 1;
		rank[b[j].s[pos] - 'a' + 1] = 0;
		i = j;
	}
	return ;
}


bool cmp(bag x, bag y) {
	int i = 1;
	while (i < x.len && i < y.len && x.s[i] == y.s[i]) {
		++i;
	}
	if (x.s[i] == y.s[i])
		return x.len < y.len;
	return x.s[i] < y.s[i];
}

char s[300005];
int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		scanf("%s", s + 1);
		b[i].len = strlen(s + 1);
		b[i].s.push_back('#');
		tmp[i].push_back('#');
		for (int j = 1; j <= b[i].len; ++j) {
			b[i].s.push_back(s[j]);
			tmp[i].push_back(s[j]);
			//cout << b[i].s[j];
		}
		b[i].s.push_back('#');
		tmp[i].push_back('#');
		b[i].i = i;
	}
	
	
	/*for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= b[i].len; ++j) {
			cout << b[i].s[j];
		}
		cout << i << endl;
	}*/
	
	
	sort(b + 1, b + 1 + n, cmp);
	
	/*for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= b[i].len; ++j) {
			cout << b[i].s[j];
		}
		cout << i << endl;
	}*/
	
	find(1, 1, n);
	
	printf("%d\n", ans);
	
	for (int i = 1; i <= n; ++i) {
		if (!can[i]) continue;
		for (int j = 1; j <= can[i]; ++j) {
			printf("%c", tmp[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
