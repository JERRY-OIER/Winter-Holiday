#include <iostream>
#include <cstdio>
#include <queue>
#include <iostream>
using namespace std;

int s = 1, t, n;
long long buy, fast, fac, slow, slc, cnt;
int head[5003], nxt[50000], to[50000];
long long r[2003], wei[50000], c[50000];  

int back(int x) {
    if (x % 2 == 0) return x - 1; 
    return x + 1;
}

void add (int f, int t, long long ca, long long weight) {
    nxt[++cnt] = head[f];
    head[f] = cnt;
    to[cnt] = t;
    c[cnt] = ca;
    wei[cnt] = weight;
    return ;
}

void mk() {
    for (int i = 1; i <= n; ++i) {
        add(s, n + i + 1, r[i], buy);
        add(n + i + 1, s, 0, -buy);
        add(n + i + 1, t, r[i], 0);
        add(t, n + i + 1, 0, 0);
        
        add(s, i + 1, r[i], 0);
        add(i + 1, s, 0, 0);
        
        if (i + fast <= n) {
            add(i + 1, n + 1 + (i + fast), 1000000008ll, fac);
            add(n + 1 + (i + fast), i + 1, 0, -fac);
        }
        
        if (i + slow <= n) {
            add(i + 1, n + 1 + (i + slow), 1000000008ll, slc);
            add(n + 1 + (i + slow), i + 1, 0, -slc);
        }
        
        if (i < n) {
            add(i + 1, i + 2, 200000000000ll, 0);
            add(i + 2, i + 1, 0, 0);
        }
    }
    return ;
}

long long sumr;
long long dist[5003];

queue<int> q;
int prevv[5003], preve[5003];

long long min_cost() {
    long long ans = 0;
    while (sumr > 0) {
        for (int i = 2; i <= t; ++i) {
            dist[i] = 20000000000ll;
        }
        dist[s] = 0;
        q.push(s);
        while (!q.empty()) {
            int u = q.front();
            q.pop();
            for (int i = head[u]; i != 0; i = nxt[i]) {
                if (c[i] > 0 && dist[to[i]] > dist[u] + wei[i]){
                    dist[to[i]] = dist[u] + wei[i];
                    prevv[to[i]] = u;
                    preve[to[i]] = i;
                    q.push(to[i]);
                }
            }
        }
        
        if (dist[t] == 2000000000ll) return -1;
        
        long long d = sumr;
        for (int v = t; v != s; v = prevv[v]) {
            d = min(d, c[preve[v]]);
        }
        
        sumr -= d;
        ans += d * dist[t];
        
        for (int v = t; v != s; v = prevv[v]) {
            c[preve[v]] -= d;
            c[back(preve[v])] +=d;
            
        }
        //cout << sumr << " " << ans << endl;
    }
    return ans;

}

int main() {
	freopen("toys.in", "r", stdin);
	freopen("toys.out", "w", stdout);
	
    scanf("%d", &n);
    scanf("%lld%lld%lld%lld%lld", &fast, &slow, &fac, &slc, &buy);
    t = 2 * (n + 1);
    for (int i = 1; i <= n; ++i) {
        scanf("%lld", &r[i]);
        sumr += r[i];
    }
    
    mk();
    
    long long ans = min_cost();
    
    printf("%lld", ans);
    
    return 0;
}
