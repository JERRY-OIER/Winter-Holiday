#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int N=100010;
inline ll read(){
	ll X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
ll t[N];
ll dp[N];
int main(){
	freopen("toys.in","r",stdin);
	freopen("toys.out","w",stdout);
	ll d=read(),n1=read(),n2=read(),c1=read(),c2=read(),tc=read();
	for(int i=1;i<=d;i++){
		t[i]=read();dp[i]=dp[i-1]+tc*t[i];
	}
	if(d<=500){
		for(int i=1;i<=d;i++){
			ll now=0;
			for(int j=i+n1;j<=d;j++){
				ll l=-min(t[i],t[j])*tc+c1*min(t[i],t[j]);
				if(l<0){
					now+=l;
					t[i]-=min(t[i],t[j]);
				}
				dp[j]+=now;
			}
			now=0;
			for(int j=i+n2;j<=d;j++){
				ll l=-min(t[i],t[j])*tc+c2*min(t[i],t[j]);
				if(l<0){
					now+=l;
					t[i]-=min(t[i],t[j]);
				}
				dp[j]+=now;
			}
		}
	}
	printf("%lld\n",dp[d]);
	return 0;
}
