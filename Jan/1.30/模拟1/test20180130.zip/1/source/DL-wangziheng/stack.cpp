#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=100010;
inline int read(){
	int X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
int sum[N];
int erfen(int l,int r,int aim,int ed){
	int ans;
	while(l<=r){
		int mid=(l+r)>>1;
		if(sum[ed]-sum[mid-1]>=aim){
			ans=mid;l=mid+1;
		}else r=mid-1;
	}
	return ans;
}
int main(){
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	int n=read();
	for(int i=1;i<=n;i++)sum[i]=sum[i-1]+read();
	int pre=-1,h=0;
	for(int i=n;i>=1;i--){
		if(sum[i]<pre)break;
		int k=erfen(1,i,pre,i);
		pre=sum[i]-sum[k-1];
		h++;i=k;
	}
	printf("%d\n",h);
	return 0;
}
