#include<cmath>
#include<queue>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=300010;
const int INF=2147483647;
struct node{
	int to,nxt;
	char ch;
}e[N];
int n,cnt=0,cnt1=1,head[N];
int ans[N],f[27][27],indeg[27];//1<
bool flag[N];
string s[N];
void add(int u,int v,char ch){
	e[++cnt].to=v;
	e[cnt].ch=ch;
	e[cnt].nxt=head[u];
	head[u]=cnt;
	return;
}
void insert(int now){
	int u=1;
	for(int i=0;i<s[now].length();i++){
		int v=-1;
		for(int j=head[u];j;j=e[j].nxt){
			char ch=e[j].ch;
			if(ch==s[now][i]){
				v=e[j].to;
				break;
			}
		}
		if(v==-1)add(u,v=++cnt1,s[now][i]);
		u=v;
	}
	flag[u]=1;
	return;
}
inline int g(char ch){return ch-'a'+1;}
bool topu(){
	queue<int>q;
	int num=0;
	for(int i=1;i<=26;i++){
		if(!indeg[i]){
			num++;q.push(i);
		}
	}
	while(!q.empty()){
		int i=q.front();q.pop();
		for(int j=1;j<=26;j++){
			if(f[i][j]){
				f[i][j]=0;
				indeg[j]--;
				if(!indeg[j]){
					num++;q.push(j);
				}
			}
		}
	}
	return num==26;
}
bool check(int now){
	memset(f,0,sizeof(f));
	memset(indeg,0,sizeof(indeg));
	int u=1;
	for(int i=0;i<s[now].length();i++){
		int v=-1;
		for(int j=head[u];j;j=e[j].nxt){
			char ch=e[j].ch;
			if(ch==s[now][i]){
				v=e[j].to;
			}else{
				if(f[g(ch)][g(s[now][i])])return 0;
				if(!f[g(s[now][i])][g(ch)])indeg[g(ch)]++;
				f[g(s[now][i])][g(ch)]=1;
			}
		}
		u=v;
		if(i!=s[now].length()-1&&flag[u])return 0;
	}
	return topu();
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>s[i];
		insert(i);
	}
	int k=0;
	for(int i=1;i<=n;i++){
		if(check(i))ans[++k]=i;
	}
	printf("%d\n",k);
	for(int i=1;i<=k;i++)cout<<s[ans[i]]<<endl;
	return 0;
}
