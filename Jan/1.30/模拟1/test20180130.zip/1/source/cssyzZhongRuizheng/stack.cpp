#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std;
int now, la, n, ans, w[100005], tot;
long long sta[100005];
int main() {
	freopen ("stack.in", "r", stdin);
	freopen ("stack.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf ("%d", &w[i]);
	}
	tot++;
	sta[tot] = w[1];
	for (int i = 2; i <= n; i++) {
		if (w[i] > sta[tot]) {
			if (sta[tot] + w[i] < sta[tot - 1] || tot == 1) {
				sta[tot] += w[i];
			}
			else {
				while (sta[tot] + sta[tot - 1] > sta[tot - 2]) {
					if(tot == 2) {
						sta[tot - 1] += sta[tot];
						sta[tot] = w[i];
						if (sta[2] > sta[1]) {
							tot--;
							sta[1] += sta[2];
						}
						break;
					}
					sta[tot - 1] += sta[tot];
					tot--;
				}
			}
		}
		else {
			tot++;
			sta[tot] = w[i];
		}
	}
	cout<<tot<<endl;
	return 0;
}

