#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int n;
char s[1001][10001];
int main() {
	freopen ("string.in", "r", stdin);
	freopen ("string.out", "w", stdout);
	cin>>n;
	for (int i = 1; i <= n; i++) {
		cin>>s[i];
	}
	cout<<n<<endl;
	for (int i = 1; i <= n; i++) {
		cout<<s[i]<<endl;
	}
	return 0;
}
