#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std;
int d, n1, n2, c1, c2, tc, w[100001], minn, fir, ans, maxx, can[100001], now;
int main() {
	freopen ("toys.in", "r", stdin);
	freopen ("toys.out", "w", stdout);
	cin>>d>>n1>>n2>>c1>>c2>>tc;
	minn = min(n1, n2);
	if (n1 > n2) {
		swap(n1, n2);
		swap(c1, c2);
	}
	for (int i = 1; i <= d; i++) {
		scanf ("%d", &w[i]);
		maxx = max(w[i], maxx);
	}
	for (int i = 1; i <= minn; i++) {
		fir += w[i];
	}
	fir = max(fir, maxx);
	ans += fir * tc;
	now = fir;
	for (int i = 1; i + n1 <= d; i++) {
		int flag = w[i];
		int j = i;
		while (can[j] > w[j]) {
			can[j + 1] += can[j] -w[j];
			can[j] = w[j];
			j++;
		}
		j = i + n1;
		while (can[j] > w[j]) {
			can[j + 1] += can[j] -w[j];
			can[j] = w[j];
			j++;
		}
		j = i + n2;
		while (can[j] > w[j]) {
			can[j + 1] += can[j] -w[j];
			can[j] = w[j];
			j++;
		}
		int x1 = w[n1 + i] - can[n1 + i];
		int x2;
		if (n2 + i == d) x2 = w[n2 + i] - can[n2 + i];
		else x2 = w[i] - x1;
		if (i + n2 > d) {
			ans += x1 * c1;
			can[n1 + i] += x1;
		}
		else {
		ans += c1 * x1 + c2 * x2;
		can[n1 + i] += x1;
		can[n2 + i] += x2;
		}
	}
	cout<<ans<<endl;
	return 0;
}
