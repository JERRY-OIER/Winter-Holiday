#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<string>
#include<vector>
using namespace std;
const int N=3e5+5;
typedef  pair<int,string> pis;
vector<pis>vt;
string st;
struct trie
{
	int ch[26];
	int dmax;
	int dan;
	trie()
	{
		memset(ch,0,sizeof(ch));
		dmax=dan=0;
	}
}t[N];
int n,dep[26],cnt,ncnt=1,root=1,now;
char s[N];
void insert(int x)
{
	memset(dep,0,sizeof(dep));
	now=root;
	int l=strlen(s);
	for(int i=0;i<l;i++)
	{
	if(t[now].dan) return;
	if(dep[s[i]-'a']!=0&&t[now].dmax!=0&&dep[s[i]-'a']>t[now].dmax) return;
	if(dep[s[i]-'a']==0) dep[s[i]-'a']=i+1;
	if(t[now].dmax==0) t[now].dmax=dep[s[i]-'a'];
	else t[now].dmax=min(t[now].dmax,dep[s[i]-'a']);
	if(t[now].ch[s[i]-'a'])
		{
			now=t[now].ch[s[i]-'a'];
		}
	else
		{
			t[now].ch[s[i]-'a']=++ncnt;
			now=ncnt; 
		}
	}
	t[now].dan=x;
	return;
}
void dfs(int u,int D)
{
//	printf("%d:%d %d\n",u,t[u].dmax,t[u].dan);
	if(t[u].dan)
	{
		vt.push_back(make_pair(t[u].dan,st));
		return ;
	}
	for(int i=0,pre;i<26;i++)
	{
		if(t[u].ch[i]==0) continue;
		pre=dep[i+'a'];
		if(dep[i+'a']==0)dep[i+'a']=D;
		else if(t[u].dmax<dep[i+'a']) continue;
		st.push_back(i+'a');
//		printf("%c",i+'a');
		dfs(t[u].ch[i],D+1);
		dep[i+'a']=pre;
		st.erase(st.end()-1);
	}
}
void solve()
{
	memset(dep,0,sizeof(dep));
	dfs(root,1);
}
void DFS(int u)
{
	printf("%d:%d %d\n",u,t[u].dmax,t[u].dan);
	for(int i=0;i<26;i++) if(t[u].ch[i]) printf("%c",i+'a'),DFS(t[u].ch[i]);
}
int main()
{
	freopen("string.in","r",stdin);freopen("string.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",s);
		insert(i);
//		printf("?%d\n",cnt);
	}
	//DFS(root);
	solve();
	sort(vt.begin(),vt.end()); 
	printf("%d\n",vt.size());
	for(int i=0;i<vt.size();i++) cout<<vt[i].second<<endl;
	return 0;
}
/*
4
omm
moo
mom
ommnom

*/
