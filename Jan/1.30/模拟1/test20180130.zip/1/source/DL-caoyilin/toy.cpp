#include<cstdio>
#include<algorithm>
#define inf 0x3f3f3f3f
using namespace std;
const int N=1e5+5;
int d,n1,n2,c1,c2,tc;
long long sum; 
int t[N];
int main()
{
	freopen("toy.in","r",stdin);freopen("toy.out","w",stdout);
	scanf("%d%d%d%d%d%d",&d,&n1,&n2,&c1,&c2,&tc);
	for(int i=1;i<=d;i++) scanf("%d",&t[i]),sum+=t[i];
	if(n1>n2) swap(n1,n2),swap(c1,c2);
	printf("%lld",sum*tc);
	return 0;
}
