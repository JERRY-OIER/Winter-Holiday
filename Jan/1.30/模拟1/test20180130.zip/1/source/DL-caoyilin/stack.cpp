#include<cstdio>
#include<algorithm>
using namespace std;
const int N=1e5+5;
int n,cnt;
int w[N];
int main()
{
	freopen("stack.in","r",stdin);freopen("stzck.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
	int lim=w[n];
	for(int i=n-1;i>=1;i--) 
	{
		if(w[i]<lim) 
		{
			w[i-1]+=w[i];
			cnt++;
			continue;
		}
		lim=max(lim,w[i]);
	}
	printf("%d",n-cnt);
	return 0;
}
