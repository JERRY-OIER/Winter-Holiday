#include<cstdio>
#include<algorithm>
#define N 100010
using namespace std;
int n,a[N],l=1,r,mid,ans,sum[N];

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

int check(int x)
{
	int ll=n,now=0,tmp=0,height=1;
	while (x--) now+=a[ll--];
	//printf("!%d!\n",ll);
	while (ll)
	{
		if (sum[ll]<now) return height;
		while (tmp<now && ll) tmp+=a[ll--];
		if (tmp<now) return 1;
		now=tmp;
		tmp=0;
		height++;
	}
	return height;
}

void dfs(int x,int floor,int sum,int pre)
{
//	printf("%d\n",x);
	if (x==n) { ans=max(ans,floor); return ; }
	if (floor+n-x<=ans) return ;
	x++;
	if (sum+a[x]<=pre) dfs(x,floor,sum+a[x],pre);
	if (a[x]<=sum) dfs(x,floor+1,a[x],sum);
}

int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout); 
	n=read();
	for (int i=1;i<=n;i++) a[i]=read(),sum[i]=sum[i-1]+a[i];
	r=n;
	if (n<=100)
	{
		dfs(1,1,a[1],1000000007);
		printf("%d\n",ans);
		return 0;
	}
	while (l<r)
	{
		mid=(l+r)>>1;
		//printf("%d ",mid);
		int tmp=check(mid);
		//printf("%d\n",tmp);
		if (tmp>=ans) ans=tmp,r=mid;
		else l=mid+1;
	}
	printf("%d\n",ans);
	return 0;
}
/*
5
9
8
2
6
3
*/
