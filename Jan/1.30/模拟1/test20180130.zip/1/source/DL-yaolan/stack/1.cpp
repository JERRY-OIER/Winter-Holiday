#include<cstdio>
#define N 100010
using namespace std;
int n,w[N],sum[N],stk[N],top;

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

int main()
{
	n=read();
	for (int i=1;i<=n;i++)
		w[i]=read();
	for (int i=1;i<=n;i++)
	{
		sum[++top]=w[i];
		stk[top]=i;
		while (top>1 && sum[top-1]<sum[top])
		{
			sum[top-1]+=w[stk[top]];
			sum[top]-=w[stk[top]];
			if (!sum[top]) top--;
			else stk[top]++;
			if (stk[top]>i) break;
		}
		if (!sum[top]) top--;
	}
	printf("%d\n",top);
	for (int i=1;i<=top;i++)
	printf("%d ",sum[i]);
	return 0;
}
