#include<cstdio>
#include<algorithm>
#include<ctime>
#include<iostream>
#define N 100010
using namespace std;
int n,a[N],ans;

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

void dfs(int x,int floor,int sum,int pre)
{
//	printf("%d\n",x);
	if (x==n) { ans=max(ans,floor); return ; }
	if (floor+n-x<=ans) return ;
	x++;
	if (sum+a[x]<=pre) dfs(x,floor,sum+a[x],pre);
	if (a[x]<=sum) dfs(x,floor+1,a[x],sum);
}

int main()
{
	freopen("stack.in","r",stdin);
	n=read();
	for (int i=1;i<=n;i++) a[i]=read();
	dfs(1,1,a[1],1000000007);
	printf("%d\n",ans);
	cerr<<clock();
	return 0;
}
