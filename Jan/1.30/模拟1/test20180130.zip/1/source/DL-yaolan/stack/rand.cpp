#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
int n;

int main()
{
	freopen("stack.in","w",stdout);
	srand((int)time(0));
	n=100;
	printf("%d\n",n);
	for (int i=1,a;i<=n;i++)
		a=rand()%10000+1,printf("%d\n",a);
	return 0;
}
