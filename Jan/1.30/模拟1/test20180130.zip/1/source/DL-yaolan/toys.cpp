#include<cstdio>
#include<algorithm>
#define N 100010
using namespace std;
int d,n1,n2,c1,c2,tc,t,now,last[N],ans;
bool b;

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

void get(int now,int x)
{
	if (!x) return ;
	if (b) 
	{
		for (int i=now-1,p;i && x;i--)
		{
			p=min(last[i],x);
			ans+=c1*p;
			x-=p;
			last[i]-=p;
		}
		return ;
	}
	//printf("%d %d\n",now,x);
	for (int i=1,p;i<=now-n2;i++)
	{
		p=min(last[i],x);
		ans+=c2*p;
		x-=p;
		last[i]-=p;
	}
	if (!x) return ;
	for (int i=now-1,p;i && x;i--)
	{
		p=min(last[i],x);
		ans+=c1*p;
		x-=p;
		last[i]-=p;
	}
}

int main()
{
	freopen("toys.in","r",stdin);
	freopen("toys.out","w",stdout);
	d=read();
	n1=read();n2=read();c1=read();c2=read();
	if (n2<n1) swap(n1,n2),swap(c1,c2);
	b=c1<=c2;
	tc=read();
	for (int i=1;i<=d;i++)
	{
		t=read();
		if (now<=t) ans+=tc*(t-now);
		get(i,min(now,t));
		now-=min(now,t);
		last[i]=t;
		now+=t;
	}
	printf("%d\n",ans);
	return 0;
}
/*
4 1 2 2 1 3
8
2
1
6
*/
