#include<cstdio>
#include<vector>
#include<cstring>
#include<algorithm>
#define N 300010
using namespace std;
struct hhh
{
	int son[30],end;
	hhh() { memset(son,0,sizeof(son)); end=0; }
}tre[N];
int cnt=1,n,qq=1,start[N],rank[30],prev[30];
char s[N],t[N];
vector <int> v;

void insert(int x)
{
	int now=0;
	int l=strlen(s+1);
	start[x]=qq;
	for (int i=1;i<=l;i++)
	{
		if (tre[now].son[s[i]-'a'+1]) now=tre[now].son[s[i]-'a'+1];
		else now=tre[now].son[s[i]-'a'+1]=cnt++;
		t[qq++]=s[i];
	}
	tre[now].end=x;
}

bool check(int x)
{
	memset(rank,0,sizeof(rank));
	int now=0;
	for (int i=start[x],j=1;i<start[x+1];i++)
	{
		if (tre[now].end) return 0;
		if (!rank[t[i]-'a'+1]) rank[t[i]-'a'+1]=j,prev[j]=t[i]-'a'+1,j++;
		for (int k=1;k<j && k<rank[t[i]-'a'+1];k++)
			if (tre[now].son[prev[k]]) return 0;
		now=tre[now].son[t[i]-'a'+1];
	}
	return 1;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%s",s+1),insert(i);
	start[n+1]=qq;
	for (int i=1;i<=n;i++)
		if (check(i))
			v.push_back(i);
	int ss=v.size();
	printf("%d\n",ss);
	for (int i=0;i<ss;i++)
	{
		for (int j=start[v[i]];j<start[v[i]+1];j++)
			putchar(t[j]);
		putchar('\n');
	}
	return 0;
}
/*
4
omm
moo
mom
ommnom
*/
