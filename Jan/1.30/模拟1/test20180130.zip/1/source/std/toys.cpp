#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

#define MAX (100005)
#define INF (1000000000)

int T[MAX];
int queue[MAX], num[MAX];
int sn,sm,so,en,em,eo;
/* These variables control the queue and point to the start 
 * and end of new, middle, and old toys, respectively. 
 * New toys are ones washed less than N1 days ago, old toys are 
 * washed at least N2 days ago, and middle toys are all the rest.
 * We essentially keep three queues in a single array, but the manner
 * in which we add/remove elements guarantees that we never have to
 * worry about memory overlap.
 */

int D,N1,N2,C1,C2,Tc;

inline void add_new(int x,int q){
  queue[en]=x;
  num[en++]=q;
}

void flush_new(int x){
  while(sn!=en && x-queue[sn] >= N1) { num[em]=num[sn]; queue[em++]
= queue[sn++]; }
}

void flush_mid(int x){
  while(sm!=em && x-queue[sm] >= N2) { num[eo]=num[sm]; queue[eo++]
= queue[sm++]; }
}

int f(int t){ //find the minimum cost given that we use t toys
  sn=sm=so=en=em=eo=0;
  int r = (Tc-C2)*t;
  /*
   * In the following algorithm, we pay even to wash the initial toys, so 
   * we have to subtract this out of our initial cost estimate for 
   * purchasing the toys. This is valid as long as we use all of the toys 
   * we purchase (which is why we start the ternary search at tsum+1 
   * instead of 5000001).
   */
  add_new(-200000,t);
  for(int d=0;d<D;d++){
    flush_new(d); flush_mid(d); //move any toys toys whose status changes 
      //from being new to middle or middle to old to the appropriate queue
    int i = T[d];
    while(i > 0){ //we deal with the toys in batches to make 
      //the runtime of this function O(N) instead of O(sum ti)
      if(so!=eo){ //if there are any old toys
        if(num[eo-1] > i){ //if this batch has more toys than we need, we can stop here
          r += C2*i;
          num[eo-1]-=i;
          break;
        }
        else { //otherwise, use all toys in this batch
          r += C2*num[eo-1];
          i -= num[eo-1];
          eo--;
        }
      }
      else if(sm!=em){ //else if there are any middle toys
        if(num[em-1] > i){
          r += C1*i;
          num[em-1]-=i;
          break;
        }
        else {
          r += C1*num[em-1];
          i -= num[em-1];
          em--;
        }
      }
      else return INF; //if there are no available toys, 
        //we can't find a solution with this many toys
    }
    add_new(d,T[d]); //put the toys we used today back into the queue of toys
  }
  return r;
}

int ternary_search(int s,int e){
  while(1){
    if(e-s <= 2){ //when e-s is small enough that our ternary search 
      //can get stuck, just handle the end manually
      int m = f(s);
      for(int i=s+1;i<e;i++) m = min(m,f(i));
      return m;
    }
    int x = s+(e-s)/3, y = s+2*(e-s)/3; //sample values 1/3 and 2/3 
      //of the way through the remaining interval
    int a = f(x); //f(x) = -1 if x was too few toys to have enough toys each day
    if(a!= INF && a <= f(y)) e=y;
    else s=x;
  }
}

int main(){
  FILE *fin = fopen("toys.in","r");
  FILE *fout = fopen("toys.out","w");
  fscanf(fin,"%d%d%d%d%d%d",&D,&N1,&N2,&C1,&C2,&Tc);
  if(N1 > N2){ //set N2 to be greater than N1
    N1 ^= N2; N2 ^= N1; N1 ^= N2;
    C1 ^= C2; C2 ^= C1; C1 ^= C2;
  }
  if(C1 < C2){ //if faster way is cheaper
    C2 = C1; //then set its cost to that of the slower way, 
      //since we could always just use the slower way instead
  }
  int tsum = 0;
  for(int i=0;i<D;i++) { fscanf(fin,"%d",&T[i]); tsum += T[i]; }
  fprintf(fout,"%d\n",ternary_search(0,tsum+1));
  fclose(fin); fclose(fout);
  return 0;
}
