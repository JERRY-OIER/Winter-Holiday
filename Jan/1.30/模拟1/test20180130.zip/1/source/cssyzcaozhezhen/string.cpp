#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int re[30][30];//i<j
int n;
char s[5001][5001];
int book[5001];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	int m=n;
	for(int i=1;i<=n;i++)   scanf("%s",s[i]);
	for(int i=1;i<=n;i++)
	{	  
		memset(re,0,sizeof(re));
		int flag=0;
	    for(int j=1;j<=n;j++)
	    {
	        if(j!=i)
		  	{
		  		int xk=0;
		  		for(int k=0;k<min(strlen(s[i]),strlen(s[j]));k++)
		  		{
		  			if(s[i][k]!=s[j][k]) 
		  			{
		  				xk=0;
		  				if(re[s[j][k]-'a'][s[i][k]-'a']==1)
		  				{
		  					flag=1;
		  					break;
		  				}
		  				re[s[i][k]-'a'][s[j][k]-'a']=1;
		  				break;
	   	  		    }
	   	  		    else{
	   	  		    	xk=1;
	   	  		    }
		  	    }
		  	    if(flag==1||(xk==1&&strlen(s[i])>strlen(s[j])))
		  	    {
		  	    	book[i]=1;
		  	    	m--;
		  	    	break;
		  	    }
			}
		}	
	}
	printf("%d\n",m);
	for(int i=1;i<=n;i++)   if(book[i]==0)  printf("%s\n",s[i]);
	return 0;
}
