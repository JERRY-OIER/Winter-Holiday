#include<iostream>
#include<cstdio>
#include<vector>
using namespace std;
int n;
int h[100100];
int sum[100100];
int main()
{
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)   scanf("%d",&h[i]);
	sum[1]=h[n];
	int tot=1;
	for(int i=n-1;i>=1;i--)
	{
		if(sum[tot]>=sum[tot-1])  tot++; 
		sum[tot]+=h[i];
	}
	if(sum[tot]<sum[tot-1])  tot--;
	printf("%d\n",tot);
	return 0;
}
