#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int d,n1,n2,c1,c2,tc;
int c[100010],a[100010],cost[100010];
long long sum;
int main()
{
	freopen("toys.in","r",stdin);
	freopen("toys.out","w",stdout);
	scanf("%d%d%d%d%d%d",&d,&n1,&n2,&c1,&c2,&tc);
	for(int i=1;i<=d;i++)    scanf("%d",&a[i]);
	if(c1>=c2)
	{
		swap(c1,c2);
		swap(n1,n2);
	}
	if(c1<=c2&&n1<=n2)
	{
		int c=c1;
		int n=n1;
		for(int i=1;i<=d;i++)
		{
			int x=a[i]-cost[i];
			if(x<0)
			{
				cost[i+1]+=cost[i]-a[i];
				cost[i+n]+=a[i];
			}
			else{
				sum+=(long long) x*tc;
				cost[i+n]+=a[i];
			}
			sum+=c*a[i];
		}
		printf("%lld\n",sum);
	}	
	return 0;
}
