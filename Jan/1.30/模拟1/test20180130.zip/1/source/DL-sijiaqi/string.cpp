#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
//#define ivorysi
#define MAXN 300005
using namespace std;
typedef long long ll;
struct node {
	int to,next,val;
}edge[MAXN * 2];
int head[MAXN],sumedge;
int nodecnt = 1;
bool ed[MAXN],unable[MAXN];
int n;
string str[MAXN];
bool g[30][30];
int instack[30];
void add(int u,int v,int c) {
	edge[++sumedge].to = v;
	edge[sumedge].next = head[u];
	edge[sumedge].val = c;
	head[u] = sumedge;
}
void insert(string s,int id) {
	int len = s.length();
	int p = 1;
	for(int i = 0 ; i < len ; ++i) {
		bool flag = 0;
		for(int j = head[p] ; j ; j = edge[j].next) {
			if(edge[j].val == s[i] - 'a' + 1) {
				p = edge[j].to;
				flag = 1;
				break;
			}
		}
		if(ed[p]) unable[id] = 1;
		if(!flag) {
			add(p,++nodecnt,s[i] - 'a' + 1);
			p = nodecnt;
		}
	}
	ed[p] = 1;
}

bool dfs(int u) {
	instack[u] = 1;
	for(int v = 1 ; v <= 26 ; ++v) {
		if(!g[u][v]) continue;
		if(!instack[v]) {
			if(dfs(v)) return true;
		}
		else if(instack[v] == 1) return true;
	}
	instack[u] = 2;
	return false;
}
bool check(int id) {
	memset(instack,0,sizeof(instack));
	memset(g,0,sizeof(g));
	int len = str[id].length();
	int p = 1;
	for(int i = 0 ; i < len ; ++i) {
		int t;
		for(int j = head[p] ; j ; j = edge[j].next) {
			int w = edge[j].val;
			if(edge[j].val != str[id][i] - 'a' + 1) {
				g[str[id][i] - 'a' + 1][edge[j].val] = 1;
			}
			else t = edge[j].to;
		}
		if(ed[p]) return false;
		p = t;
	}
	for(int i = 1 ; i <= 26 ; ++i) {
		if(!instack[i]) {
			if(dfs(i)) return false;
		}
	}
	return true;
}
int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
#else
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
#endif
	//ios::sync_with_stdio(false);
	scanf("%d",&n);
	for(int i = 1 ; i <= n ; ++i) {
		cin>>str[i];
	}
	for(int i = 1 ; i <= n ; ++i) {
		insert(str[i],i);
	}
	for(int i = 1 ; i <= n ; ++i) {
		if(unable[i]) continue;
		if(!check(i)) unable[i] = 1;
	}
	int ans = 0;
	for(int i = 1; i <= n ; ++i) {
		if(!unable[i]) ans++;
	}
	printf("%d\n",ans);
	for(int i = 1; i <= n ; ++i) {
		if(!unable[i]) cout<<str[i]<<endl; 
	}
	return 0;
}