#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
//#define ivorysi
#define MAXN 100005
using namespace std;
typedef long long ll;
int n,w[MAXN];
ll sta[MAXN];
int top;
int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
#else
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
#endif
	scanf("%d",&n);
	for(int i = 1 ; i <= n ; ++i) {
		scanf("%d",&w[i]);
		if(top > 1 && w[i] > sta[top] && sta[top] + w[i] <= sta[top - 1]) {
			sta[top] += w[i];
			continue;
		}
		while(top > 1) {
			if(sta[top] >= w[i]) break;
			sta[top - 1] += sta[top];
			--top;
			while(top > 1 && sta[top - 1] < sta[top]) {
				sta[top - 1] += sta[top];
				--top;
			}
		}
		if(top!= 0 && sta[top] < w[i]) sta[top] += w[i];
		else sta[++top] = w[i];
	}
	printf("%d\n",top);
	return 0;
}