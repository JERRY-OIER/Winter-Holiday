#include <bits/stdc++.h>
#define MAX_N 100010
#define INF 2147483647
using namespace std;

int N, t1, t2, q1, q2, m;
int x[MAX_N], bit[MAX_N * 2], bit2[MAX_N * 2];
int res;

void add (int i, int x, int op) {
  while (i <= N) {
    op == 1 ? bit[i] += x : bit2[i] += x;
    i += i & -i;
  }
}

int sum (int i, int op) {
  int s = 0;
  while (i > 0) {
    s += op == 1 ? bit[i] : bit2[i];
    i -= i & -i;
  }
  return s;
}

void solvebf () {
  int sum = 0;
  for (int i = 1;i <= N; ++i) sum += x[i];
  printf("%d\n", sum * m);
  exit(0);
}

int main () {
  freopen ("toys.in", "r", stdin);
  freopen ("toys.out", "w", stdout);
  scanf("%d%d%d%d%d%d", &N, &t1, &t2, &q1, &q2, &m);
  for (int i = 1;i <= N; ++i) scanf("%d", x + i);
  if (q1 < q2) {swap(q1, q2); swap(t1, t2);} //q1 > q2
  solvebf();

  res = m * x[1];
  for (int i = 1;i <= N; ++i) {
    /*
    add(N, x[i], 1);
    add(i + t1 - 1, -x[i], 1);
    add(N, x[i], 2);
    add(i + t2 - 1, -x[i], 2);*/
    for (int j = i + t1;j <= N; ++j) bit[j] += x[i];
    for (int j = i + t2;j <= N; ++j) bit2[j] += x[i];
  }

  for (int i = 2;i <= N; ++i) {
    int n1 = bit[i], n2 = bit2[i];
    if (n2 >= x[i]) {
      res += x[i] * t2;
      for (int j = i + 1;j <= N; ++j) bit2[j] -= x[i];
    }
    else if (n2 + n1 >= x[i]) {
      res += n2 * t2 + (x[i] - n2) * t1;
      for (int j = i + 1;j <= N; ++j) bit2[j] -= n2;
      for (int j = i + 1;j <= N; ++j) bit[j] -= (x[i] - n2);
    }
    else {
      res += n2 * t2 + n1 * t1 + (x[i] - n1 - n2) * m;
      for (int j = i + 1;j <= N; ++j) bit2[j] -= n2;
      for (int j = i + 1;j <= N; ++j) bit[j] -= n1;
    }
  }
  printf("%d\n", res);
  return 0;
}
