#include <bits/stdc++.h>
#define MAX_N 100000 + 10
#define INF 2147483647
using namespace std;

int N, x[MAX_N];

int find (int now, int c) {
  int l = now, r = N, mid, ans = -INF;

  while (l <= r) {
    mid = (l + r) >> 1;
    if (x[mid] - x[now] >= c) {r = mid - 1,ans = mid;}
    else l = mid + 1;
  }
  return ans;
}

bool check (int f) {
  f--;
  int c = x[1], cnt = 0, now = 1, now2 = now;
  while (++cnt <= f) {
    now2 = now;
    now = find(now, c);
    if (now == -INF) return false;
    c = x[now] - x[now2];
  }
  return true;
}

int main () {
  freopen ("stack.in", "r", stdin);
  freopen ("stack.out", "w", stdout);
  scanf("%d", &N);
  for (int i = 1;i <= N; ++i) scanf("%d", x + i);
  reverse (x + 1, x + N + 1);

  for (int i = 1;i <= N; ++i) x[i] += x[i - 1];
  int l = 1, r = N, mid, res;
  while (l <= r) {
    mid = (l + r) >> 1;
    if (check(mid)) {l = mid + 1, res = mid;}
    else r = mid - 1;
  }
  printf("%d\n", res);
  return 0;
}
