#include <bits/stdc++.h>
#define MAX_N 30010
#define MAX_L 30010
#define INF 2147483647
using namespace std;
struct answer {
  char s[1000];
  int id;
}ans[MAX_N];
int idx (char c) {return c - 'a';}

int N, len_;
int ch[MAX_L][30], sz = 1;
int book[MAX_N];
int val[30];
char s[MAX_L], res[MAX_L];
int rsl, asl;

void build (int len, int x) {
  int u = 0, c;
  for (int i = 0;i < len; ++i) {
    c = idx(s[i]);
    if (!ch[u][c]) {
      memset(ch[sz], 0, sizeof(ch[sz]));
      ch[u][c] = sz++;
    }
    u = ch[u][c];
  }
  book[u] = x;
}

int min_ (int a, int b) {
  if (a == 0 || b == 0) return max(a, b);
  return min(a, b);
}

void print (int x) {
  memcpy(ans[asl].s, res, rsl);
  ans[asl].id = x;
  asl++;
}

void rebuild (int o) {
  //printf("%d\n", o);
  if (book[o]) {print(book[o]);return;}
  int minn = INF;
  for (int i = 0;i < 26; ++i) {
    if (!ch[o][i]) continue;
    minn = min_(minn, val[i]);
  }
  for (int i = 0;i < 26; ++i) {
    if (!ch[o][i]) continue;
    if (val[i] > minn) continue;
    //printf("%d %c %d\n", o, i + 'a', ch[o][i]);
    res[rsl++] = i + 'a';
    rebuild (ch[o][i]);
    rsl--;
  }
}

bool cmp (const answer a, const answer b) {return a.id < b.id;}
int main () {
  freopen ("string.in", "r", stdin);
  freopen ("string.out", "w", stdout);
  scanf("%d", &N);
  for (int i = 1;i <= N; ++i) {
    scanf("%s", s);
    len_ = strlen(s);
    build (len_, i);
  } 

  for (int i = 0;i < 26; ++i) {
    if (ch[0][i]) val[i] = 2;
  }

  for (int i = 0;i < 26; ++i) {
    if (!ch[0][i]) continue;
    val[i] = 1;
    res[rsl++] = i + 'a';
    rebuild (ch[0][i]);
    val[i] = 2;
    rsl--;
  }

  printf("%d\n", asl);
  sort(ans, ans + asl, cmp);
  for (int i = 0;i < asl; ++i) printf("%s\n", ans[i].s);
  return 0;
}
