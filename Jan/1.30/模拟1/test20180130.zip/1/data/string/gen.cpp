#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
  srand(time(0));
  freopen("temp.in", "w", stdout);
  int N = 10002;
  printf("%d\n", N);
  for (int i = 1; i <= 100000; ++i)
    putchar('a');
  puts("");
  for (int i = 1; i <= 100000; ++i)
    putchar('b');
  puts("");
  for (int i = 1; i <= 10000; ++i) {
    for (int j = 1; j <= 10; ++j)
      putchar('a' + rand() % 26);
    puts("");
  }
  return 0;
}
