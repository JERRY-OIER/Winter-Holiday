#include <cstdio>
#include <string>
#include <cstring>
using namespace std;

int main() {
  int num;
  scanf("%d", &num);
  for (int i = 1; i <= num; ++i) {
    string S = to_string(i) + ".in";
    FILE *f = fopen(S.c_str(), "r");
    int N, len = 0;
    static char s[100005];
    fscanf(f, "%d", &N);
    for (int j = 1; j <= N; ++j) {
      fscanf(f, "%s", &s);
      len += strlen(s);
    }
    
    printf("%d %d %d\n", i, N, len);
    fclose(f);
  }
  return 0;
}
