#include<bits/stdc++.h>
using namespace std;
int a[50010];
int b[50010];
bool used[50010];
int main()
{
	freopen("buy.in","r",stdin);
	freopen("buy.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d %d",&a[i],&b[i]);
	}
	long long ans=0;
	for(int i=1;i<=n;i++)
		if(!used[i])
		{
			int na=a[i],nb=b[i];
			for(int j=i+1;j<=n;j++)
				if(!used[j])
				{
					int ma=max(na,a[j]),mb=max(nb,b[j]);
					if((long long)ma*mb<=(long long)na*nb+(long long)a[j]*b[j])
					{
						used[j]=1;
						na=ma;
						nb=mb;
					}
				}
			ans+=(long long)na*nb;
		}
	printf("%lld\n",ans);
	return 0;
}

