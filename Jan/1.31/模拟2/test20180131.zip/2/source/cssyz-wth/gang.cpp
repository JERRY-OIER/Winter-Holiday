#include<bits/stdc++.h>
using namespace std;
int gang[101];
int fight[101][101];
int main()
{

	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
	int n,m;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d",&gang[i]);
		gang[i]=gang[i]*1000+i;
	}
	sort(gang+2,gang+m+1);
	int now=0;
	for(int i=m;i;i--)
	{
		if(!now)
		{	
			now=gang[i];
			continue;
		}
		int min_=min(gang[i]%1000 , now%1000),max_=max(gang[i]%1000 , now%1000);
		fight[min_][max_]=min(gang[i],now)/1000;
		if(gang[i]/1000>now/1000) now=gang[i]-(now/1000)*1000;
		if(gang[i]/1000==now/1000) now=0;
		if(gang[i]/1000<now/1000) now=now-(gang[i]/1000)*1000;
	}
	if(now%1000!=1) printf("NO\n");
	else
	{
		printf("YES\n%d\n",now/1000);
		for(int i=1;i<=m;i++)
		{
			for(int j=i+1;j<=m;j++)
			{
				for(int k=1;k<=fight[i][j];k++) printf("%d\n",i);
				for(int k=1;k<=fight[i][j];k++) printf("%d\n",j);
			}
		}
		for(int i=1;i<=now/1000;i++) printf("1\n");
	}
				
	return 0;
}
