#include<bits/stdc++.h>
using namespace std;
struct dot
{
	int x;
	int y;
};
struct vec
{
	int x;
	int y;
	vec(int x=0,int y=0):x(x),y(y) {};
};
int n;
dot xy[1001];
int next[1001],last[1001];
int ans;
bool operator < (dot x,dot y)
{
	return x.x==y.x?x.y<y.y:x.x<y.x;
}
int operator * (vec x,vec y)
{
	return (x.x*y.y)-(x.y*y.x);
}
vec operator - (dot x,dot y)
{
	return vec(x.x-y.x , x.y-y.y);
}
void add(int x,int y)
{
	next[x]=y;
	last[y]=x;
}
void insert(vec v1,vec v2,int d,int p,int deep)
{
	if(p>n)
	{
		ans=max(ans , deep);
		return ;
	}
	insert(v1,v2,d,p+1,deep+1);
	vec v3=xy[p]-xy[d];
	if((v1*v2)*(v2*v3)>0)
	{
		add(d,p);
		insert(v2,v3,p,p+1,deep+1);
	}
	return ;
}
int main()
{	
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d %d",&xy[i].x,&xy[i].y);
	}
	sort(xy+1,xy+n+1);
	add(1,2);
	add(2,3);
	insert(xy[2]-xy[1],xy[3]-xy[2],3,4,3);
	printf("%d\n",ans);
	return 0;
}
