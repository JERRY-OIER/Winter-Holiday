#include <bits/stdc++.h>

using namespace std;

int n;

int main() {
	freopen("dot.in", "r", stdin);
	freopen("dot.out", "w", stdout);
	scanf("%d", &n);
	printf("%d\n", n - 2);
	return 0;
}
