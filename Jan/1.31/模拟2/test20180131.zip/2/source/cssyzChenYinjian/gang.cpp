#include <bits/stdc++.h>

using namespace std;

const int N = 100;

int n, m;
int a[N + 1];
int ans[N + 1];
int jsq;
int maxn;
int rest;

int main()
{
	freopen("gang.in", "r", stdin);
	freopen("gang.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= m; i++)
	{
		scanf("%d", &a[i]);
		
		if(a[i] * 2 >= n && i != 1)
		{
			printf("NO\n");
			return 0;
		}
		
		if(i != 1)
		{
			maxn = max(maxn, a[i]);
		}
	}
	
	printf("YES\n");
	if(maxn * 2 > n - a[1])
	{
		rest = n - maxn * 2;
	}
	else
	{
		rest = a[1] - ((n - a[1]) & 1);
	}
	printf("%d\n", rest);
	
	if(m == 2)
	{
		for(int i = 1; i <= n; i++)
			printf("%d\n", i <= a[1] ? 1 : 2);
		return 0;
	}
	
	for(int i = 0; i < rest; i++)
	{
		ans[n - i] = 1;
	}
	a[1] -= rest;
	n -= rest;
	
	jsq = 1;
	for(int i = 1; i <= m; i++) {
		if(!a[i])
		{
			continue;
		}
		for(int j = 1; j <= a[i]; j++)
		{
			ans[jsq] = i;
			jsq++;
		}
		
		for(int j = i + 1; j <= m; j++)
		{
			int num = 0;
			for(int k = i + 1; k <= m; k++)
			{
				if(a[k] > a[num] && k != j)
				{
					num = k;
				}
			}
			int cut = min(a[i], min(a[j], (n - a[num] * 2) >> 1));
			a[i] -= cut;
			a[j] -= cut;
			n -= cut << 1;
			for(int k = 1; k <= cut; k++)
			{
				ans[jsq] = j;
				jsq++;
			}
		}
	}
	
	jsq += rest - 1;
	for(int i = 1; i <= jsq; i++)
	{
		printf("%d\n", ans[i]);
	}
	return 0;
}
