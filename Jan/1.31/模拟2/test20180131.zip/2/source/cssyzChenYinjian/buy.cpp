#include <bits/stdc++.h>

using namespace std;

const int N = 50000;

int n;
long long res;
struct P {
	int a, b, num;
	
	friend bool operator < (P x, P y)
	{
		return x.b > y.b;
	}
	friend P operator - (P x)
	{
		x.a = -x.a; x.b = -x.b;
		return x;
	}
}s[N + 1];

set<P>q;
set<P>::iterator it;

bool cmp(P x, P y) {
	if(x.a != x.b) return x.a < y.a;
	return x.b < y.b;
}

bool pd(P x, P y) {
	long long s1 = min(x.a, y.a) * min(x.b, y.b);
	long long s2 = abs(x.a - y.a) * abs(x.b - y.b);
	if(s1 >= s2) return 1;
	return 0;
}

int main() {
	freopen("buy.in", "r", stdin);
	freopen("buy.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++)
	{
		scanf("%d%d", &s[i].a, &s[i].b);
		s[i].num = i;
	}
	sort(s + 1, s + 1 + n, cmp);
	
	P INF;
	INF.a = 2e9; INF.b = 2e9;
	q.insert(INF);
	for(int i = 1; i <= n; i++)
	{
		bool flag = 1;
		while(flag)
		{
			flag = 0;
			it = q.upper_bound(s[i]);
			while((--it) != q.begin() && (*it).b < s[i].b)
			{
				q.erase(it);
				it = q.upper_bound(s[i]);
			}
			it = q.begin();
			while((++it) != q.end())
			{
				P now = *it;
				if(pd(s[i], now))
				{
					flag = 1;
					q.erase(it);
					it = q.upper_bound(now);
					s[i].a = max(s[i].a, now.a);
					s[i].b = max(s[i].b, now.b);
				}
			}
		}
		q.insert(s[i]);
	}
	it = q.begin();
	while((++it) != q.end())
	{
		P now = *it;
		res += (long long)(now.a * now.b);
	}
	cout << res << endl;
	return 0;
}
