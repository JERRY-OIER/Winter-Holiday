#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#define N 50005
#define INF 0x3f3f3f3f
typedef long long ll;
using namespace std;
ll dp[N],n,q[N],l,r,m;
struct node
{
	ll l,w;
	bool operator < (const node &a)const
	{
		if (l==a.l) return w<a.w;
		return l<a.l;
	}
}g[N],gg[N];
double getD(ll j,ll k)
{
	return 1.0*(dp[j]-dp[k])/(g[k+1].w-g[j+1].w);
}
void Solve2()
{
	for (ll i=1;i<=n;i++)
	{
		while (l<r && getD(q[l],q[l+1])<(double)g[i].l) l++;
		dp[i]=dp[q[l]]+g[q[l]+1].w*g[i].l;
		while (l<r && getD(q[r],i)<getD(q[r-1],q[r])) r--;
		q[++r]=i;
	}
}
int main()
{
	freopen("buy.in","r",stdin);
	freopen("buy.out","w",stdout);
	scanf("%lld",&m);
	for (ll i=1;i<=m;i++)
		scanf("%lld%lld",&gg[i].l,&gg[i].w),dp[i]=INF;
	sort(gg+1,gg+1+m);
	for (ll i=1;i<=m;i++)
	{
		while (n && gg[i].w>=g[n].w) n--;
		g[++n].l=gg[i].l;g[n].w=gg[i].w;
	}
	Solve2();
	printf("%lld\n",dp[n]);
	return 0;
}
/*
4
15 15
100 1
20 5
1 100
*/
