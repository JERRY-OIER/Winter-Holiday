#include<cstdio>
#include<algorithm>
#include<cstring>
#include<stack>
#define N 10005
using namespace std;
int vis[N],QWQ,ans;
struct point
{
    int x,y;
    point (){};
    point (int _x,int _y)
    {
        x=_x,y=_y;
    }
    point operator - (const point &a)const
    {
        return point (x-a.x,y-a.y);
    }
    int operator * (const point &a) const
    {
        return x*a.y-y*a.x;
    }
    int norm()const
    {
        return x*x+y*y;
    }
}p[N],q[N],a[N];
bool cmp(int u,int v)
{
    int det=(p[u]-p[1])*(p[v]-p[1]);
    if (det!=0) return det>0;
    return (p[u]-p[1]).norm() < (p[v]-p[1]).norm();
}
int Graham()
{
	int n=0,m=0;
	for (int i=1;i<=QWQ;i++)
		if (vis[i]) p[++n]=a[i];
	if (n<=2) return 1;
    int id=1;
    for (int i=2;i<=n;i++)
    if (p[i].x<p[id].x || (p[i].x==p[id].x && p[i].y<p[id].y))
        id=i;
   if (id!=1) swap(p[1],p[id]);
    int per[N];
    for (int i=1;i<=n;i++)
    per[i]=i;
 	 sort(per+2,per+1+n,cmp);
    q[++m]=p[1];
    for (int i=2;i<=n;i++)
    {
  		int j=per[i];
    	while (m>=2 && (p[j]-q[m-1])*(q[m]-q[m-1])>=0) m--;
    	q[++m]=p[j];
    }
    return m;
}
void dfs(int x)
{
	if (x>QWQ)
	{
		ans=max(ans,Graham());
		return ;
	}
	dfs(x+1);
	vis[x]=1;
	dfs(x+1);
	vis[x]=0;
}
int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
    scanf("%d",&QWQ);
    if (QWQ<=2) printf("%d\n",QWQ);
    else 
    {
    	for (int i=1;i<=QWQ;i++)
		scanf("%d%d",&a[i].x,&a[i].y);
		if (n<=20)
		{
    		dfs(1);
    		printf("%d",ans);
    	}
    	else printf("%d\n",n/2);
    }
    return 0;
}
/*
6
5 5
2 3
3 2
1 5
5 1
1 1
*/
