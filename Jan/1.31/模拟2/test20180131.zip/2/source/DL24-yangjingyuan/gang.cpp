#include<cstdio>
#include<algorithm>
#include<cstring>
#include<stack>
#define N 105
#define Put(i) printf("%d\n",(i))
using namespace std;
int n,a[N],sum,jj,mx,m,tmp[N],t[N],vis[N],tot,ans,qwq[N];
void check()
{
//	for (int i=1;i<=n;i++)
	//	printf("%d%c",t[i]," \n"[i==n]);
	stack <int> st;
	while (!st.empty()) st.pop();
	for (int i=1;i<=n;i++)
		if (st.empty()) st.push(t[i]);
		else if (st.top()==t[i]) st.push(t[i]);
		else st.pop();
	int res=0;
	while (!st.empty()) res+=(st.top()==1),st.pop();
	if (res>ans)
	{
		for (int i=1;i<=n;i++)
			qwq[i]=t[i];
		ans=res;
	}
}
void dfs(int x)
{
	if (x>n)
		check();
	for (int i=1;i<=n;i++)
		if (!vis[i]) t[x]=tmp[i],vis[i]=1,dfs(x+1),vis[i]=0;
}
int main()
{
	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++)
		scanf("%d",&a[i]),sum+=(i==1)?0:a[i];
	for (int i=2;i<=n;i++)
		if (a[i]>mx) jj=i,mx=a[i];
	if (n<=10)
	{
		for (int i=1;i<=m;i++)
			while (--a[i]>=0) tmp[++tot]=i;
		dfs(1);
		if (ans>0) 
		{
			printf("YES\n%d\n",ans);
			for (int i=1;i<=n;i++)
				printf("%d\n",qwq[i]);
		}
		else puts("NO");
	}
	else puts("NO");
	/*
	if ((sum&1) && a[1]==1)
	{
		puts("NO");
		return 0;
	}
	if (!(sum&1) && mx<=sum/2)
	{
		for (int i=2;i<=n;i++)
		{
			while (a[i]) a[i]--,Put(i);
			for (int j=i+1;j<=n;j++)
				if (a[j]>0)
				{
					if (a[j]==jj)
						while (a[j]) a[j]--,Put(j),sum-=2;
					else
						while (a[j])
						{
							if ((sum-2)/2>=mx) a[j]--,Put(j),sum-=2;
							else Put(jj),a[jj]--,sum-=2;
						}
					break;
				}
		}
	}
	*/
	return 0;
}
/*
5 3
2 1 2
*/
