#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std;
int n, m, book, res;
struct dd {
	int pos, p;
}bp[101];
bool camp(dd a, dd b) {
	return a.p < b.p;
}
bool cmp(dd a, dd b) {
	return a.pos < b.pos;
}
bool camp1(dd a, dd b) {
	return a.p > b.p;
}
int main() {
	freopen ("gang.in", "r", stdin);
	freopen ("gang.out", "w", stdout);
	cin>>n>>m;
	for (int i = 1; i <= m; i++) {
		scanf("%d", &bp[i].p);
		bp[i].pos = i;
	}
	sort(bp + 1, bp + m + 1, camp);
	for (int i = 1; i <= m; i++) {
		if (bp[i].pos == 1) {
			book = i;
			break;
		}
	}
	int flag = 0;
	for (int i = 1; i < m; i++) {
		if (i == book) continue;
		flag += bp[i].p;
	}
	if (flag <= bp[m].p) {
		int mm = bp[m].pos;
		int can = bp[m].p - flag;
		if (can == 0) {
			cout<<"NO\n";
			return 0;
		}
		cout<<"YES\n";
		sort(bp + 1, bp + m + 1, cmp);
		for (int i = 1; i <= bp[1].p - can; i++) printf("1\n");
		for (int i = 1; i <= bp[1].p - can; i++) printf("%d\n", mm);
		for (int i = 2; i <= mm - 1; i++) {
			if (i != mm) {
				for (int j = 1; j <= bp[i].p; i++) {
					printf("%d\n", i);
				}
				for (int j = 1; j <= bp[i].p; i++) {
					printf ("%d\n", mm);
				}
			}
		}
		for (int i = 1;i <= can; i++) {
			printf("1\n");
		}
		return 0;
	}
	res = bp[1].p;
	for (int i = 1; i < book - 1; i++) {
		res = bp[i + 1].p - res;
	}
	res = bp[book + 1].p - bp[book - 1].p;
	for (int i = book + 1; i < m; i++) {
		res = bp[i + 1].p - res;
	}
	sort(bp + 1, bp + m + 1, cmp);
	if (res >= bp[1].p)	 cout<<"NO"<<endl;
	else {
		cout<<"YES"<<endl;
		cout<<bp[1].p - res<<endl;
		for (int i = 1; i <= res; i++) {
			printf("1\n");
		}
		int jsq = 0;
		int now = 2;
		while (jsq < res) {
			if (bp[now].p >= res) {
				bp[now].p -= res - jsq;
				for (int j = 1; j <= res - jsq; j++) {
					printf("%d\n", now);
				}
				jsq = res;
				
			}
			else {
				jsq += bp[now].p;
				for (int j = 1; j <= bp[now].p; j++) {
					printf("%d\n", now);
				}
				bp[now].p = 0;
				now++;
			}
		}
		sort(bp + 1, bp + m + 1, camp1);
		int aa = 2, bb = 0;
		while (bp[aa].p > 0) {
			bb += bp[aa].p;
		}
		if (bb == bp[1].p) {
			for (int i = 2; i < aa ; i++) {
				for (int j = 1; j <= bp[i].p; j++) {
					printf("%d\n", bp[i].pos);
				}
				for (int j = 1; j <= bp[i].p; j++) {
					printf("%d\n", bp[1].pos);
				}
			}
			for (int i = 1; i <= res; i++) {
				printf("1\n");
			}
			return 0;
		}
		else {
			sort(bp + 1, bp + m + 1, cmp);
			for (int i = 1; i <= m; i++) {
				if (bp[i].p && i != 1) {
					for (int j = 1; j <= bp[i].p; j++) {
						printf("%d\n", i);
					}
				}
			}
			for (int i = 1; i <= res; i++) {
				printf("1\n");
			}
			return 0;
		}
	}
	return 0;
}






















