#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <ctime>
using namespace std;
int n;
int main() {
	freopen ("dot.in", "r", stdin);
	freopen ("dot.out", "w", stdout);
	srand(time(0));
	cin>>n;
	for (int i = 1;i <= n; i++) {
		int x, y;
		cin>>x>>y;
	}
	if (n == 3) {
		cout<<3<<endl;
		return 0;
	}
	int a = rand();
	a %= n;
	a++;
	if (a < 3) {
		int b = rand();
		b %= n;
		b += a;
		b %= n;
		cout<<b<<endl;
		return 0;
	}
	else cout<<endl;
	return 0;
}
