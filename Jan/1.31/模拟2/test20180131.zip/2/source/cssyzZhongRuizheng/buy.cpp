#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
int n, l[50001], w[50001];
bool check(int x, int y, int n, int m, int &pd) {
	if (n < 0 && m > 0) {
		pd = 1;
		long long res = x * y;
		long long a = abs(m * n);
		long long b = abs(n * y);
		if (res > a + b) {
			return true;
		}
		else return false;
	}
	if (n > 0 && m < 0) {
		pd = 0;
		long long res = x * y;
		long long a = abs(m * n);
		long long b = abs(m * x);
		if (res > a + b) {
			return true;
		}
		else return false;
	}
}
bool used[50001];
long long ans;
int now = 1;
int cnt;
int main() {
	freopen ("buy.in", "r", stdin);
	freopen ("buy.out", "w", stdout);
	cin>>n;
	for (int i = 1; i <= n; i++) {
		scanf ("%d%d", &l[i], &w[i]);
	}
	while (cnt < n) {
		if (used[now]) {
			now++;
			continue;
		}
		int la = l[now], wa = w[now];
		used[now] = 1;
		cnt++;
		for (int i = now + 1; i <= n; i++) {
			if (!used[i]) {
				if (wa >= w[i] && la >= l[i]) {
					used[i] = 1;
					cnt++;
					continue;
				}
				if (wa <= w[i] && la <= l[i]) {
					used[i] = 1;
					cnt++;
					wa = w[i], la = l[i];
					continue;
				}
				int flag = 0;
				if (check(la, wa, la - l[i], wa - w[i], flag)) {
					if (flag) {
						la = l[i];
						cnt++;
						used[i] = 1;
					}
					else {
						wa = w[i];
						cnt++;
						used[i] = 1;
					}
				}
			}
		}
		ans += la * wa;
	}
	cout<<ans<<endl;
	return 0;
}
