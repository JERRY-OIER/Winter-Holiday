#include<iostream>
#include<cstdio>
using namespace std;
int n;
int max_x,max_y;
int main()
{
	freopen("buy.in","r",stdin);
	freopen("buy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		max_x=max(max_x,x);
		max_y=max(max_y,y);
	}
	long long ans=(long long) max_x*max_y;
	printf("%lld\n",ans);
	return 0;
}
