#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n;
int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
	}
	printf("%d\n",n-1);
	return 0;
}
