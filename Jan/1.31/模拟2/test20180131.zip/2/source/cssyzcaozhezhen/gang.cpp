#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
using namespace std;
struct P{
	int po,num;
}pe[110],work[110];
bool cmp(P a,P b)
{
	return a.po<b.po;	
}
vector<int> v[110];
int re[110][110];
int cnt_x[110][110];
int book[110][110];
int n,m;
int sum[110];
int cnt,ans;
int judge()
{
	if(work[m].po!=0&&work[m-1].po==0)   return 1;
	else if(work[m].po==0&&work[m-1].po==0) return  2;
	else return 0;
}
bool check()
{
	for(int i=1;i<=m;i++)  work[i]=pe[i];
	while(true)
	{
		sort(work+1,work+m+1,cmp);
		if(judge()==1)  return false;
		if(judge()==2)  return true;
		int pos;
		for(int i=1;i<=m;i++)
		  if(work[i].po!=0)
		  {
		  	pos=i;
		  	break;
		  }
		work[pos].po--;
		work[m].po--;
	}
}
void run()
{
	for(int i=1;i<=m;i++)  work[i]=pe[i];
	while(true)
	{
		sort(work+1,work+m+1,cmp);
		if(judge()==1)  break;
		if(judge()==2)  break;
		int pos;
		for(int i=1;i<=m;i++)
		  if(work[i].po!=0)
		  {
		  	pos=i;
		  	break;
		  }
		work[pos].po--;
		work[m].po--;
		if(work[pos].num<work[m].num)  cnt_x[work[pos].num][work[m].num]++;
		else                           cnt_x[work[m].num][work[pos].num]++;
	}	
}
int main()
{
	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)   scanf("%d",&sum[i]);
	for(int i=1;i<=m;i++)   cnt+=sum[i];
	for(int i=1;i<=m;i++)   pe[i].po=sum[i];
	for(int i=1;i<=m;i++)   pe[i].num=i;
	for(int i=0;i<sum[1];i++)
	{
		pe[1].po=i;
		if(check()==true)
		{
			ans=sum[1]-i;
			break;
		}
	}
	if(ans==0)
	{
		printf("NO\n");
		return 0;
	}
	printf("YES\n");
	printf("%d\n",ans);
	pe[1].po=sum[1]-ans;
	run();
	for(int i=1;i<=m;i++)
	{
		int sum=0;
		for(int j=1;j<=m;j++)
		{
			sum+=cnt_x[i][j];
		}
		for(int j=1;j<=sum;j++)   printf("%d\n",i);
		for(int j=1;j<=m;j++)
		  for(int k=1;k<=cnt_x[i][j];k++)   printf("%d\n",j);
	}
	for(int i=1;i<=ans;i++)  printf("%d\n",1);
	return 0;
}
