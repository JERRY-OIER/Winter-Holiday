#include <cstdio>
using namespace std;

int main()
{
	freopen("dot.in", "r", stdin);
	freopen("dot.out", "w", stdout);
	printf("5\n");
	return 0;
}
