#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;

int n, m, maxx, ans;
int a[1010], b[1010], ha[1010], gg[1010];

void dfs(int now)
{
	if(now == n + 1)
	{
		int in = ha[1], num = 1, cnt = 0;
		if(ha[1] == 1)
		    cnt++;
		for(int i = 2; i <= n; i++)
		{
			if(ha[i] != in)
			{
				num--;
				if(cnt)
				    cnt--;
				if(num == 0)
				{
					in = ha[i + 1], num = 1;
					if(in == 1)
					    cnt = 1;
					i++;
					continue;
				}
			}
			else
			{
				num++;
				if(cnt)
				    cnt++;
			}
		}
		if(cnt == ans && gg[1] == 0)
		{
			for(int i = 1; i <= n; i++)
			    gg[i] = ha[i];
		}
		return;
	}
	for(int i = 1; i <= m; i++)
	{
		if(b[i])
		{
			ha[now] = i;
			b[i]--;
			dfs(now + 1);
			b[i]++;
		}
	}
	return;
}

void solve1()
{
	for(int i = 1; i <= m; i++)
	    b[i] = a[i];
	dfs(1);
	printf("%d\n", ans);
	for(int i = 1; i <= n; i++)
	    printf("%d\n", gg[i]);
	return;
}

int main()
{
	freopen("gang.in", "r", stdin);
	freopen("gang.out", "w", stdout);
	int temp, ha, now;
    scanf("%d %d", &n, &m);
    for(int i = 1; i <= m; i++)
    {
    	scanf("%d", &a[i]);
    	b[i] = a[i];
    	maxx = max(maxx, a[i]);
    }
    for(int i = 2; i < m; i++)
    {
        if(b[2] < b[3])
            swap(b[2], b[3]);
        b[2] -= b[3];
        for(int j = 4; j <= m; j++)
            b[j - 1] = b[j];
    }
    ans = b[1] - b[2];
    if(ans <= 0)
    {
    	printf("NO\n");
    	return 0;
    }
    if(n <= 10)
    {
    	solve1();
    	return 0;
	}
    int i;
    for(i = 1; i <= a[1]; i++)
    {
    	for(int j = 1; j <= m; j++)
    	    b[j] = a[j];
    	temp = 0, ha = i, now = 2;
    	b[1] -= i;
    	while(now <= m)
    	{
    		if(ha > b[now])
    		{
    			ha -= b[now];
    			now++;
    		}
    	    b[now] -= ha;
    	    break;
    	}
    	if(ha > 0)
    	    b[1] += ha;
    	for(int j = 2; j < m; j++)
		{
        	if(b[2] < b[3])
            	swap(b[2], b[3]);
        	b[2] -= b[3];
        	for(int k = 4; k <= m; k++)
            	b[k - 1] = b[k];
    	}
    	temp = b[1] - b[2];
    	if(temp < ans)
    	{
    		i--;
    		break;
    	}
    }
    now = 2;
    a[1] -= i;
    printf("YES\n");
    printf("%d\n", ans);
    for(int j = 1; j <= i; j++)
        printf("1\n");
    for(int j = 2; j <= m; j++)
    {
    	while(a[j])
    	{
    		printf("%d\n", j);
    		a[j]--;
    	}
    }
    for(int j = 1; j <= a[1]; j++)
        printf("1\n");
    return 0;
}
