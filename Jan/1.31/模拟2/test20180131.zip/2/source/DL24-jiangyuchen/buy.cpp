#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;

const int inf = 2147483647;
int stl[50005][20], stw[50005][20], dp[1010], er[25];
int n;

struct p{
	int l, w;
}po[50005];

bool cmp(p x, p y)
{
	if(x.l == y.l)
	    return x.w < y.w;
	return x.l < y.l;
}

void init()
{
	int temp = 1;
	for(int i = 0; i <= 20; i++)
	{
		er[i] = temp;
		temp *= 2;
	}
	for(int i = 1; i <= n; i++)
	{
		stl[i][0] = po[i].l;
	    stw[i][0] = po[i].w;
	    dp[i] = inf;
	}
	return;
}

void solve1()
{
	sort(po + 1, po + 1 + n, cmp);
	init();
	int maxx = log2(n);
	for(int i = 1; i <= maxx; i++)
	{
		for(int j = 1; j + er[i] - 1 <= n; j++)
		{
			stl[j][i] = max(stl[j][i - 1], stl[j + er[i - 1]][i - 1]);
			stw[j][i] = max(stw[j][i - 1], stw[j + er[i - 1]][i - 1]);
		}
	}
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= i; j++)
		{
			int len = i - j + 1;
			int ha = log2(len);
			int cost = max(stl[j][ha], stl[i - er[ha] + 1][ha]) * max(stw[j][ha], stw[i - er[ha] + 1][ha]);
			dp[i] = min(dp[i], dp[j - 1] + cost);
		}
	}
	printf("%d\n", dp[n]);
	return;
}

int main()
{
	freopen("buy.in", "r", stdin);
	freopen("buy.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++)
	    scanf("%d %d", &po[i].l, &po[i].w);
	if(n <= 1000)
	    solve1();
	return 0;
}
