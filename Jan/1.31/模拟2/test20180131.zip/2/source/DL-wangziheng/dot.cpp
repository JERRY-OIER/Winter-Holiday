#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=300;
inline int read(){
	int X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
struct point{
	int x,y;
}p[N];
int main(){
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	int n=read();
	for(int i=1;i<=n;i++){
		p[i].x=read(),p[i].y=read();
	}
	printf("5\n");
	return 0;
}
