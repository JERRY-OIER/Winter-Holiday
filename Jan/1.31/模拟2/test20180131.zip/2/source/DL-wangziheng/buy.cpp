#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
typedef long long ll;
const int N=50010;
const int LOGN=18;
const ll INF=1e18;
inline ll read(){
	int X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
struct buy{
	ll l,w;
}b[N];
bool cmp(buy a,buy b){
	return a.l>b.l||(a.l==b.l&&a.w>b.w);
}
ll dp[N],maxl[N][LOGN],maxw[N][LOGN];
int n;
inline int qpow(int k){return 1<<k;};
void st(){
	for(int i=1;i<LOGN;i++){
		for(int j=1;j<=n;j++){
			if(j+qpow(i)-1>n)break;
			maxl[j][i]=max(maxl[j][i-1],maxl[j+qpow(i-1)][i-1]);
			maxw[j][i]=max(maxw[j][i-1],maxw[j+qpow(i-1)][i-1]);
		}
	}
	return;
}
ll f(int l,int r){
	int s=log2(r-l+1);
	ll ansl=max(maxl[l][s],maxl[r-qpow(s)+1][s]);
	ll answ=max(maxw[l][s],maxw[r-qpow(s)+1][s]);
	return ansl*answ;
}
int main(){
	freopen("buy.in","r",stdin);
	freopen("buy.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
		b[i].l=read(),b[i].w=read();
	sort(b+1,b+n+1,cmp);
	for(int i=1;i<=n;i++){
		maxl[i][0]=b[i].l;
		maxw[i][0]=b[i].w;
	}
	st();
	for(int i=1;i<=n;i++){
		dp[i]=INF;
		for(int j=1;j<=i;j++){
			dp[i]=min(dp[i],dp[j-1]+f(j,i));
		}
	}
	printf("%lld\n",dp[n]);
	return 0;
}
