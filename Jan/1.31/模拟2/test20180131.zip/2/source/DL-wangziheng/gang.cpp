#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<queue>
#include<algorithm>
using namespace std;
inline int read(){
	int X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
int a[110],e[110],sum,m;
struct ha{
	int z,id;
}b[110];
struct cmp1{
	bool operator()(int x,int y){
		return a[x]<a[y]||(a[x]==a[y]&&x>y);
	}
};
bool cmp2(ha c,ha d){
	return c.z>d.z||(c.z==d.z&&c.id<d.id);
}
priority_queue<int,vector<int>,cmp1>q;
int main(){
	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
	sum=read(),m=read();
	for(int i=1;i<=m;i++){
		a[i]=b[i].z=e[i]=read();
		b[i].id=i;
		if(i>1)q.push(i);
	}
	while(q.size()>1){
		int t1=q.top();q.pop();
		int t2=q.top();q.pop();
		a[t1]--;a[t2]--;
		if(a[t1])q.push(t1);
		if(a[t2])q.push(t2);
	}
	int ans=0;
	if(!q.empty())ans=a[q.top()];
	ans=a[1]-ans;
	if(ans<=0)puts("NO");
	else{
		puts("YES");
		printf("%d\n",ans);
		b[1].z-=ans;sum-=ans;e[1]-=ans;
		for(int i=1;i<=m;i++){
			if(!e[i])continue;
			for(int j=1;j<=e[i];j++)printf("%d\n",i);
			while(e[i]){
				sort(b+1,b+m+1,cmp2);
				int t=b[1].id;
				if(i!=t){
					if(sum-e[t]<=e[t]){
						printf("%d\n",t);
						e[t]--;e[i]--;sum-=2;
					}else{
						for(int j=i+1;j<=m;j++){
							if(!e[j])continue;
							printf("%d\n",j);
							e[j]--;e[i]--;sum-=2;
							break;
						}
					}
				}
				else{
					for(int j=i+1;j<=m;j++){
						if(!e[j])continue;
						printf("%d\n",j);
						e[j]--;e[i]--;sum-=2;
						break;
					}
				}
				for(int j=1;j<=m;j++){
					b[j].z=e[j];b[j].id=j;
				}
			}
		}
		for(int i=1;i<=ans;i++)puts("1");
	}
	return 0;
}
