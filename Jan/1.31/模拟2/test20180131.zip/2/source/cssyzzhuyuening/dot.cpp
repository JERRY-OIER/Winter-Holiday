#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,ans=0;
int x[300],y[300];
int main()
{
    freopen("dot.in","r",stdin);
    freopen("dot.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;++i)scanf("%d%d",&x[i],&y[i]);
    cout<<n-1<<endl;
    return 0;
}
