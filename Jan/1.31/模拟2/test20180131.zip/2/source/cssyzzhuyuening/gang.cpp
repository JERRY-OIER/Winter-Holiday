#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,num[110],sta[110],xu[110],ansxu[110],tp,ans=-1;
void ser(int x)
{
    if(x>n)
    {
    //for(int i=1;i<=n;++i)cout<<xu[i]<<" ";cout<<"   ";cout<<tp<<" "<<sta[tp]<<endl;
        if(sta[tp]!=1)return;
        if(tp>ans)
        {
            ans=tp;
            for(int i=1;i<=n;++i)ansxu[i]=xu[i];
        }
        else if(tp==ans)
        {
            for(int i=1;i<=n;++i)
            {
                if(xu[i]>ansxu[i])return;
                if(xu[i]<ansxu[i])break;
            }
            for(int i=1;i<=n;++i)ansxu[i]=xu[i];
        }
        return;
    }
    for(int i=1;i<=m;++i)
    {
        if(!num[i])continue;
        int sym,t;
        if(sta[tp]==i||!tp)sta[++tp]=i,sym=0;
        else t=sta[tp],sta[tp]=0,tp--,sym=1;
        xu[x]=i;num[i]--;
        ser(x+1);
        num[i]++;xu[x]=0;
        if(!sym)tp--;
        else tp++,sta[tp]=t;
    }
}
int main()
{
    freopen("gang.in","r",stdin);
    freopen("gang.out","w",stdout);
    scanf("%d%d",&n,&m);
if(n<=12||(n<=20&&m<=3))
{
    for(int i=1;i<=m;++i)scanf("%d",&num[i]);
    ser(1);
    if(ans>0)
    {
        printf("YES\n");
        printf("%d\n",ans);
        for(int i=1;i<=n;++i)
            printf("%d\n",ansxu[i]);
    }
    else cout<<"NO"<<endl;
    return 0;
}
else cout<<"NO"<<endl;
return 0;
}
