#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,ml,mw;
long long ans,tans;
struct data{
    long long l,w,val;
}squ[500100],tsqu[500100]; 
bool cmp(data a,data b)
{
    if(a.l==b.l)return a.w<b.w;
    return a.l<b.l;
}
bool cmp2(data a,data b)
{
    if(a.w==b.w)return a.l<b.l;
    return a.w<b.w;
}
int main()
{
    freopen("buy.in","r",stdin);
    freopen("buy.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;++i)
    {
        scanf("%lld%lld",&squ[i].l,&squ[i].w);
        squ[i].val=squ[i].l*squ[i].w;
        tsqu[i].l=squ[i].l;
        tsqu[i].w=squ[i].w;
        tsqu[i].val=squ[i].val;
    }
    sort(squ+1,squ+n+1,cmp);
    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<i;++j)
        {
            if(!squ[j].val)continue;
            ml=max(squ[i].l,squ[j].l);
            mw=max(squ[i].w,squ[j].w);
            if(squ[i].val+squ[j].val>=ml*mw)
            {
                squ[i].val+=squ[j].val;
                squ[i].l=ml;squ[i].w=mw;
                squ[j].val=squ[j].l=squ[j].w=0;
            }
        }
    }
    for(int i=1;i<=n;++i)
    {
        tans+=squ[i].l*squ[i].w;
        squ[i].l=tsqu[i].l;
        squ[i].w=tsqu[i].w;
        squ[i].val=tsqu[i].val;
    }//cout<<tans<<endl;//fessdffsdfsd
    ans=tans;tans=0;
    sort(squ+1,squ+n+1,cmp2);
    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<i;++j)
        {
            if(!squ[j].val)continue;
            ml=max(squ[i].l,squ[j].l);
            mw=max(squ[i].w,squ[j].w);
            if(squ[i].val+squ[j].val>=ml*mw)
            {
                squ[i].val+=squ[j].val;
                squ[i].l=ml;squ[i].w=mw;
                squ[j].val=squ[j].l=squ[j].w=0;
            }
        }
    }
    for(int i=1;i<=n;++i)
        tans+=squ[i].l*squ[i].w;
    //cout<<tans<<endl;//fsdfsdf
    ans=min(ans,tans);
    printf("%lld\n",ans);
    return 0;
}
