#include<iostream>
#include<cstdio>
#include<queue>
#include<cstring>
#include<cmath>
#define INF 0x7fffffff
using namespace std;
int n,x[251],y[251],ans,cnt;
bool vis[251];
queue<int>nx;
struct{
	int x,y;
	double xl[251];
}dot[251];
bool judge(int x,int y,int z,int last)
{
	if(x==y)
	{return true;}
	for(int i=1;i<=n;i++)
	{
		if(!vis[i]&&(dot[last].xl[z]>dot[z].xl[i]||!last))
		{
			vis[i]=true;
			if(judge(x+1,y,i,z))
			{
				vis[i]=false;
				return true;
			}	
			vis[i]=false;
		}
	}
	return false;
}
int search(int l,int r)
{
	int mid=(l+r+1)>>1;
	if(l==r)
		return l;
	memset(vis,0,sizeof(vis));
	if(judge(0,mid,0,0))
		return search(mid,r);
	else
		return search(l,mid-1);
}
int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;++i)
		scanf("%d%d",&dot[i].x,&dot[i].y);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
		{
			if(dot[j].x-dot[i].x)
				dot[i].xl[j]=(double)abs((dot[j].y-dot[i].y))/(dot[j].x-dot[i].x);
			else
			{
				dot[i].xl[j]=INF;
				if(dot[j].y-dot[i].y<0)
					dot[i].xl[j]=-INF;
			}	
		}	
 	cout<<search(1,n)<<endl;
	return 0;
}
