#include<iostream>
#include<cstdio>
using namespace std;
int n,w[50001],l[50001],MAXw,MAXl;
long long sum,ans;
bool used[50001];
int main()
{
	freopen("buy.in","r",stdin);
	freopen("buy.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		scanf("%d%d",&l[i],&w[i]);
	for(int i=1;i<=n;i++)
	{
		if(used[i])
			continue;
		sum=l[i]*w[i];
		MAXw=w[i];
		MAXl=l[i];
		used[i]=true;
		for(int j=1;j<=n;j++)
		{
			if(used[j])
				continue;
			if(max(MAXw,w[j])*max(MAXl,l[j])<sum+w[j]*l[j])
			{
				MAXw=max(MAXw,w[j]);
				MAXl=max(MAXl,l[j]);
				sum=MAXl*MAXw;
				used[j]=true;
			}
		}
		ans+=sum;
	}
	cout<<ans<<endl;
	return 0;
}
