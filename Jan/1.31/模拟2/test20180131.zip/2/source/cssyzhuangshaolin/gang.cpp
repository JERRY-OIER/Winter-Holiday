#include<iostream>
#include<cstdio>
#include<stack>
using namespace std;
int n,m,b[101],ans[101],MAX,sta[101],top;
stack<int>rem;
void search(int x,int y)
{
	int s=rem.size(),p;
	if(x>y&&s&&rem.top()==1)	
	{
		if(s>MAX)
		{
			MAX=s;
			for(int i=0;i<n;i++)
				ans[i]=sta[i];
		}
		return;
	}	
	for(int i=1;i<=m;i++)
	{
		p=0;
		if(b[i])
		{
			b[i]--;
			sta[top++]=i;
			if(!rem.size()||rem.top()==i)
				rem.push(i);
			else
			{
				p=rem.top();
				rem.pop();
			}	
			search(x+1,y);
			if(!p)
				rem.pop();
			else
				rem.push(p);
			b[i]++;
			top--;
		}
	}
	return;
}
int main()
{
	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	search(1,n);
	if(MAX)
	{
		printf("YES\n%d\n",MAX);
		for(int i=0;i<n;i++)
			printf("%d\n",ans[i]);
	}
	else
		printf("NO\n");
	return 0;
}
