#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
int n,m,a[110];

int main()
{
	freopen("gang.in","w",stdout);
	srand((int)time(0));
	m=rand()%15+1;
	for (int i=1;i<=m;i++) a[i]=rand()%15+1,n+=a[i];
	printf("%d %d\n",n,m);
	for (int i=1;i<=m;i++) printf("%d\n",a[i]);
}
