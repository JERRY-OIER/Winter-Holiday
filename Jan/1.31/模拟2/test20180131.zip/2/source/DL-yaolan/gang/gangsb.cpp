#include<cstdio>
#include<algorithm>
#define N 110
using namespace std;
int b[N],n,m,mx,pos;
struct hhh
{
	int sum,num;
}a[N];

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

int main()
{
	freopen("gang.in","r",stdin);
	//freopen("gang.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=m;i++) 
	{
		a[i].sum=b[i]=read();
		if (i!=1 && b[i]>mx) mx=b[i],pos=i;
	}
	ans=min(b[1]-(n-b[1])&1,n-2*mx);
	if (!b[m])
	{
		printf("YES\n%d\n",b[1]);
		int l=2,r=3;
		while (l<=m)
		{
			while (!a[l].sum && l<=m) l++;
			if (l>m) break;
			a[l].sum--;
			printf("%d\n",l);
		}
		for (int i=1;i<=b[1];i++) printf("%d\n",1);
	}
	else
	{
		if (b[1]<=b[m]) 
		{
			printf("NO\n");
			return 0;
		}
		printf("YES\n%d\n",b[1]-b[m]);
		int l=2,r=3;
		for (int i=1;i<=b[m];i++)
			printf("%d\n",1);
		a[1].sum-=b[m];
		/*
		while (b[m])
		{
			printf("%d\n",pos);
			a[pos].sum--;
			b[m]--;
		}
		*/
		while (l<=m-2)
		{
			while (!a[l].sum && l<=m) l++;
			if (l>m) break;
			a[l].sum--;
			printf("%d\n",l);
		}
		if (a[l+1].sum>a[l].sum)
		{
			for (int i=1;i<=a[l+1].sum-a[l].sum;i++)
				printf("%d\n",l+1);
			a[l+1].sum=a[l].sum;
		}
		for (int i=l;i<=m;i++)
			for (int j=1;j<=a[i].sum;j++)
				printf("%d\n",i);
		for (int i=1;i<=a[1].sum;i++)
			printf("%d\n",1);
	}
	return 0;
}
/*
5 3
2
1
2
*/
