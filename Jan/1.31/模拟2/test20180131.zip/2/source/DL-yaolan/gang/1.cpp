#include <queue>
#include <cstdio>
#include <cstdlib>
#include <iostream>

using namespace std;

const int MAXN=1000010;

int n,m,s[MAXN],ans,mx,rem,p=1;

struct gang{
    int num,id;
    bool operator < (const gang &a)const{
        return num<a.num || num==a.num && id>a.id;
    }
}g[MAXN],now;

priority_queue<gang> Q;

int getint(){
    int v=0; char ch; bool f=0;
    while(!isdigit(ch=getchar())) if(ch=='-') f=1; v=ch-48;
    while(isdigit(ch=getchar())) v=v*10+ch-48; return f?-v:v;
}

int main(){
	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
    n=getint(); m=getint();
    s[1]=getint();
    g[1].num=s[1]; g[1].id=1;
    for(int i=2;i<=m;i++){
        s[i]=getint();
        mx=max(mx,s[i]);
        g[i].num=s[i];
        g[i].id=i;
        Q.push(g[i]);
    }
    ans=min(n-2*mx,s[1]-(n-s[1]&1));s[1]-=ans; n-=ans;
    g[1].num-=ans; Q.push(g[1]);
    if(!ans){puts("NO"); return 0;}
    printf("YES\n%d\n",ans);
    while(n>0){
        while(!s[p]) p++;
        rem=s[p];
        while(s[p]) printf("%d\n",p),s[p]--;
        //gang now;
        while(rem){
            n--;
            while(!Q.empty()){
                now=Q.top(); Q.pop();
                if(now.num!=s[now.id]){
                    now.num=s[now.id];
                    Q.push(now);
                }
                else{
                    Q.push(now);break;
                }
            }
            now=Q.top();Q.pop();
            if(s[now.id]*2>=n){
                s[now.id]--;
                printf("%d\n",now.id);
                now.num--;
            }
            else{
                while(!s[p]) p++;
                s[p]--;
                printf("%d\n",p);
            }
            rem--;n--;Q.push(now);
        }
    }
    while(ans--) puts("1");
    return 0;
}
