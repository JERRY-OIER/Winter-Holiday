#include<cstdio>
#include<algorithm>
#define N 300
using namespace std;
int n,mx,dp[N][N],from[N][N],ans,qwq;
bool vis[N];
struct hhh
{
	int x,y;
	hhh() : x(0),y(0) {}
	hhh(int _x,int _y) : x(_x),y(_y) {}
	hhh operator - (const hhh &b) const
	{
		return hhh(b.x-x,b.y-y);
	}
	int operator * (const hhh &b) const
	{
		return x*b.y-y*b.x;
	}
	int norm()
    {
        return x*x+y*y;
    }
}a[N],p[N],q[N];

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

bool check(int i,int j,int k)
{
	if (!i) return 1;
	return (a[k]-a[i])*(a[j]-a[i])>=0;
}

bool cmp(int u,int v)
{
    int det=(p[u]-p[1])*(p[v]-p[1]);
    if (det!=0) return det>0;
    return (p[u]-p[1]).norm() < (p[v]-p[1]).norm();
}

int Graham()
{
	int n=0,m=0;
	for (int i=1;i<=qwq;i++)
		if (vis[i]) p[++n]=a[i];
	if (n<=2) return 1;
    int id=1;
    for (int i=2;i<=n;i++)
    if (p[i].x<p[id].x || (p[i].x==p[id].x && p[i].y<p[id].y))
        id=i;
   	if (id!=1) swap(p[1],p[id]);
    int per[N];
    for (int i=1;i<=n;i++)
    per[i]=i;
 	sort(per+2,per+1+n,cmp);
    q[++m]=p[1];
    for (int i=2;i<=n;i++)
    {
  		int j=per[i];
    	while (m>=2 && (p[j]-q[m-1])*(q[m]-q[m-1])>=0) m--;
    	q[++m]=p[j];
    }
    return m;
}

void dfs(int x)
{
	if (x>qwq)
	{
		ans=max(ans,Graham());
		return ;
	}
	dfs(x+1);
	vis[x]=1;
	dfs(x+1);
	vis[x]=0;
}

int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++) a[i].x=read(),a[i].y=read();
	if (n<=20)
	{
		qwq=n;
		dfs(1);
    	printf("%d",ans);
    	return 0;
	}
	for (int i=1;i<=n;i++) dp[0][i]=1,from[0][i]=i;
	for (int i=1;i<=n;i++)
		for (int j=i+1;j<=n;j++)
			for (int k=0;k<i;k++)
				if (check(k,i,j) && dp[k][i]+1>dp[i][j])
				{
					dp[i][j]=dp[k][i]+1;
					from[i][j]=from[k][i];
					if (check(i,j,from[k][i])) 
						mx=max(mx,dp[i][j]);
				}
	printf("%d\n",mx);
	return 0;
}
