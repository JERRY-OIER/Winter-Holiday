#include<cstdio>
#include<algorithm>
#define N 50010
typedef long long ll;
using namespace std;
struct hhh
{
	ll x,y;
	bool operator < (const hhh &b) const
	{
		if (x==b.x) return y<b.y;
		return x<b.x;
	}
}a[N];
ll n,tot,x[N],y[N],q[N],f[N],l=1,r;

ll read()
{
	ll ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

ll check(int i,int j)
{
	return 1.0*(f[j]-f[i])/(y[i+1]-y[j+1]);
}

int main()
{
	freopen("buy.in","r",stdin);
	freopen("buy.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++) a[i].x=read(),a[i].y=read();
	sort(a+1,a+n+1);
	for (int i=1;i<=n;i++)
	{
		while (tot && a[i].y>=y[tot]) tot--;
		x[++tot]=a[i].x;
		y[tot]=a[i].y;
	}
	for (int i=1;i<=tot;i++)
	{
		while (l<r && check(q[l],q[l+1])<x[i]) l++;
		f[i]=f[q[l]]+y[q[l]+1]*x[i];
		while (r>l && check(q[r],i)<check(q[r-1],q[r])) r--;
		q[++r]=i;
	}
	printf("%lld\n",f[tot]);
	return 0;
}
/*
4
15 15
100 1
20 5
1 100
*/
