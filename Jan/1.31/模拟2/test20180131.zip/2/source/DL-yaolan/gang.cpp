#include<cstdio>
#include<queue>
#define N 110
using namespace std;
struct hhh
{
	int sum,num;
	bool operator < (const hhh &b) const
	{
		if (sum==b.sum) return num>b.num;
		return sum<b.sum;
	}
}b[N],now;
int n,l=1,m,a[N],mx,ans;
priority_queue <hhh> q;

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

int main()
{
	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=m;i++) 
	{
		a[i]=b[i].sum=read();
		b[i].num=i;
		if (i!=1) mx=max(mx,a[i]);
		if (i!=1) q.push(b[i]);
	}
	ans=min(a[1]-((n-a[1])&1),n-2*mx);
	if (ans<=0)
	{
		printf("NO\n");
		return 0;
	}
	printf("YES\n%d\n",ans);
	n-=ans;
	a[1]-=ans;
	b[1].sum-=ans;
	q.push(b[1]);
	while (n>0)
	{
		while (!a[l]) l++;
		int qwq=a[l];
		n-=qwq;
		while (a[l]) printf("%d\n",l),a[l]--;
		while (qwq--)
		{
			n--;
			while (!q.empty())
			{
				now=q.top();q.pop();
				if (a[now.num]!=now.sum)
				{
					now.sum=a[now.num];
					q.push(now);
				}
				else
				{
					q.push(now);
					break;
				}
			}
			//printf("%d %d\n",now.sum,now.num);
			now=q.top();q.pop();
			if (now.sum*2>=n)
			{
				a[now.num]--;
				now.sum--;
				printf("%d\n",now.num);
			}
			else
			{
				while (!a[l]) l++;
				a[l]--;
				printf("%d\n",l);
			}
			q.push(now);
		}
	}
	while (ans--) printf("1\n");
	return 0;
}
