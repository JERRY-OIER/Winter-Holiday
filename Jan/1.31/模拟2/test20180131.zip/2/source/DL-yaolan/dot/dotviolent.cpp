#include<cstdio>
#include<algorithm>
#include<cstring>
#include<stack>
#define N 10005	
using namespace std;
int vis[N],qwq,ans;
struct hhh
{
    int x,y;
    hhh (){};
    hhh (int _x,int _y)
    {
        x=_x,y=_y;
    }
    hhh operator - (const hhh &a) const
    {
        return hhh (x-a.x,y-a.y);
    }
    int operator * (const hhh &a) const
    {
        return x*a.y-y*a.x;
    }
    int norm()
    {
        return x*x+y*y;
    }
}p[N],q[N],a[N];

bool cmp(int u,int v)
{
    int det=(p[u]-p[1])*(p[v]-p[1]);
    if (det!=0) return det>0;
    return (p[u]-p[1]).norm() < (p[v]-p[1]).norm();
}

int Graham()
{
	int n=0,m=0;
	for (int i=1;i<=qwq;i++)
		if (vis[i]) p[++n]=a[i];
	if (n<=2) return 1;
    int id=1;
    for (int i=2;i<=n;i++)
    if (p[i].x<p[id].x || (p[i].x==p[id].x && p[i].y<p[id].y))
        id=i;
   	if (id!=1) swap(p[1],p[id]);
    int per[N];
    for (int i=1;i<=n;i++)
    per[i]=i;
 	sort(per+2,per+1+n,cmp);
    q[++m]=p[1];
    for (int i=2;i<=n;i++)
    {
  		int j=per[i];
    	while (m>=2 && (p[j]-q[m-1])*(q[m]-q[m-1])>=0) m--;
    	q[++m]=p[j];
    }
    return m;
}

void dfs(int x)
{
	if (x>qwq)
	{
		ans=max(ans,Graham());
		return ;
	}
	dfs(x+1);
	vis[x]=1;
	dfs(x+1);
	vis[x]=0;
}

int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
    scanf("%d",&qwq);
    if (qwq<=2) printf("%d\n",qwq);
    else
    {
    	for (int i=1;i<=qwq;i++)
		scanf("%d%d",&a[i].x,&a[i].y);
    	dfs(1);
    	printf("%d",ans);
    }
    return 0;
}
/*
6
5 5
2 3
3 2
1 5
5 1
1 1
*/
