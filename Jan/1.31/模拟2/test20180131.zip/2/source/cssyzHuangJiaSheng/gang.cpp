#include <bits/stdc++.h>
#define MAX_N 110
#define INF 2147483647
using namespace std;

int N, M;
int num[MAX_N], sum;
int maxx;

int main () {
  freopen ("gang.in", "r", stdin);
  freopen ("gang.out", "w", stdout);
  scanf("%d%d", &N, &M);
  for (int i = 1;i <= M; ++i) scanf("%d", num + i);

  sum = N;
  sum -= num[1];
  for (int i = 2;i <= M; ++i) {
    int ot = sum - num[i];
    if (num[i] > ot) {maxx = i; break;}
  }
  if (num[1] < 2 * num[maxx] - sum) {printf("NO\n");return 0;}
  int nd = max(0, 2 * num[maxx] - sum);
  printf("YES\n");
  if (maxx == 0 && sum % 2 == 1) nd = 1, maxx = 2;
  printf("%d\n", num[1] - nd);
  for (int i = 1;i <= nd; ++i) printf("1\n");
  for (int i = 1;i <= nd; ++i) printf("%d\n", maxx);
  for (int i = 2;i <= M; ++i) {
    if (i == maxx) {
      for (int j = nd + 1;j <= num[i]; ++j) printf("%d\n", i);
    }
    else
      for (int j = 1;j <= num[i]; ++j) printf("%d\n", i);
  }
  for (int i = 1;i <= num[1] - nd; ++i) printf("1\n");
  return 0;
}
