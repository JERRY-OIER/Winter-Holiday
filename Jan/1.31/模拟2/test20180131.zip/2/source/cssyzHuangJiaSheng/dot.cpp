#include <bits/stdc++.h>
#define INF 2147483647
#define MAX_N 250
using namespace std;
struct point {int x, y;}p[MAX_N];

int N;
int stp[MAX_N], spl;
double k;
point sad;
int res1, res2;

double getk (int x1, int y1, int x2, int y2) {return (double)((y1 - y2) / (x1 - x2));}

bool cmp (const point a, const point b) {return a.x == b.x ? a.y < b.y : a.x < b.x;}
int main () {
  freopen ("dot.in", "w", stdin);
  freopen ("dot.out", "r", stdout);
  scanf("%d", &N);
  for (int i = 1;i <= N; ++i) scanf("%d%d", &p[i].x, &p[i].y);

  printf("%d\n", N / int(log(N) / log(2)) + 2);
  return 0;
}
