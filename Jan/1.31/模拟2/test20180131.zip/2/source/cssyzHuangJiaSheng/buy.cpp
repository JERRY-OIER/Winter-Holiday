//一个错误的贪心加上一个错误的优化，预计得分20（如果数据够水的话），我也是实在没有办法了，想不出正解，甚至不知道暴力。
#include <bits/stdc++.h>
#define MAX_N 50010
#define INF 2147483647
using namespace std;
struct square{
  int c, k;
}sq[MAX_N];
int N;
int que[MAX_N], top;

int min_ (int a, int x, int y) {
  if (x == INF) return y;
  int m1 = max(sq[a].c, sq[que[x]].c) * max(sq[a].k, sq[que[x]].k) - sq[a].c * sq[a].k - sq[que[x]].c * sq[que[x]].k;
  int m2 = max(sq[a].c, sq[que[y]].c) * max(sq[a].k, sq[que[y]].k) - sq[a].c * sq[a].k - sq[que[y]].c * sq[que[y]].k;
  return m1 < m2 ? y : x;
}

bool cmp (const square a, const square b) {return abs(a.c - a.k) == abs(b.c - b.k) ? a.c < b.c : abs(a.c - a.k) < abs(b.c - b.k);}
int main () {
  freopen ("buy.in", "r", stdin);
  freopen ("buy.out", "w", stdout);
  scanf("%d", &N);
  for (int i = 1;i <= N; ++i) scanf("%d%d", &sq[i].c, &sq[i].k);
  sort(sq + 1, sq + N + 1, cmp);

  int ans = INF;
  for (int i = 1;i <= N; ++i) {
    ans = INF;
    for (int j = 1;j <= top; ++j) {
      int l = max(sq[i].c, sq[que[j]].c), w = max(sq[i].k, sq[que[j]].k);
      if (l * w <= sq[i].c * sq[i].k + sq[que[j]].c * sq[que[j]].k) ans = min_(i, ans, j);
    }
    if (ans == INF) {
      que[++top] = i;
    }
    else {
      sq[que[ans]].c = max(sq[i].c, sq[que[ans]].c);
      sq[que[ans]].k = max(sq[i].k, sq[que[ans]].k);
    }
  }

  for (int i = 1;i <= top; ++i) printf("%d %d\n", sq[que[i]].c, sq[que[i]].k);

  long long res = 0;
  for (int i = 1;i <= top; ++i) res += sq[que[i]].c * sq[que[i]].k;
  printf("%lld\n", res);
  return 0;
}
