#include <bits/stdc++.h>

using namespace std;
const int MAXN = 50000;

struct Place {
	int x;
	int y;
};

int N;
bool buy[MAXN + 1];
Place p[MAXN + 1];
int minPay = 0x7fffffff;

void DFS(int, int, int, int);

int main() {
	freopen("buy.in", "r", stdin);
	freopen("buy.out", "w", stdout);
	scanf("%d", &N);
	for (int i = 1; i <= N; i++) scanf("%d%d", &p[i].x, &p[i].y);
	if (N <= 5) {
		DFS(0, 0, 0, 0);
		printf("%d\n", minPay);
	}
	else {
		bool ok = false;
		while (!ok) {
			ok = true;
			for (int i = 1; i <= N; i++) {
				int vi = p[i].x * p[i].y;
				if (!vi) continue;
				for (int j = 1; j <= N; j++) {
					if (i == j) continue;
					int vj = p[j].x * p[j].y;
					if (!vj) continue;
					if (vi + vj >= max(p[i].x, p[j].x) * max(p[i].y, p[j].y)) {
						ok = false;
						p[i].x = max(p[i].x, p[j].x);
						p[i].y = max(p[i].y, p[j].y);
						p[j].x = 0;
						p[j].y = 0;
					}
				}
			}
		}
		int ans = 0;
		for (int i = 1; i <= N; i++) ans += p[i].x * p[i].y;
		printf("%d\n", ans);
	}
	return 0;
}

void DFS(int t, int mx, int my, int pay) {
	if (t == N) {
		minPay = min(minPay, pay + mx * my);
		return ;
	}
	if (pay >= minPay) return ;
	if (mx * my != 0) DFS(t, 0, 0, pay + mx * my);
	for (int i = 1; i <= N; i++) {
		if (!buy[i]) {
			buy[i] = true;
			DFS(t + 1, max(mx, p[i].x), max(my, p[i].y), pay);
			buy[i] = false;
		}
	}
}
