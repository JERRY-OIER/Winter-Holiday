#include <bits/stdc++.h>

using namespace std;
const int MAXN = 100;

int n;
int m;
int a[MAXN + 1];
int p[MAXN + 1];
int maxLose = 0;
int ans[MAXN + 1];

void DFS(int);

int main() {
	freopen("gang.in", "r", stdin);
	freopen("gang.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) scanf("%d", &p[i]);
	if (n <= 10) {
		DFS(1);
		if (maxLose) {
			printf("YES\n");
			printf("%d\n", maxLose);
			for (int i = 1; i <= n; i++) printf("%d\n", ans[i]);
		}
		else printf("NO\n");
	}
	return 0;
}

void DFS(int t) {
	if (t == n + 1) {
		int qb = 0;
		int qbn = 0;
		for (int i = 1; i <= n; i++) {
			if (a[i] != qb) {
				if (!qbn) {
					qb = a[i];
					qbn++;
				}
				else qbn--;
			}
			else qbn++;
		}
		if (qb == 1 && qbn > maxLose) {
			maxLose = qbn;
			memset(ans, 0, sizeof(ans));
			for (int i = 1; i <= n; i++) ans[i] = a[i];
		}
		return ;
	}
	for (int i = 1; i <= m; i++) {
		if (p[i]) {
			p[i]--;
			a[t] = i;
			DFS(t + 1);
			p[i]++;
		}
	}
}
