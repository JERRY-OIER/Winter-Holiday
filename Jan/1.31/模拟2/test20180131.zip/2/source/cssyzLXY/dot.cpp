#include <bits/stdc++.h>

using namespace std;
const int MAXN = 250;

int main() {
	freopen("dot.in", "r", stdin);
	freopen("dot.out", "w", stdout);
	srand(time(0));
	int n;
	scanf("%d", &n);
	printf("%d\n", n * (rand() % 5 + 1));
	return 0;
}
