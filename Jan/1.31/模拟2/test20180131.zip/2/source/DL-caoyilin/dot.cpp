#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=105;
struct point 
{
	int x,y;
	bool vis;
	point(){}
	point (int xx,int yy)
	{
		x=xx;y=yy;
	}
	friend inline point operator +(const point &a,const point &b)
	{
		return point(a.x+b.x,a.y+b.y);
	}
	friend inline point operator -(const point &a,const point &b)
	{
		return point(a.x-b.x,a.y-b.y);
	}
	friend inline int operator *(const point &a,const point &b)
	{
		return a.x*b.y-a.y*b.x;
	}
	friend inline bool operator <(const point &a,const point &b)
	{
		if(a.x==b.x) return a.y<b.y;
		return a.x<b.x;
	}
	inline int norm()
	{
		return x*x+y*y;
	}
	inline void read()
	{
		scanf("%d%d",&x,&y);
	}
	inline void write()
	{
		printf("%d %d\n",x,y);
	}
}p[N],P[22];
bool cmp(point u,point v)
{
	int det=(u-p[1])*(v-p[1]);
	return det>0;
}
int n,q[N];
int graham()
{
	int id,qn=0;
	for(int i=1;i<=n;i++) 
		if(!p[i].vis) 
		{
			id=i;
			break;
		}
	for(int i=1;i<=n;i++) if(!p[i].vis&&p[i]<p[id]) id=i;
	if(id!=1)swap(p[1],p[id]);
	sort(p+2,p+n+1,cmp);
	q[++qn]=1;
	for(int i=2;i<=n;i++)
	{
		if(p[i].vis) continue;
		while(qn>=2 && (p[i]-p[q[qn-1]])*(p[q[qn]]-p[q[qn-1]])>=0)qn--;
		q[++qn]=i;
	}
	return qn;
}
bool relax(int a,int &b)
{
	if(a>b)
	{
		b=a;
		return 1;
	}
	return 0;
}
void solve()
{
	int qr=graham();
	bool ok=1;
//	for(int i=1;i<=qr;i++)Q[i]=q[i];
	while(ok)
	{
	ok=0;		
	for(int i=1;i<=qr;i++)
	{
		p[q[i]].vis=1;
		if(relax(graham(),qr)) ok=1; 
		else p[q[i]].vis=0;
	}
}
//	printf("point 1:");for(int i=1;i<=qr;i++) 
	printf("%d\n",qr);
}
void solve1()
{
	int ans=0,id=1;
	for(int i=1;i<=n;i++) P[i]=p[i];
	for(int i=1,ok,cnt;i<(1<<n);i++)
	{
		for(int j=1;j<=n;j++)p[i]=P[i];
		for(int j=0;j<n;j++)
		{
			p[j+1].vis=0;
			if(!(i&(1<<j))) p[j+1].vis=1;
		}
		ans=max(ans,graham());
	}
	printf("%d\n",ans);
}
int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) p[i].read();
	if(n<=20) solve1();
	else	solve();
	return 0;
}
/*
6
5 5
2 3
3 2
1 5
5 1
1 1
*/
