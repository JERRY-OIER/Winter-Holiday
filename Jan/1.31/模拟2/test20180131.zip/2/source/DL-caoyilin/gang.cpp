#include<cstdio>
using namespace std;
const int N=105;
int n,m,p;
int a[N];
int check(int x)
{
	int ret=0,maxn=-1;
	for(int i=x;i<=m;i++) if(a[i]>maxn) ret=i,maxn=a[i];
	return ret;
}
void solve()
{
	a[0]=-100000;
	int rest=0,t=2-(n&1),now=2,qwq=n;
	puts("YES");
	printf("%d\n",t);
	for(int i=1;i<=a[1]-t;i++) printf("1\n");
	rest=a[1]-t;
	bool qaq=0;
	p=check(2);
//	printf("here%d\n",p);
	while(now<=m)
	{
		if(now==p) p=check(now+1);
		qaq=0;
		while(a[now])
		{
			if(rest==0) qaq=1;
			if(!qaq) while (a[p]>=(qwq-2)/2 && rest && a[p]>0 &&qwq>=2) printf("%d\n",p),a[p]--,rest--,qwq-=2;
			if(rest==0) qaq=1; 
			if(qaq)rest++;
			else rest--,qwq-=2;
			a[now]--;
			printf("%d\n",now);
		}
		now++;
	}
	for(int i=1;i<=t;i++) printf("%d\n",1);
}
int main()
{
	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
	scanf("%d%d",&n,&m);
	int pp=0;
	for(int i=1;i<=m;i++) 
	{
		scanf("%d",&a[i]);
		if(a[i]>n/2) p=i;
		if((!(n&1))&&a[i]==n/2) pp=i;
	}
	if(pp!=1&&pp!=0){puts("NO");return 0;}
	if(a[1]==1&&!(n&1))
	{
		puts("NO");
		return 0;
	}
	if(p)
	{
		if(p!=1) puts("NO");
		else
		{
			puts("YES");
			printf("%d\n",2*a[1]-n);
			for(int i=1;i<=m;i++)
			for(int j=1;j<=a[i];j++)
			printf("%d\n",i);
		}
		return 0;
	}
	solve();
	return 0;
}
/*
5 3 2 1 2
*/
