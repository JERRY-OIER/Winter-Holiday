#include<cstdio>
#include<algorithm>
#define fi first
#define se second
using namespace std;
const int N=50005;
typedef pair<int,int> pii;
typedef long long ll;
const ll inf=(1e13);
pii a[N];
ll dp[N];
int n;
int st[1102][12],lg[N];
ll get_max(int l,int r)
{
	if(l>r) swap(l,r);
	int L=lg[r-l+1];
	return max(st[l][L],st[r-(1<<L)+1][L]);
}
void init()
{
	for(int i=1;i*2<=n;i*=2) lg[i*2]=lg[i]+1;
	for(int i=3;i<=n;i++) if(!lg[i]) lg[i]=lg[i-1];
}
void solve1()
{
	init();
	for(int i=1;i<=n;i++) st[i][0]=a[i].se;
	for(int j=1;j<=n;j++)
		for(int i=1;i+(1<<j)-1<=n;i++)
			st[i][j]=max(st[i][j-1],st[i+(1<<j-1)][j-1]);
	for(int i=1;i<=n;i++) 
	{
		dp[i]=inf;
		for(int j=1;j<=i;j++)dp[i]=min(dp[i],dp[j-1]+get_max(j,i)*a[i].fi);
	}
	//for(int i=1;i<=n;i++) printf("%lld\n",dp[i]);
	printf("%lld\n",dp[n]);
}
void solve2()
{
	static int que[N],ql=1,qr=0;
	for(int i=1;i<=n;i++)
	{
		dp[i]=inf;
		while(ql<=qr&&a[que[qr]].se<a[i].se) qr--;
//		while(ql<qr&&dp[que[ql-1]]+a[i].fi*a[que[ql]].se>=dp[que[ql]]+a[i].fi*a[que[ql+1]].se) ql++;		
		que[++qr]=i;
		if(ql==qr) dp[i]=a[i].fi*a[i].se;
//		printf("??%d:",i);for(int j=ql;j<=qr;j++) printf("%d%c",que[j]," \n"[j==qr]);
		for(int j=ql;j<=qr;j++) dp[i]=min(dp[i],dp[que[j-1]]+a[i].fi*a[que[j]].se);
	}
//	for(int i=1;i<=n;i++) printf("%d:%lld\n",i,dp[i]);
	printf("%lld\n",dp[n]);
}

int main()
{
	freopen("buy.in","r",stdin);	freopen("buy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d%d",&a[i].fi,&a[i].se);
	sort(a+1,a+n+1);
//	for(int i=1;i<=n;i++) printf("!%d %d\n",a[i].fi,a[i].se);
	if(n<=1000)solve1();else 
	solve2();
	return 0;
}
/*
5
1 1
2 2
3 3
750 750
500 1000
4
15 15
100 1
20 5
1 100
7
2002 2002
6 6
2 1
73 64 
52 38
94 99
87 135
7
75 22
86 96
135 192
732 3147
2333 546
12 10000
22 23
*/
