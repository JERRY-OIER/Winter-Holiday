#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
//#define ivorysi
#define MAXN 50005
using namespace std;
typedef long long ll;
int n;
struct Point {
	ll x,y;
	Point() {};
	Point(ll _x,ll _y) {
		x = _x;y = _y;
	}
	friend Point operator + (const Point &a,const Point &b) {
		return Point(a.x + b.x,a.y + b.y);
	}
	friend Point operator - (const Point &a,const Point &b) {
		return Point(a.x - b.x,a.y - b.y);
	}
	friend ll operator * (const Point &a,const Point &b) {
		return a.x * b.y - a.y * b.x;
	} 
}poi[305],now[305];
int que[305];
int tot,ans,qr,ql;
bool cmp(Point a,Point b) {
	return (a - now[1]) * (b - now[1]) >= 0;
}
int calc(int t) {
	que[ql = qr = 1] = 1;
	for(int i = 2 ; i <= tot ; ++i) {
		while(qr > ql && que[qr] != t 
			&& (now[i] - now[que[qr - 1]]) * (now[que[qr]] - now[que[qr - 1]]) >= 0) --qr;
		if((now[i] - now[que[qr - 1]]) * (now[que[qr]] - now[que[qr - 1]]) <= 0) que[++qr] = i;
	}
	return qr;
}
int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
#else
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
#endif
	scanf("%d",&n);
	for(int i = 1 ; i <= n ; ++i) {
		scanf("%lld%lld",&poi[i].x,&poi[i].y);
	}
	ans = 3;
	for(int i = 1 ; i <= n ; ++i) {
		tot = 1;
		now[1] = poi[i];
		for(int j = 1; j <= n ; ++j) {
			if(j != i) {
				if(poi[j].x <= poi[i].x && poi[j].y <= poi[i].y) continue;
				now[++tot] = poi[j];
			}
		}
		sort(now + 2,now + tot + 1,cmp);
		for(int k = 2 ; k <= tot ; ++k) {
			ans = max(ans,calc(k));
		}
	}
	printf("%d\n",ans);
	return 0;
}
