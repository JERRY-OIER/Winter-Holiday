#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
//#define ivorysi
#define MAXN 50005
using namespace std;
typedef long long ll;
int num[105],n,m;
int line[15],ans,ansline[15];
void dfs(int dep) {
	if(dep > n) {
		int np = 0,pos = 0;
		for(int i = 1 ; i <= n ; ++i) {
			if(pos == 0 || pos == line[i]) {
				pos = line[i];
				++np;
			}
			else {
				--np;
				if(!np) pos = 0;
			}
		}
		if(pos == 1) {
			if(np > ans) {
				ans = np;
				memcpy(ansline,line,sizeof(line));
			}
			else if(np == ans) {
				for(int i = 1 ; i <= n ; ++i) {
					if(ansline[i] != line[i]) {
						if(line[i] < ansline[i]) {
							memcpy(ansline,line,sizeof(line));
						}
						else break;
					}
				}
			} 
		}
		return;
	}
	for(int i = 1 ; i <= m ; ++i) {
		if(num[i]) {
			num[i]--;
			line[dep] = i;
			dfs(dep + 1);
			num[i]++;
		}
	}
}
int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
#else
	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
#endif
	scanf("%d%d",&n,&m);
	for(int i = 1 ; i <= m ; ++i) {
		scanf("%d",&num[i]);
	}
	if(n <= 10) {
		dfs(1);
		if(ans > 0) {
			puts("YES");
			printf("%d\n",ans);
			for(int i = 1 ; i <= n ; ++i) {
				printf("%d\n",ansline[i]);
			}
		}
		else {
			puts("NO");
		}
	}
	else {
		puts("NO");
	}
	return 0;
}
