#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
//#define ivorysi
#define MAXN 50005
using namespace std;
typedef long long ll;
struct node {
	int l,w;
}poi[MAXN],np[MAXN];
int n,tot;
ll X[MAXN],Y[MAXN];
int que[MAXN],ql,qr;
ll dp[MAXN];
bool cmp(node a,node b) {
	return a.l < b.l || (a.l == b.l && a.w < b.w);
}
ll calc(int from,int to) {
	return 1LL * np[to].l * X[from] + Y[from];
}
bool check(int s,int q,int cer) {
	return 1LL * (X[q] - X[cer]) * (Y[s] - Y[cer]) - 1LL * (X[s] - X[cer]) * (Y[q] - Y[cer]) >= 0;
}
int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
#else
	freopen("buy.in","r",stdin);
	freopen("buy.out","w",stdout);
#endif
	scanf("%d",&n);
	for(int i = 1 ; i <= n ; ++i) {
		scanf("%d%d",&poi[i].l,&poi[i].w);
	}
	sort(poi + 1, poi + n + 1,cmp);
	for(int i = 1 ; i <= n ; ++i) {
		if(tot == 0) np[++tot] = poi[i];
		else {
			while(tot >= 1 && poi[i].w >= np[tot].w) {
				--tot;
			}
			np[++tot] = poi[i];
		}
	}
	que[ql = qr = 1] = 0;
	X[0] = np[1].w;
	for(int i = 1 ; i <= tot ; ++i) {
		while(ql < qr && calc(que[ql + 1],i) < calc(que[ql],i)) ++ql;
		dp[i] = calc(que[ql],i);
		X[i] = np[i + 1].w,Y[i] = dp[i];
		while(ql < qr && check(i,que[qr],que[qr - 1])) --qr;
		que[++qr] = i;
	}
	printf("%lld\n",dp[tot]);
	return 0;
}
