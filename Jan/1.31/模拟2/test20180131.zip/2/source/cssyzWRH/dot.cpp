#include <cstdio>

using namespace std;

int n;

struct tu {
    int x;
    int y;
}hhw[255];

int main() {
    scanf("%d", &n);
    for(int i = 1; i <= n; i++) {
	scanf("%d%d", &hhw[i].x, &hhw[i].y);
    }
    if(n < 7)
	printf("%d\n", n);
    else
	printf("%d\n", n / 7 * 5);
    return 0;
}
