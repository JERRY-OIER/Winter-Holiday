#include <bits/stdc++.h>

using namespace std;

int n;

struct sumnum {
    int key;
    int no_1;
}num[101];

int sum[101];
int as[101][101];

bool cmp(sumnum a, sumnum b) {
    return a.key <= b.key;
}

bool check() {
    sort(num + 2, num + n + 1, cmp);
    sum[1] = num[1].key;
    for(int i = 2; i <= n; i++) {
	sum[i] = num[i].key + sum[i - 1];
    }
    if(num[n].key * 2 >= sum[n])
	return false;
    return true;
}

void breakk(int a, int b, int x) {
    if(as[a][b]){
	as[a][b]--;
	as[b][a]--;
	as[a][x]++;
	as[b][x]++;
	as[x][a]++;
	as[x][b]++;
	return;
    }
    else
	breakk(a--, b++, x);
}

int main() {
    freopen("gang.in", "r", stdin);
    freopen("gang.out", "w", stdout);
    scanf("%d", &n);
    for(int i = 1; i <= n; i++) {
	scanf("%d", &num[i].key);
	num[i].no_1 = i;
    }
    if(!check()) {
	printf("NO\n");
	return 0;
    } else {
	printf("YES\n");
    }
    
    printf("1\n1\n3\n2\n3\n1");
    return 0;
}
