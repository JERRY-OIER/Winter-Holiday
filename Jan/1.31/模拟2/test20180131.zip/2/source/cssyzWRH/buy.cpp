#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>

using namespace std;

int n;

struct qq {
    int x, y;
}a[51000], b[51000];

int f[51000];

bool cmp(qq x, qq y) {
    if(x.x == y.x)
	return x.y > y.y;
    else
	return x.x > y.x;
}

int mmin(int x, int y) {
    return x < y ? x : y;
}

int main() { 
    freopen("buy.in", "r", stdin);
    freopen("buy.out", "w", stdout);
    
    for(int i = 0; i < 51000; i++) {
	f[i] = 2147483627;
    }
    
    scanf("%d", &n);
    for(int i = 1; i <= n; i++) {
	scanf("%d%d", &a[i].x, &a[i].y);
    }

    sort(a + 1, a + n + 1, cmp);
    int len = 0;
    for(int i = 1; i <= n; i++) {
	if(len == 0 || a[i].y > b[len].y) {
	    len++;
	    b[len].x = a[i].x;
	    b[len].y = a[i].y;
	}
    }
    f[1] = b[1].x * b[1].y;
    for(int i = 1; i <= len; i++) {
	for(int j = 1; j < i; j++) {
	    f[i] = mmin(f[i], f[j] + b[j + 1].x * b[i].y);
	}
    }
    printf("%d\n",f[len]);
    return 0;
}
