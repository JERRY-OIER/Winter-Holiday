#include <iostream>
#include <cstdio>
using namespace std;
int n, m;
int sum[200];
int maxsum = 0, maxi;
int pdg[200][200], bp[200];

void pd() {
	for (int i = 2; i < m; ++i) {
		if (bp[i] == sum[i]) continue;
		for (int j = i + 1; j <= m; ++j) {
			while (bp[j] < sum[j] && bp[i] < sum[i]) {
				bp[j]++;
				bp[i]++;
				pdg[i][j]++;
			}
		}
	}
	
	if (bp[m] == sum[m]) return ;
	for (int i = m - 1; i >= 2; --i) {
		for (int j = i - 1; j >= 2; --j) {
			while (pdg[j][i] && bp[m] < sum[m]) {
				pdg[j][i]--;
				pdg[j][m]++;
				pdg[i][m]++;
				bp[m] += 2;
			}
		}
	}
	return ; 
}


int main() {
	freopen("gang.in", "r", stdin);
	freopen("gang.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; ++i) {
		scanf("%d", &sum[i]);
		if (i != 1) {
			if (sum[i] > maxsum) {
				maxsum = sum[i];
				maxi = i;
			}
		}
	}
	if (2 * maxsum + sum[1] - n >= sum[1]) {
		cout << "NO";
		return 0;
	}
	cout << "YES\n";
	int tmp = 2 * maxsum + sum[1] - n;
	if (tmp >= 0) {
		sum[1] -= tmp;
		printf("%d\n", sum[1]);
		for (int i = 1; i <= tmp; ++i) {
			printf("1\n");
		}
		for (int i = 1; i <= tmp; ++i) {
			printf("%d\n", maxi);
			sum[maxi]--;
		}
		for (int i = 2; i <= m; ++i) {
			if (i == maxi) {
				for (int j = 1; j <= sum[maxi]; ++j) {
					printf("%d\n", i);
				}
			} else if (i < maxi) {
				for (int j = 1; j <= sum[i]; ++j) {
					printf("%d\n", i);
				}
				for (int j = 1; j <= sum[i]; ++j) {
					printf("%d\n", maxi);
				}
				sum[maxi]-= sum[i];
			} else {
				for (int j = 1; j <= sum[i]; ++j) {
					printf("%d\n", i);
				}
			}
		}
		for (int i = 1; i <= sum[1]; ++i) {
			printf("1\n");
		}
		return 0;
	}
	int b = 0;
	if (-tmp % 2 == 1) {
		sum[1]--;
		b = 1;
		tmp++;
	} 
	printf("%d\n", sum[1]);
	if (b) {
		printf("1\n2\n");
		sum[2]--;
	}
	
	pd();
	
	for (int i = 2; i <= m; ++i) {
		if (!sum[i]) continue ;
		for (int j = 1; j <= sum[i]; ++j) {
			printf("%d\n", i);
		}
		for (int j = i + 1; j <= m; ++j) {
			for (int k = 1; k <= pdg[i][j]; ++k) {
				printf("%d\n", j);
				sum[j]--;
			}
		}
	}
	
	for (int i = 1; i <= sum[1]; ++i) {
		printf("1\n");
	}
	return 0;
	
}

/*
5 3
2
1
2
*/
