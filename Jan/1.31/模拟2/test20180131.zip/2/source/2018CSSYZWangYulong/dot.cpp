#include <iostream>
#include <cstdio>
using namespace std;
int main() {
	freopen("dot.in", "r", stdin);
	freopen("dot.out", "w", stdout);
	int n;
	scanf("%d", &n);
	printf("%d", n  * 2 / 3 + 1);
	return 0;
}
