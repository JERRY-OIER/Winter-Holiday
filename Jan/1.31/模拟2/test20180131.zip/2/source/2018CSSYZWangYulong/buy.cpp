#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
int n;

struct P {
	long long L,
			  W;
} p[50004];

bool cmp (P a, P b) {
	if (a.L == b.L) return a.W < b.W;
	return a.L < b.L;
}

bool cmp2 (P a, P b) {
	return a.L > b.L;
}

int main() {
	freopen("buy.in", "r", stdin);
	freopen("buy.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		scanf("%lld%lld", &p[i].L, &p[i].W);
	}
	sort(p + 1, p + 1 + n, cmp);
	long long maxW = 0;
	for (int i = n; i >= 1; --i) {
		if (maxW >= p[i].W) {
			p[i].L = 0;
			p[i].W = 0;
		}
		maxW = max(maxW, p[i].W);
	}
	sort(p + 1, p + 1 + n, cmp2);
	for (int i = 1; i <= n; ++i) {
		if (p[i].L == 0) n = i - 1;
	}
	/*for (int i = 1; i <= n; ++i) {
		printf("%lld %lld\n", p[i].L, p[i].W);
	}*/
	long long ans = 0, tmplw = p[1].W * p[1].L, tmpw = p[1].W, tmpl = p[1].L;
	for (int i = 2; i <= n; ++i) {
		//cout << max(p[i].L, tmpl) * max(p[i].W, tmpw) << " ";
		//cout << tmplw + p[i].L * p[i].W << endl;
		if (max(p[i].L, tmpl) * max(p[i].W, tmpw) <= tmplw + p[i].L * p[i].W) {
			tmplw = max(p[i].L, tmpl) * max(p[i].W, tmpw);
			tmpl = max(p[i].L, tmpl);
			tmpw = max(p[i].W, tmpw);
		} 
		else {
			//cout << i;
			//printf(" %lld\n", tmplw);
			ans += tmplw;
			tmpw = p[i].W;
			tmpl = p[i].L;
			tmplw = p[i].L * p[i].W;
		}
	}
	ans += tmplw;
	printf("%lld", ans);
	return 0;
}


/*
4
15 15
100 1
20 5
1 100

*/
