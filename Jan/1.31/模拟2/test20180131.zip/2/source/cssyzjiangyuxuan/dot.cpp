#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,cnt,q[1010];
struct d
{
	int x,y;
}a[1001];
bool cmp(d u,d v){return u.x<v.x||u.x==v.x&&u.y<v.y;}
double k(int u,int v)
{ return (a[u].y-a[v].y)/(a[u].x-a[v].x);}
int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&a[i].x,&a[i].y);
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		while(cnt>1&&k(i,q[cnt])<k(q[cnt],q[cnt-1])) cnt--;
		q[++cnt]=i;
	}
	int m=cnt;
	for(int i=n-1;i;i--)
	{
		while(cnt>m+1&&k(i,q[cnt])<k(q[cnt],q[cnt-1])) cnt--;
		q[++cnt]=i;
	}
	printf("%d",cnt);
	return 0;
}
		
