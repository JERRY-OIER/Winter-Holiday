#include<iostream>
#include<cstdio>
using namespace std;
int n,m,a[110],k,an,nd;
int main()
{
	freopen("gang.in","r",stdin);
	freopen("gang.out","w",stdout);
	scanf("%d%d",&n,&m);
	scanf("%d",&a[1]);
	int k=n-a[1];
	for(int i=2;i<=m;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]>=(n+1)/2)
		{
			printf("NO\n");
			return 0;
		}
		if(2*a[i]-n+a[1]>0)
		{
			an=n-2*a[i];
			nd=i;
		}
	}
	printf("YES\n");
	if(nd)
	 printf("%d\n",an+((k-an)%2==0?0:1));
	else 
	 printf("%d\n",a[1]-(k%2==0 ? 0 :1));
	if(nd)
	{
		if((k-an)%2) printf("1\n");
		for(int i=1;i<=an;i++)
		printf("1\n");
		for(int i=1;i<=an;i++)
		printf("%d\n",nd);
		if((k-an)%2) printf("2\n"),a[2]--,a[1]--;
		a[nd]-=an;k-=an;
		a[1]-=an;
	}
	else if(k%2==1)
	{
		printf("1\n");
		int q=2;
		while(!a[q])q++;
		printf("%d\n",q);
		a[1]--;a[q]--;k--;
	}
	for(int i=2;i<=m;i++)
	{
		for(int j=1;j<=a[i];j++)
		printf("%d\n",i);
		k-=2*a[i];
		int d=0;
		for(int j=i;j<=m;j++)
		if(a[j]>a[d]) d=j;
		int q=i+1,num=a[i];
		while(num)
		{
			if(a[q]==0)
			 q++,i++;
			if(nd>q&&a[d]>=(k+2*num)/2)
			{
				num--;
				printf("%d\n",d);
				a[d]--;
			}
			else 
			{
				printf("%d\n",q);
				a[q]--;num--;
			}
		}
	}
	for(int i=1;i<=a[1];i++)
	printf("1\n");
	return 0;
}
				
		
//	for(int i=m;i>2;i--)
//	ma[i]=max(a[i],ma[i+1]);
	
		
		

