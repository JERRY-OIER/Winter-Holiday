#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
int n,d[101010];
ll ans,x[101010],y[101010];
int main()
{
	freopen("buy.in","r",stdin);
	freopen("buy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%lld%lld",&x[i],&y[i]);
	for(int i=1;i<=n;i++)
	{
		if(d[i]) continue;
		for(int j=i+1;j<=n;j++)
		{
			if((ll)max(x[i],x[j])*max(y[i],y[j])<=(ll)x[i]*y[i]+(ll)x[j]*y[j])
			{
				x[i]=max(x[i],x[j]);y[i]=max(y[i],y[j]);
				d[j]=i;
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(!d[i])
		 ans+=(ll)x[i]*y[i];
	}
	printf("%lld\n",ans);
	return 0;
}
			
