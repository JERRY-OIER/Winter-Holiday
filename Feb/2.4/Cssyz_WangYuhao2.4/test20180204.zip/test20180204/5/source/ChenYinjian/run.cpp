#include <bits/stdc++.h>

using namespace std;

const int N = 20;

int n, m, k;
int s[N][10];
bool choose[N];

void print() {
	for(int i = 1; i <= n; i++)
		printf("%c", choose[i] ? 'T' : 'B');
}

bool ss(int num, int pos) {
	if(num == n) {
		if((m - pos) % m <= k) return 1;
		return 0;
	}
	bool flag;
	num++;
	choose[num] = 0;
	flag  = ss(num, (long long)(pos * s[num][5] + s[num][6]) % m);
	flag &= ss(num, (long long)(pos * s[num][7] + s[num][8]) % m);
	if(flag) return 1;
	choose[num] = 1;
	flag  = ss(num, (long long)(pos * s[num][1] + s[num][2]) % m);
	flag &= ss(num, (long long)(pos * s[num][3] + s[num][4]) % m);
	if(flag) return 1;
	return 0;
}

int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	char sss[100]; scanf("%s", sss);
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= 8; j++)
			scanf("%d", &s[i][j]);
	ss(0, 0);
	print();
	return 0;
}
