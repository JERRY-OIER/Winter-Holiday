#include <bits/stdc++.h>

using namespace std;

const int N = 40000;

int n;
int tot;
int res;
int dis[N + 1];
int fi[N + 1];
int ne[N + 1];
int to[N + 1];

void add(int, int);
void dfs(int, int, int, int);

int main() {
	freopen("bracket.in", "r", stdin);
	freopen("bracket.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 2; i <= n; i++) {
		int a;
		scanf("%d", &a);
		add(a, i);
	}
	for(int i = 1; i <= n; i++) {
		char ch = 0;
		while(ch != '(' && ch != ')') scanf("%c", &ch);
		dis[i] = (ch == '(' ? 1 : -1);
	}
	dfs(1, 0, 0, 0);
	printf("%d\n", res);
	return 0;
}

void add(int u, int v) {
	tot++;
	ne[tot] = fi[u];
	fi[u] = tot;
	to[tot] = v;
}

void dfs(int k, int sum, int z, int maxn) {
	int s1 = sum;
	sum += dis[k];
	if(s1 > 0 && !sum && z) res = max(res, maxn);
	if(sum == 0) maxn = 0;
	for(int i = fi[k]; i; i = ne[i])
		dfs(to[i], sum > 0 ? sum : 0, !s1 && sum > 0 ? k : z, max(maxn, sum));
}
