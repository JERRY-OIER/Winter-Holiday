#include <bits/stdc++.h>

using namespace std;

const int N = 50000;

int n, m;
int fail[N + 3];
char S[N + 3];
char T[N + 3];
char ch;

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d%d", &n, &m);
	int jsq = 0;
	while(jsq < n) {
		scanf("%c", &ch);
		if(ch > 'Z' || ch < 'A') continue;
		jsq++;
		S[jsq] = ch;
	}
	jsq = 0;
	while(jsq < m) {
		scanf("%c", &ch);
		if(ch > 'Z' || ch < 'A') continue;
		jsq++;
		T[jsq] = ch;
	}
	int get = 0;
	int res = 0;
	while(get < m) {
		int j = get;
		fail[get + 1] = get;
		for(int i = get + 1; i < m; i++) {
			j = fail[i];
			while(T[j + 1] != T[i + 1] && j > get) j = fail[j];
			if(T[j + 1] == T[i + 1]) fail[i + 1] = j + 1;
		}
		j = get;
		int maxn = 0;
		for(int i = 1; i <= n; i++) {
			while(S[i + 1] != T[j + 1] && j > get) j = fail[j];
			if(S[i + 1] == T[j + 1]) j++;
			maxn = max(j - get, maxn);
		}
		get += maxn;
		res++;
	}
	printf("%d\n", res);
	return 0;
}
