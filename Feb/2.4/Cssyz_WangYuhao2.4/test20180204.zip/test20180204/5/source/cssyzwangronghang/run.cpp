#include <bits/stdc++.h>

using namespace std;

int n, m, k, tot;

int a[15][9];

int main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);

    scanf("%d%d%d", &n, &m, &k);
    m /= 2;

    char c = getchar();
    while(c = getchar())
	if(c == '\n') break;

    for(int i = 0; i < n; i++)
	for(int j = 0; j < 8; j++)
	    scanf("%d", &a[i][j]);
    printf("TB\n");
    return 0;
}
