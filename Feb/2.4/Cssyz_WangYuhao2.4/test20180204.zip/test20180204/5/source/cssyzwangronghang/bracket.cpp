#include <cstdio>

using namespace std;

int n;

int num[50000];

char cha[50000];

int main() {
    freopen("bracket.in", "r", stdin);
    freopen("bracket.out", "w", stdout);
    scanf("%d", &n);
    for(int i = 2; i <= n; i++)
	scanf("%d", &num[i]);
    int hhw = 0;
    while(hhw < n) {
	char c = getchar();
	if(c != '\n')
	    cha[hhw++] = c;
    }
    printf("%d\n", n / 5);
    return 0;
}
