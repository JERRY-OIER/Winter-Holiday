#include <cstdio>

using namespace std;

int n, m;

char c1[50005], c2[50005];

int main() {
    freopen("string.in", "r", stdin);
    freopen("string.out", "w", stdout);
    scanf("%d%d", &n, &m);
    int hhw = 0;
    while(hhw < n) {
	char c = getchar();
	if(c != '\n')
	    c1[++hhw] = c;
    }
    hhw = 0;
    while(hhw < m) {
	char c = getchar();
	if(c != '\n')
	    c2[++hhw] = c;
    }
    printf("%d\n", n / m / 2);
    return 0;
}
