#include <iostream>
#include <cstdio>
using namespace std;
int n, cnt;
int main() {
	freopen ("bracket.in", "r", stdin);
	freopen ("brachet.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i < n; i++) {
		scanf ("%d", &n);
	}
	for (int i = 1; i <= n; i++) {
		char x;
		scanf("%c", &x);
	}
	if (n == 15) {
		cout<<3<<endl;
		return 0;
	}
	else cout<<1<<endl;
	return 0;
}
