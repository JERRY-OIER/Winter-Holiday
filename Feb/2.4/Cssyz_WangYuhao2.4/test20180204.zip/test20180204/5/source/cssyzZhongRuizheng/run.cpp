#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
long long m, n, k, ans[20], pd, flag;
long long res;
char a[1000001];
long long r[20][10];

void check(int a) {
	if (a > n) {
		if (res % m > k) {
			pd = 1;
		}
		return;
	}
	if (ans[a] == 1) {
		res += res * r[a][5] + r[a][6];
		check(a + 1);
		if (pd) return;
		res -= res * r[a][5] + r[a][6];
		res += res * r[a][7] + r[a][8];
		check(a + 1);
		if (pd) return;
		res -= res * r[a][7] + r[a][8];
	}
	if (ans[a] == 2) {
		res += res * r[a][1] + r[a][2];
		check(a + 1);
		if (pd) return;
		res -= res * r[a][1] + r[a][2];
		res += res * r[a][3] + r[a][4];
		check(a + 1);
		if (pd) return;
		res -= res * r[a][3] + r[a][4];
	}
}

void dfs(int x) {
	if (x > n) {
		check(1);
		res = 0;
		
		if (!pd) {
			flag = 1;
		}
		pd = 0;
		return;
	}
	ans[x] = 2;
	dfs(x + 1);
	if (flag) return;
	ans[x] = 1;
	dfs(x + 1);
	if (flag) return;
}



int main() {
	freopen ("run.in", "r", stdin);
	freopen ("run.out", "w", stdout);
	scanf ("%d%d%d", &n, &m, &k);
	scanf ("%s", a);
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= 8; j++) {
			scanf ("%d", &r[i][j]);
		}
	}
	dfs(1);
	for (int i = 1; i <= n; i++) {
		if (ans[i] == 1) printf ("B");
		if (ans[i] == 2) printf ("T");
	}
	printf("\n");
	return 0;
}
