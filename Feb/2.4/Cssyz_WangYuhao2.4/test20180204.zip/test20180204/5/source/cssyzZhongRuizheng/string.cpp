#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int n, m, cnt, maxx, ans;
char s[50001], t[50001];
int pos[26];
bool appear[26], used[26];

void read() {
	scanf("%d%d", &n, &m);
	while (cnt < n) {
		char x = getchar();
		if (x == '\n') continue;
		s[cnt] = x;
		cnt++;
	}
	cnt = 0;
	while (cnt < m) {
		char x = getchar();
		if (x == '\n') continue;
		t[cnt] = x;
		cnt++;
		if (!appear[x - 'a']) {
			appear[x - 'a'] = 1;
		}
	}
}

void find() {
	for (int i = 1; i <= n; i++) {
		if (appear[s[i] - 'a'] && used[s[i] - 'a']) {
			pos[s[i] - 'a'] = i;
		}
	}
}

void solve() {
	cnt = 0;
	while (cnt < m) {
		int fir = pos[t[cnt] - 'a'], jsq = 0;
		for (int i = 1; i <= n - fir + 1; i++) {
			if(s[fir + i] == t[cnt + jsq + 1]) {
				jsq++;
			}
			else {
				maxx = max(maxx, jsq);
				jsq = 0;
			}
		}
		ans++;
		cnt += maxx;
	}
}

int main() {
	freopen ("string.in", "r", stdin);
	freopen ("string.out", "w", stdout);
	read();
	find();
	solve();
	printf("%d", ans);
	return 0;
}
