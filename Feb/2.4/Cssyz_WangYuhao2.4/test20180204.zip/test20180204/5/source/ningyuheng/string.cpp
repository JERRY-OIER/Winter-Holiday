#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
#include<set>
using namespace std;
long long n,m,i,j,k,l,r,mid,hash[1002][1002],ans,ll;
char s[50002],t[50002];
set<long long> p;
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	set<long long> :: iterator it;
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
		cin>>s[i];
	for(i=1;i<=m;i++)
		cin>>t[i];
	for(i=1;i<=n;i++){
		ll=min(i+m-1,n);
		for(j=i;j<=ll;j++){
			l=l*1000000007+s[j];
			p.insert(l);
		}
		l=0;
	}
	for(i=1;i<=m;i++)
		for(j=i;j<=m;j++)
			hash[i][j]=hash[i][j-1]*1000000007+t[j];
	i=0;
	while(i<m){
		l=i+1;r=m;mid=(l+r)/2;ll=l;
		while(l<=r){
			if((*p.lower_bound(hash[ll][mid]))==hash[ll][mid]){
				l=mid+1;
				i=mid;
			}
			else
				r=mid-1;
			mid=(l+r)/2;
			
		}
		ans++;
	}
	cout<<ans<<endl;
	return 0;
}
