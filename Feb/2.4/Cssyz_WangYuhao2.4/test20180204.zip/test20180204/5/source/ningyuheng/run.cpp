#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
#include<set>
using namespace std;
long long n,m,k,b[15][8],z,i,j,flag,flag2;
char a[1000002],d[20];
int ss2(long long x,long long y){
	if(flag==1) return 0;
	if(x>n){
		if(y>k&&y<m-k)
			flag=1;
		return 0;
	}
	if(d[x]=='B'){
		ss2(x+1,(y*b[x][4]+b[x][5])%m);
		ss2(x+1,(y*b[x][6]+b[x][7])%m);
	}
	else{
		ss2(x+1,(y*b[x][0]+b[x][1])%m);
		ss2(x+1,(y*b[x][2]+b[x][3])%m);
	}
}
int ss(long long x){
	if(flag2==1) return 0;
	if(x>n) {
		ss2(1,0);
		if(flag==0){
			flag2=1;
			cout<<(d+1)<<endl;		
		}
		flag=0;
		return 0;
	}
	d[x]='B';
	ss(x+1);
	d[x]='T';
	ss(x+1);
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	scanf("%s",a);
	for(i=1;i<=n;i++)
		for(j=0;j<8;j++)
		scanf("%lld",&b[i][j]);
	ss(1);
	return 0;
}
