#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
#include<set>
using namespace std;
int n,i,j,x,dp[50020],max1,top,to[100020],nex[100020],fir[50020],zz[50020];
char s[50002],o='(',p=')';
int lj(int u,int v){
	top++;
	to[top]=v;
	nex[top]=fir[u];
	fir[u]=top;
}
int ss(int u,int v,int w){
	int top1=fir[v];
	while(top1!=0){
		if(to[top1]!=u){
			if(s[v]==p)
				ss(v,to[top1],w+1);
			else
				ss(v,to[top1],max(w-1,0));
			dp[v]=max(dp[v],dp[to[top1]]);
		}
		top1=nex[top1];	
	}
	if(s[v]==o)	dp[v]++;
	else dp[v]--;
	if(dp[v]<=w)
		max1=max(max1,dp[v]);
	else
		max1=max(max1,w);
	return 0;
}
int main(){
	freopen("bracket.in","r",stdin);
	freopen("bracket.out","w",stdout);
	scanf("%d",&n);
	for(i=2;i<=n;i++){
		scanf("%d",&x);
		lj(i,x);
		lj(x,i);
	}
	for(i=1;i<=n;i++)
		cin>>s[i];
	for(i=1;i<=n;i++){
		ss(i,i,0);
		for(j=1;j<=n;j++)
			dp[j]=0;
	}
	cout<<max1<<endl;
	return 0;
}
