#include <bits/stdc++.h>

using namespace std;
const int MAXN = 50000;
const int MAXM = 50000;

char S[MAXN + 1];
char T[MAXN + 1];
int top;
int fi[MAXN + MAXM + 1];
int ne[MAXN + MAXM + 1];
int to[MAXN + MAXM + 1];

void add(int, int);
int BFS(int, int);

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	int N;
	int M;
	for (int i = 1; i <= N; i++) {
		char c;
		while (scanf("%c", &c) == 1) {
			if (c == '\n' || c == ' ') continue;
			break;
		}
		S[i] = c;
	}
	for (int i = 1; i <= M; i++) {
		char c;
		while (scanf("%c", &c) == 1) {
			if (c == '\n' || c == ' ') continue;
			break;
		}
		T[i] = c;
	}
	for (int i = 1; i <= M; i++) {
		for (int j = 1; j <= N; j++) {
			if (T[i] == S[j]) {
				add(N + i, j);
				add(j, N + i + 1);
			}
		}
	}
	printf("%d\n", BFS(N + 1, N + M + 1));
	return 0;
}

void add(int u, int v) {
	top++;
	ne[top] = fi[u];
	fi[u] = top;
	to[top] = v;
}

int BFS(int begin, int end) {
	queue<int>q;
	q.push(begin);
	queue<int>step;
	step.push(0);
	while (!q.empty()) {
		int f = q.front();q.pop();
		int ts = step.front();step.pop();
		for (int i = fi[f]; i; i = ne[i]) {
		}
	}
	return 10;
}
