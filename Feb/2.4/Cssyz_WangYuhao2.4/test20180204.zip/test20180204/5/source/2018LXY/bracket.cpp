#include <bits/stdc++.h>

using namespace std;
const int MAXN = 40000;

int top;
int fi[MAXN + 1];
int ne[MAXN + 1];
int to[MAXN + 1];
int value[MAXN + 1];
int ans = 0;
bool arrive[MAXN + 1];

void add(int, int);
void DFS(int, int, int);

int main() {
	freopen("bracket.in", "r", stdin);
	freopen("bracket.out", "w", stdout);
	int N;
	scanf("%d", &N);
	for (int i = 2; i <= N; i++) {
		int x;
		scanf("%d", &x);
		add(x, i);
		add(i ,x);
	}
	for (int i = 1; i <= N; i++) {
		char buff[10];
		scanf("%s", buff);
		if (buff[0] == '(') value[i] = 1;
		if (buff[0] == ')') value[i] = -1;
	}
	for (int i = 1; i <= N; i++) {
		memset(arrive, false, sizeof(false));
		arrive[i] = true;
		DFS(i, value[i], 0);
	}
	printf("%d\n", ans);
	return 0;
}

void add(int u, int v) {
	top++;
	ne[top] = fi[u];
	fi[u] = top;
	to[top] = v;
}

void DFS(int t, int sum, int maxS) {
	if (sum < 0) return ;
	if (sum == 0) ans = max(ans, maxS);
	for (int i = fi[t]; i; i = ne[i]) {
		if (!arrive[to[i]]) {
			arrive[to[i]] = true;
			DFS(to[i], sum + value[to[i]], max(maxS, sum + value[to[i]]));
		}
	}
}
