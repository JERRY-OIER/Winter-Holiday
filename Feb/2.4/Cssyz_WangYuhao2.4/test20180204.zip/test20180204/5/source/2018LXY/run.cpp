#include <bits/stdc++.h>

using namespace std;
const int MAXN = 14;

struct Step {
	int card[9];
	Step() {memset(this->card, 0, sizeof(this->card));}
};

int po[4];
Step step[MAXN + 1];

int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	po[0] = 7;po[1] = 5;po[2] = 3;po[3] = 1;
	int N;
	int M;
	int K;
	scanf("%d%d%d", &N, &M, &K);
	char buff[MAXN + 1];
	memset(buff, 0, sizeof(buff));
	scanf("%s", buff);
	for (int i = 1; i <= N; i++) {
		for (int j = 1; j <= 8; j++) scanf("%d", &step[i].card[j]);
	}
	for (int i = 0; i < (1 << N); i++) {
		int ok = true;
		for (int j = 0; j  < (1 << N) && ok; j++) {
			int nm = i;
			int um = j;
			int far = 0;
			for (int bt = 1; bt <=  N; bt++) {
				int t = po[(nm & 1) * 2 + (um & 1)];
				far = (step[bt].card[t] * far + step[bt].card[t + 1]) % M;
				nm >>= 1;um >>= 1;
			}
			if (far > K && far <= (M - K)) ok = false;
		}
		if (ok) {
			int t = i;
			for (int k = 1; k <= N; k++) {
				printf("%c", (t & 1) ? 'T' : 'B');
				t >>= 1;
			}
			printf("\n");
			return 0;
		}
	}
	return 0;
}
