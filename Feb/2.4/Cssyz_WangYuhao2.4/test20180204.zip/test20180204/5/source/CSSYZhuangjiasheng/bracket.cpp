#include <bits/stdc++.h>
#define MAX_N 30010
#define INF 2147483647
using namespace std;

int N;
bool s[MAX_N];
int val[MAX_N];
int res = 0;

int main () {
  freopen ("bracket.in", "r", stdin);
  freopen ("bracket.out", "w", stdout);
  scanf("%d", &N);
  int v;
  for (int i = 1;i <= N; ++i) {
    scanf("%d", &v);
  }
  char c[2];
  for (int i = 1;i <= N; ++i) {
    scanf("%s",  c);
    s[i] = c[0] == '(' ? 0 : 1;
  }
  int sum = 0;
  for (int i = 1;i <= N; ++i) {
    if (s[i] == 1 && sum) sum--;
    if (s[i] == 0) sum++;
    val[i] = sum;
  } 

  for (int i = 1;i <= N; ++i) res = max(res, val[i]);
  printf("%d\n", res);
  return 0;
}
