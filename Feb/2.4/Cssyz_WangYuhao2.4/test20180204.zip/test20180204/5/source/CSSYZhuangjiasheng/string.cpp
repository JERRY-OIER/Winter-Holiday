#include <bits/stdc++.h>
#define MAX_N 2000
#define MAX_M 2000
#define MAX_S 200101
#define INF 2147483647
using namespace std;
inline int idx (char c) {return c - 'A';}

int ch[MAX_S][30], sz = 1;

char s[MAX_N], t[MAX_N], c;
int lens, lent;
int val[MAX_N];
int res = INF;

void build (int stat) {
  int u = 0, c = 0;
  for (int i = stat;i < lens; ++i) {
    c = idx(s[i]);
    if (!ch[u][c]) {
      memset(ch[sz], 0, sizeof(ch[sz]));
      ch[u][c] = sz++;
    }
    u = ch[u][c];
  }
}

void go () {
  int u = ch[0][idx(t[0])], c = 0;
  val[0] = 1;
  for (int i = 1;i < lent; ++i) {
    c = idx(t[i]);
    val[i] = val[i - 1];
    if (!ch[u][c]) u = 0, val[i]++;
    u = ch[u][c];
  }
}

void get (int stat) {
  int u = 0, c = 0;
  int sum = val[stat];
  for (int i = stat;i < lent; ++i) {
    c = idx(t[i]);
    if (!ch[u][c]) sum++, u = 0;
    //printf("%d %c %d  %d\n", u, c + 'A', ch[u][c], sum);
    u = ch[u][c];
  }
  res = min(res, sum);
}

int main () {
  freopen ("string.in", "r", stdin);
  freopen ("string.out", "w", stdout);
  scanf("%d%d", &lens, &lent);
  for (int i = 0;i < lens; ++i) {
    scanf("%c", &c);
    if (c == '\n') {i--; continue;}
    s[i] = c;
  }
  for (int i = 0;i < lent; ++i) {
    scanf("%c", &c);
    if (c == '\n') {i--; continue;}
    t[i] = c;
  }

  
  for (int i = 0;i < lens - 1; ++i) 
    build (i);

  go();
  res = min(res, val[lent - 1]);
  //for (int i = 0;i < lent; ++i) printf("%d ", val[i]); printf("\n"); return 0;
  for (int i = 1;i < lent - 1; ++i)
    get(i);

  printf("%d\n", res);
  return 0;
}
