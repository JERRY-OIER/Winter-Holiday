#include <bits/stdc++.h>
#define MAX_N 15
#define INF 2147483647
typedef long long ll;
using namespace std;

int N;
ll M, K;
char c = 'a';
int p[MAX_N][10], res[MAX_N];
int book;

void print () {
  for (int i = 1;i <= N; ++i) printf("%c", res[i] == 0 ? 'T' : 'B');printf("\n");
}

bool find (int dep, int dis) {
  if (dep == N + 1) {
    if (dis % M <= K) return true;
    return false;
  }
  for (int i = 5;i >= 1; i -= 4) {
    res[dep] = i / 5;
    if (find(dep + 1, dis * p[dep][i] + p[dep][i + 1]) & find(dep + 1, dis * p[dep][i + 2] + p[dep][i + 3])) return true;
  }
  return false;
}

int main () {
  freopen ("run.in", "r", stdin);
  freopen ("run.out", "w", stdout);
  scanf("%d%lld%lld\n", &N, &M, &K);
  while (c != '\n') scanf("%c", &c);
  for (int i = 1;i <= N; ++i) 
    for (int j = 1;j <= 8; ++j) 
      scanf("%d", &p[i][j]);


  find(1, 0);
  print();
  return 0;
}
