#include<bits/stdc++.h>
using namespace std;
int n,m,i,z[27][50005],size[27],sizet,sizes,k,ti,sum,sum1,sum2;
char a,s[50005],t[50005];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	//���� 
	scanf("%d%d",&n,&m);
	for(;;)
	{
		a = getchar();
		if(a == '\n') continue;
		else
		{
			z[a-'A'][size[a-'A']++] = i;
			s[i++] = a;
			if(i == n) break;
		}
	}
	i = 0;
	for(;;)
	{
		a = getchar();
		if(a == '\n') continue;
		else
		{
			t[i++] = a;
			if(i == m) break;
		}
	}
	//����
	sizet = strlen(t);
	sizes = strlen(s);
	//����
	i = 0;
	for(;;)
	{
		ti = t[i] - 'A';
		for(int j =  0; j < size[ti]; j++)
		{
			k = i;
			sum = 0;
			for(int b = z[ti][j];b <= sizes ; b++)
			{
				if(t[k] != s[b])
				{
					sum1 = max(sum1 , sum);
					break;
				}
				k++;
				sum++;
			}
		}
		sum2++;
		i += sum1;
		sum1 = 0;
		if(i == sizet)
		{
			cout<<sum2;
			return 0;
		}
	} 
	//����
}
