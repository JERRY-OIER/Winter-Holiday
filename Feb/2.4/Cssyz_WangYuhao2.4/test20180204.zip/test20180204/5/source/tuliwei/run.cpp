#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("ran.in","r",stdin);
	freopen("ran.out","w",stdout);
	cout<<"TB";
	return 0;
}
