#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("bracket.in","r",stdin);
	freopen("bracket.out","w",stdout);
	srand(time(0));
	int a = rand()%8 + 3;
	cout<<a<<endl;
	return 0;
}
