#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
char x[100];
char s[4010];
char t[4010];
int trie[10100][30],nxt[10100];
int tot,fa[10100],book[10100];
int n,m;
int root,lens,lent;
queue<int> q;
int end[4010];
void get_nxt()
{
	nxt[0]=0;
	for(int i=0;i<26;i++)
	{
		if(trie[0][i]!=0)
		{
			nxt[trie[0][i]]=0;
			q.push(trie[0][i]);
		}
	}
	while(q.size()!=0)
	{
		int now=q.front();
		q.pop();
		for(int i=0;i<26;i++)
		{
			if(trie[now][i]!=0)
			{
				int j=nxt[now];
				while(j!=0&&trie[j][i]==0)  j=nxt[j];
				if(trie[j][i]!=0)   j=trie[j][i];
				nxt[trie[now][i]]=j;
				q.push(trie[now][i]);
			}
		}
	}
}
bool check(int j,int i)
{
	//cout<<j<<" "<<end[i]<<endl;
	int fi=end[i];
	int x=j;
	while(x!=0)
	{
		if(x==fi)  return true;
		x=nxt[x];
	}
	return false;
}
int ans;
void solve()
{
	get_nxt();
	int work=lent;
	while(work!=0)
	{
		int flag=0;
		for(int i=work;i>=1;i--)
		{
			for(int j=1;j<=tot;j++)
			{
				if(book[j]==1&&check(j,i)==true)
				{
					work-=i;
					ans++;
					flag=1;
					break;
				}
			}
			if(flag==1)  break;
		}
	}
	cout<<ans<<endl;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	int cnt=0;
	lens=-1;
	lent=-1;
	while(scanf("%s",x))
	{
		cnt+=strlen(x);
		for(int i=0;i<strlen(x);i++)
		{
			lens++;
			s[lens]=x[i];
		}				
		if(cnt==n) break;
	}
	int root=0;
	cnt=0;
	while(scanf("%s",x))
	{
		cnt+=strlen(x);
		for(int i=0;i<strlen(x);i++)
		{
			lent++;
			t[lent]=x[i];
		}
		if(cnt==m) break;
	}
	lens=strlen(s);
	lent=strlen(t);
	for(int i=0;i<lens;i++)
	{
		root=0;
		for(int j=i;j<lens;j++)
		{
			int id=s[j]-'A';
			if(trie[root][id]==0)
			{
				tot++;
				trie[root][id]=tot;
			}
			root=trie[root][id];
			book[root]=1;
		}
	}
	for(int i=0;i<lent;i++)
	{
		root=0;
		for(int j=i;j<lent;j++)
		{
			int id=t[j]-'A';
			if(trie[root][id]==0)
			{
				tot++;
				trie[root][id]=tot;
			}
			root=trie[root][id];
		}
		end[lent-i]=root;
	}
	solve();
	return 0;
}
/*
38 9
THEQUICKBROWNFOXDO
GJUMPSOVERTHELAZYDOG
FOXDOGD
OG
*/
