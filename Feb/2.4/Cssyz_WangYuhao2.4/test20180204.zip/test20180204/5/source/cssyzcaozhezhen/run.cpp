#include<iostream>
#include<cstdio>
using namespace std;
int dp[(1<<10)+2][(1<<10)+2][12];
int book[(1<<10)+2][(1<<10)+2][12];
int n,m,kx;
char ansx[20];
int ans;
char s[20];
int card[20][8];
int main()
{
	freopen("run.in","r",stdin);
	freopen("run,out","w",stdout);
	scanf("%d%d%d",&n,&m,&kx);
	scanf("%s",s);
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=8;j++)  scanf("%d",&card[i][j]);
	dp[0][0][1]=card[1][6];
	dp[0][1][1]=card[1][8];
	dp[1][0][1]=card[1][2];
	dp[1][1][1]=card[1][4];
	
	book[0][0][1]=1;
	book[0][1][1]=1;
	book[1][0][1]=1;
	book[1][1][1]=1;
	for(int k=1;k<=n-1;k++)
	{
		for(int i=0;i<=(1<<n)-1;i++)
		{
			for(int j=0;j<=(1<<n)-1;j++)
			{
				if(book[i][j][k]==1)
				{
					cout<<i<<" "<<j<<" "<<k<<endl;
					dp[i][j][k+1]=(dp[i][j][k]*card[k+1][5]+card[k+1][6])%m;
					dp[i][j|(1<<k)][k+1]=(dp[i][j][k]*card[k+1][7]+card[k+1][8])%m;
					dp[i|(1<<k)][j][k+1]=(dp[i][j][k]*card[k+1][1]+card[k+1][2])%m;
					dp[i|(1<<k)][j|(1<<k)][k+1]=(dp[i][j][k]*card[k+1][3]+card[k+1][4])%m;
		
					book[i][j][k+1]=1;
					book[i][j|(1<<k)][k+1]=1;
					book[i|(1<<k)][j][k+1]=1;
					book[i|(1<<k)][j|(1<<k)][k+1]=1;
				}
			}
		}		
	}
	for(int i=(1<<n)-1;i>=0;i--)
	{
		int flag=0;
		for(int j=0;j<=(1<<n)-1;j++)
		{
			if(dp[i][j][n]>kx)
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			ans=i;
			break;
		}
	}
	int x=ans;
	for(int i=n;i>=1;i--)
	{
		int y=(x&(1<<(i-1)));
		if(y==0)  cout<<"T";
		else      cout<<"B"; 
	}
	cout<<endl;
	return 0;
}
