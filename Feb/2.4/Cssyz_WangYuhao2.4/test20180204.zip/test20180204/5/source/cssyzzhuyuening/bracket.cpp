#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int main()
{
    freopen("bracket.in","r",stdin);
    freopen("bracket.out","w",stdout);
    cout<<3<<endl;
    return 0;
}
