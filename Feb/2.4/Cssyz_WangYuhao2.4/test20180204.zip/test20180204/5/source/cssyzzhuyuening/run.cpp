#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,k;
int a[20][10],ans[50],flag[2]={0,1},fu[2][2]={{5,7},{1,3}};
char tt[100];
long long sum;
int susb(int x)
{   
    if(x>n)
    {
        if(sum>k&&m-sum>k)return 0;
        return 1;
    }
    int tsum=sum;
    if(ans[x]==0)
        for(int i=0;i<=1;++i)
        {
            sum=(sum+(sum*a[x][fu[0][i]]+a[x][fu[0][i]+1]))%m;
            int sym=susb(x+1); 
            sum=tsum;
            if(!sym)return 0;
        }
    else
        for(int i=0;i<=1;++i)
        {
            sum=(sum+(sum*a[x][fu[1][i]]+a[x][fu[1][i]+1]))%m;
            int sym=susb(x+1);
            sum=tsum;
            if(!sym)return 0;
        }
   return 1;
}
int search(int x)
{
    if(x>n)
    {
        sum=0;
        if(susb(1))
        {
            for(int i=1;i<=n;++i)
          {
               if(ans[i]==0)printf("B");
               else printf("T");
          }printf("\n");
            return 1;
        }
        return 0;
    }
    for(int i=0;i<=1;++i)
    {
        ans[x]=flag[i];
        if(search(x+1))return 1;
    }
}
int main()
{
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    scanf("%s",tt);
    for(int i=1;i<=n;++i)
        for(int j=1;j<=8;++j)
            scanf("%d",&a[i][j]);
    search(1);
    return 0;
}
//大法师
