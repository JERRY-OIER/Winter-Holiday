#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,l,tl,cnt,top,ed;
char s[100100],t[100100],tt[10010];
int r[100100];
struct data{
    int l,r;
}mar[100100];
int main()
{
    freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
    scanf("%d%d",&n,&m);
    while(strlen(s)<n)
    {
        scanf("%s",tt);
        l=strlen(s);tl=strlen(tt);
        for(int i=0;i<tl;++i)
        s[l+i]=tt[i];
    }
    while(strlen(t)<m)
    {
        scanf("%s",tt);
        l=strlen(t);tl=strlen(tt);
        for(int i=0;i<tl;++i)
        t[l+i]=tt[i];
    }
    for(int i=0;i<m;++i)
    {
        for(int j=0;j<n;++j)
        {
            if(t[i]!=s[j])continue;
            cnt=0;
            while(t[i+cnt]==s[j+cnt]&&i+cnt<m-1&&j+cnt<n-1)cnt++;
            if(i+cnt>r[i])r[i]=i+cnt;
        }
    }
    mar[0].r=r[0],top=0,mar[0].l=0;
    for(int i=1;i<m;++i)
    {   
        if(r[i]>mar[top].r)
            mar[++top].r=r[i],mar[top].l=i;
        //cout<<top<<" "<<mar[top].l<<" "<<mar[top].r<<endl;
    }
   // cout<<top<<endl;
    ed=0;
    for(int i=1;i<=top;++i)
    {
        while(mar[i].l<=mar[ed-1].r+1&&ed)ed--;
        //if(mar[i].l>mar[ed].r+1)ed++;
        mar[++ed].l=i;
        mar[ed].r=mar[i].r;
    }
    printf("%d\n",ed+1);
    return 0;
}
