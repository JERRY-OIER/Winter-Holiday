#include<cstdio>
int n,m,k,ans=999999999;
int f[15][15],s[15][15],a[15];
void bl(int x,int cnt)
{
	if (x>n)
	{
		int js=1,t;
		if (cnt%m<=k&&cnt!=0)
		{
			for (int i=1;i<=n;i++)
			{
				if (a[i]<=2) t=1;
				else t=2;
				js=js*(i-1)*10+t;
			}
			if (ans>js) ans=js;
		}
		return ;
	}
	for (int i=1;i<=8;i=i+2)
	{
		a[x]=(i+1)/2;
		bl(x+1,cnt+f[x][i]*cnt+f[x][i+1]);
	}
	return ;
}
int main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=8;j++)
			scanf("%d",&f[i][j]);
	bl(1,0);
	for (int i=n-1;n>=1;n--)
	{
		if (ans/n==1) printf("B");
		else printf("T");
		ans=ans%n;
	}
	return 0;
}
