#include<cstdio>
char a[50005],b[50005],x[5];
int n,m,ans;
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int k=1;
	scanf("%d%d",&n,&m);
	while (k<=n)
	{
		scanf("%c",&x[1]);
		if (x[1]!='\n')
			a[k]=x[1],k++;
	}
	k=1;
	while (k<=m)
	{
		scanf("%c",&x[1]);
		if (x[1]!='\n')
			b[k]=x[1],k++;
	}
	k=1;
	while (k<=m)
	{
		int cnt=1;
		for (int i=1;i<=n;i++)
			if (b[k]==a[i])
			{
				int k1=k+1,i1=i+1;
				int js=1;
				while (b[k1]==a[i1])
				{
					k1++;
					i1++;
					js++;
				}
				if (js>cnt) cnt=js;
			}
		k=k+cnt; ans++;
	}
	printf("%d\n",ans);
	return 0;
}
