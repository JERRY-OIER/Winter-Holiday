#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int N, M;

char rd[100];
int s[200005];

int tmp = 0;
void read1() {
	while (tmp < N) {
		scanf("%s", rd + 1);
		int len = strlen(rd + 1);
		for (int i = 1; i <= len; ++i) {
			s[++tmp] = rd[i] - 'A' + 1;
		}
	}
	return ;
}

void read2() {
	int tmp = 0;
	while (tmp < M) {
		scanf("%s", rd + 1);
		int len = strlen(rd + 1);
		for (int i = 1; i <= len; ++i) {
			s[++tmp + N] = rd[i] - 'A' + 1;
		}
	}
	return ;
}


int sa[200005], cnt[200005], t1[200005], t2[200005];

void bdsa(int m) {
	int *x = t1, *y = t2;
	for (int i = 1; i <= m; ++i) {
		cnt[i] = 0;
	}
	for (int i = 1; i <= N + M; ++i) {
		cnt[x[i] = s[i]]++;
	}
	for (int i = 1; i <= m; ++i) {
		cnt[i] += cnt[i - 1];
	}
	for (int i = N + M; i >= 1; --i) {
		sa[cnt[x[i]]--] = i;
	}
	for (int k = 1; k <= N + M; k <<= 1) {
		int p = 0;
		for (int i = N + M - k + 1; i <= N + M; ++i) {
			y[++p] = i;
		}
		for (int i = 1; i <= N + M; ++i) {
			if (sa[i] > k) y[++p] = sa[i] - k;
		}
		
		for (int i = 1; i <= m; ++i) {
			cnt[i] = 0;
		}
		for (int i = 1; i <= N + M; ++i) {
			cnt[x[y[i]]]++;
		}
		for (int i = 1; i <= m; ++i) {
			cnt[i] += cnt[i - 1];
		}
		for (int i = N + M; i >= 1; --i) {
			sa[cnt[x[y[i]]]--] = y[i];
		}
		
		swap(x, y);
		p = 1;
		x[sa[1]] = 1;
		for (int i = 2; i <= N + M; ++i) {
			x[sa[i]] = (y[sa[i - 1]] == y[sa[i]] && y[sa[i - 1] + k] == y[sa[i] + k] ? p: ++p);
		}
		if (p >= N + M) break;
		m = p;
	}
	return ;
}

int rk[200005], hei[200005], pot[200005];

void bdhe() {
	for (int i = 1; i <= N + M; ++i) {
		rk[sa[i]] = i;
		if (sa[i] > N) {
			pot[sa[i] - N] = i;
		}
	}
	
	int k = 0;
	
	for (int i = 1; i <= N + M; ++i) {
		if (k) k--;
		while (s[i + k] == s[sa[rk[i] - 1] + k]) {
			++k;
		}
		hei[rk[i]] = k;
	}
	return ;
}

int ans = 0;

int find(int p) {
	return p - 1 + max(hei[pot[p]], hei[pot[p] + 1]);
}

void solve() {
	int pos = 0;
	while (pos < M) {
		//cout << " " << N + M ;
		pos = find(pos + 1);
		//cout << pos << " ";
		++ans;
	}
	return ;
}


int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d%d", &N, &M);
	read1();
	read2();
	bdsa(26);
	
	/*printf("%d\n", N + M);
	for (int i = 1; i <= N + M; ++i) {
		printf("%d ", sa[i]);
		printf("%d\n", s[i]);
	}
	printf("\n");*/
	
	bdhe();
	/*for (int i = 1; i <= N + M; ++i) {
		printf("%d ", hei[i]);
		printf("%d\n", s[i]);
	}
	printf("\n");*/
	
	//printf("%d\n", N + M);
	
	solve();
	printf("%d", ans);
	return 0;	
}
















