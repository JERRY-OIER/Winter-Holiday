#include <iostream>
#include <cstdio>
using namespace std;
string S;
long long a[50][10];
int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	int n;
	long long m, k;
	scanf("%d%lld%lld", &n, &m, &k);
	cin >> S;
	
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= 8; ++j) {
			scanf("%d", &a[i][j]);
		}
	}
	
	for (int i = 0; i <= (1 << n) - 1; ++i) {
		int b = 1;
		for (int j = 0; j <= (1 << n) - 1; ++j) {
			long long dis = 0;
			for (int l = 1; l <= n; ++l) {
				int pos = ((i >> (n - l)) ^ 1) * 2 + ((j >> (l - 1)) & 1);
				//cout << pos;
				long long tmp = dis;
				dis += tmp * a[l][2 * pos + 1] + a[l][2 * pos + 2];
				dis %= m;
			}
			//printf(" %d %d %lld\n", i, j, dis);
			if (dis > k && dis < m - k) {
				b = 0;
				break;
			}
		}
		if (b) {
			for (int j = n; j >= 1; --j) {
				printf("%c", i >> (j - 1) & 1 ? 'T' : 'B');
			}
			break;
		}
	}
	return 0;
}

