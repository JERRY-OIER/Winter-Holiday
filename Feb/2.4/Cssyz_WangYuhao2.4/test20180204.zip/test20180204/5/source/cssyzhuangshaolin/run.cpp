#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
using namespace std;
int n,m,k,card[15][9];
bool ans[15];
string s;
bool search(int x,int dis)
{
	if(x>n)
	{
		if(min(dis,m-dis)<=k)
			return true;
		else
			return false;
	}
	srand(time(0));
	int a=rand()%2;
	if(a)
	{
		if(search(x+1,(dis*card[x][5]+card[x][6])%m))
			if(search(x+1,(dis*card[x][7]+card[x][8])%m))
				return ans[x]=true;
	}	
	else
	{
		if(search(x+1,(dis*card[x][7]+card[x][8])%m))
			if(search(x+1,(dis*card[x][5]+card[x][6])%m))
				return ans[x]=true;
	}	
	a=rand()%2;
	ans[x]=false;
	if(a)
	{
		if(search(x+1,(dis*card[x][1]+card[x][2])%m))
			if(search(x+1,(dis*card[x][3]+card[x][4])%m))
				return true;
	}	
	else
	{
		if(search(x+1,(dis*card[x][3]+card[x][4])%m))
			if(search(x+1,(dis*card[x][1]+card[x][2])%m))
				return true;
	}	
	return false;
}
int main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	cin>>n>>m>>k>>s;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=8;j++)
			scanf("%d",&card[i][j]);
	search(1,0);
	for(int i=1;i<=n;i++)
		if(ans[i])
			printf("B");
		else
			printf("T");
	printf("\n");
	return 0;
}
