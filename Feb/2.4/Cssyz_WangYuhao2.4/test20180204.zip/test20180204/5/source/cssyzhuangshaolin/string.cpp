#include<iostream>
#include<cstdio>
#include<cstring>
#define INF 0x7fffffff
using namespace std;
int n,m,dp[50001],jsq;
char s[50001],t[50001];
int main()
{
	int a,b;
	char sr[81];
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	cin>>n>>m;
	while(jsq<n)
	{
		scanf("%s",sr);
		for(int i=1;i<=strlen(sr);i++)
			s[jsq+i]=sr[i-1];
		jsq+=strlen(sr);
	}
	jsq=0;
	memset(sr,0,sizeof(sr));
	while(jsq<m)
	{
		scanf("%s",sr);
		for(int i=1;i<=strlen(sr);i++)
			t[jsq+i]=sr[i-1];
		jsq+=strlen(sr);
	}
	for(int i=1;i<=m;i++)
		dp[i]=INF;
	dp[0]=0;
	for(int i=1;i<=n;i++)
		for(int j=m;j>=1;j--)
		{
			a=i;
			b=j;
			while(s[a]==t[b]&&a<=n&&b<=m)
			{
				a++;
				b++;
			}
			dp[b]=min(dp[b],dp[j-1]+1);	
		}
	cout<<dp[m]<<endl;
	return 0;
}
