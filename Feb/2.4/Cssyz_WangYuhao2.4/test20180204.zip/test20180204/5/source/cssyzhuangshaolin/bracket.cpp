#include<iostream>
#include<cstdio>
using namespace std;
struct {
	int to,last;
}line[80000];
int n,val[40001],fir[40001],jsq,ans;
char c[40001];
void con(int u,int v)
{
	line[++jsq].to=v;
	line[jsq].last=fir[u];
	fir[u]=jsq;
}
void DFS(int x,int from,int sum)
{
	if(c[x]=='(')
	{
		sum++;
		ans=max(ans,sum);
	}	
	else
		if(sum)
			sum--;
	for(int next=fir[x];next;next=line[next].last)
	{
		if(line[next].to==from)
			continue;
		DFS(line[next].to,x,sum);
	}
	return;
}
int main()
{
	int a;
	freopen("bracket.in","r",stdin);
	freopen("bracket.out","w",stdout);
	cin>>n;
	for(int i=1;i<n;i++)
	{
		scanf("%d",&a);	
		con(i+1,a);
		con(a,i+1);
	}
	for(int i=1;i<=n;i++)
		scanf("%s",&c[i]);	
	DFS(1,0,0);
	cout<<ans<<endl;
	return 0;
}
