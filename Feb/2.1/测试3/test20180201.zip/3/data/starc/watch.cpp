#include <cstdio>
#include <string>
using namespace std;

int main() {
  int num;
  scanf("%d", &num);
  for (int i = 1; i <= num; ++i) {
    string S = "starc." + to_string(i) + ".in";
    FILE *f = fopen(S.c_str(), "r");
    int N, M;
    fscanf(f, "%d %d", &N, &M);
    printf("%d %d %d\n", i, N, M);
    fclose(f);
  }
  return 0;
}
