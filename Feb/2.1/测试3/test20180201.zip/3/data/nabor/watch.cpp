#include <cstdio>
#include <string>
using namespace std;

int main() {
  int num;
  scanf("%d", &num);
  for (int i = 1; i <= num; ++i) {
    string S = "nabor." + to_string(i) + ".in";
    FILE *f = fopen(S.c_str(), "r");
    int N;
    fscanf(f, "%d", &N);
    printf("%d %d\n", i, N);
    fclose(f);
  }
  return 0;
}
