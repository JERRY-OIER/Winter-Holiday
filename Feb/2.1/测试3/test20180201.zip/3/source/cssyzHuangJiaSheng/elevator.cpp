#include <bits/stdc++.h>
#define MAX_N 19
using namespace std;

int N, W;
int c[MAX_N];
int que[MAX_N];
int front = 1, rear = 0;

void solve () {
  sort(c + 1, c + N + 1);
  for (int i = 1;i <= N; ++i) que[++rear] = c[i];
  int res = 0, sum = 0;
  while (front <= rear) {
    sum = 0;
    res++;
    while (rear >= front && sum + que[rear] <= W) {
      sum += que[rear];
      rear--;
    }
    while (front <=  rear && sum + que[front] <= W) {
      sum += que[front];
      front++;
    }
  }
  printf("%d\n", res);
}

int main () {
  freopen ("elevator.in", "r", stdin);
  freopen ("elevator.out", "w", stdout);
  scanf("%d%d", &N, &W);
  for (int i = 1;i <= N; ++i) scanf("%d", c + i);
  if (N == 2) {
    if (c[1] + c[2] > W) printf("2\n");
    else printf("1\n");
    return 0;
  }
  else if (N == 3) {
    if (c[1] + c[2] + c[3] <= W) printf("1\n");
    else {
      if (c[1] + c[2] > W && c[2] + c[3] > W && c[1] + c[3] > W) printf("3\n");
      else printf("2\n");
    }
    return 0;
  }
  else solve();
  return 0;
}
