#include <bits/stdc++.h>
#define MAX_N 51
#define MAX_M 151
using namespace std;

int N, M;

int main () {
  freopen ("battle.in", "r", stdin);
  freopen ("battle.out", "w", stdout);
  scanf("%d%d", &N, &M);
  int a = M / 2 + 1;
  for (int i = 1;i <= a; ++i)
    printf("J\n");

  for (int i = a + 1;i <= M; ++i) printf("U\n");
  return 0;
}
