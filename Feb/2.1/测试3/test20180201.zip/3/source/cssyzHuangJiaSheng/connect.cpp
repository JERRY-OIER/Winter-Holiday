#include <bits/stdc++.h>
#define MAX_N 100010
typedef long long ll;
using namespace std;
struct pp {
  ll x, y;
}p[MAX_N];

int head[MAX_N * 100], nxt[MAX_N * 100], to[MAX_N * 100], top;

int N;
ll C;
bool vis[MAX_N], idx[MAX_N];
int res, maxx, sz;

int get_dis (pp a, pp b) {
  return abs (a.x - b.x) + abs(a.y - b.y);
}

void addedge (int u, int v) {
  nxt[++top] = head[u];
  head[u] = top;
  to[top] = v;
}

void find (int o) {
  vis[o] = true;
  for (int i = head[o]; i; i = nxt[i]) {
    if (vis[to[i]]) continue;
    maxx++;
    find(to[i]);
  }
}

bool cmp (const pp a, const pp b) {return a.x == b.x ? a.y < b.y : a.x < b.x;}
int main () {
  freopen ("connect.in", "r", stdin);
  freopen ("connect.out", "w", stdout);
  scanf("%d%lld", &N, &C);
  for (int i = 1;i <= N; ++i) scanf("%lld%lld", &p[i].x, &p[i].y);
  sort(p + 1, p + N + 1, cmp);

  for (int i = 1;i <= N; ++i) {
    for (int j = i + 1;j <= N; ++j) {
      if (p[j].x - p[i].x > C) break;
      if (get_dis(p[i], p[j]) <= C) {
	addedge(i, j);
	addedge(j, i);
      }
    }
  }

  memset(vis, 0, sizeof(vis));
  for (int i = 1;i <= N; ++i) {
    if (vis[i]) continue;
    maxx = 1;
    find(i);
    res = max(maxx, res);
    ++sz;
  }

  printf("%d %d\n", sz, res);
  return 0;
}
