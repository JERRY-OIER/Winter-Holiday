#include<iostream>
#include<cstdio>
using namespace std;
int n,m,j1,j2,j3,b1,b2,b3;
char t;
struct d
{
	int c1,c2,c3;
}a[101010];
int main()
{
	freopen("battle.in","r",stdin);
	freopen("battle.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		cin>>t;
		scanf("%d%d%d%d%d%d",&j1,&j2,&j3,&b1,&b2,&b3);
		if(t=='J')
		{
			a[i].c1=j1-b1;a[i].c2=j2-b2;
			a[i].c3=j3-b3;
		}
		else
		{
			a[i].c1=b1-j1;a[i].c2=b2-j2;
			a[i].c3=b3-j3;
		}
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d%d%d%d",&j1,&j2,&j3,&b1,&b2,&b3);
		j1-=b1;j2-=b2;j3-=b3;
		int d=0;
		for(int j=1;j<=n;j++)
		 if(j1-a[j].c1>=0&&j2-a[j].c2>=0&&j3-a[j].c3>=0)
		 {
		 	 d=1;
			 break;
		 }
		 else if(j1+a[j].c1<=0&&j2+a[j].c2<=0&&j3+a[j].c3<=0)
		 {
			 d=2;
			 break;
		 }
		if(d==1)
		 printf("J\n");
		if(d==2)
		 printf("B\n");
		if(!d)
		 printf("U\n");
	}
	return 0;
}

