#include<iostream>
#include<cstdio>
using namespace std;
int n,k,sum,ans,cnt,cntq,tot,num;
int a[20],q[20],t[20];
bool d[20];
void dfs(int x,int sum)
{
	for(int i=x+1;i<=n;i++)
	{

		if(sum+a[i]>k||d[i]) continue;	
		t[++cnt]=i;
		dfs(i,sum+a[i]);
		cnt--;
	}	
	if(sum>tot)
	{
		tot=sum;
		for(int i=1;i<=cnt;i++)
		q[i]=t[i];
		cntq=cnt;
	}
}
int main()
{
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	num=n;int j=0;
	while(num)
	{
		tot=0;
		for(int i=1;i<=n;i++)
		if(!d[i])
	 	{
	 		t[cnt=1]=i;
	 		dfs(i,a[i]);
	 	}
	 	for(int i=1;i<=cntq;i++)
	 	 d[q[i]]=1;
	 	num-=cntq;
	 	ans++;
	}	
	printf("%d\n",ans);
	return 0;
}
