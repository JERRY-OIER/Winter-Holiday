#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,c,cnt,ans,ans2,fa[101010],size[101010];
struct da
{
	int x,y;
}a[101010];
bool cmp(da u,da v){return u.x<v.x||u.x==v.x&&u.y<v.y;}
int low(int l,int r,int k)
{
	int mid;
	while(l<r)
	{
		mid=(l+r)/2;
		if(a[mid].x>k)r=mid;
		else l=mid+1;
	}
	return r;
}
int find(int x)
{
	if(x==fa[x]) return x;
	else return fa[x]=find(fa[x]);
}
int main()
{
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	scanf("%d%d",&n,&c);
	for(int i=1;i<=n;i++)
	 	scanf("%d%d",&a[i].x,&a[i].y);
	sort(a+1,a+n+1,cmp);
	a[n+1].x=0x3f3f3f3f;
	for(int i=1;i<=n;i++)
	{
		int nd=low(i+1,n+1,a[i].x+c);
		if(!fa[i]) {fa[i]=i;size[i]=1;}
		for(int j=i+1;j<nd;j++)
		if((a[j].x-a[i].x)+abs(a[j].y-a[i].y)<=c)
		{
			if(!fa[j]) 
			{
				fa[j]=find(i);
				size[fa[i]]++;
			}
			else if(find(j)!=find(i))
			{
				fa[find(j)]=find(i);
				size[fa[i]]+=size[fa[j]];
			}
		}
	}
	for(int i=1;i<=n;i++)
		if(fa[i]==i)
		{
			if(size[i]>ans2) ans2=size[i];
			ans++;
		}
	printf("%d %d\n",ans,ans2);
	return 0;
}
