#include <bits/stdc++.h>

using namespace std;

int n, m;

int main() {
    freopen("battle.in", "r", stdin);
    freopen("battle.out", "w", stdout);
    scanf("%d%d", &n, &m);
    int a, b, c, d, e, f;
    for(int i = 1; i <= n; i++) {
	getchar();
	scanf("%d%d%d%d%d", &a, &b, &c, &d, &e);
    }
    for(int i = 1; i <= m; i++) {
	scanf("%d%d%d%d%d%d", &a, &b, &c, &d, &e, &f);
    }
    for(int i = 1; i <= m; i++) {
	printf("J\n");
    }
    return 0;
}
