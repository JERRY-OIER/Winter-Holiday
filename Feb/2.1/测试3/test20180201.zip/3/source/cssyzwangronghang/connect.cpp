#include <bits/stdc++.h>

using namespace std;

int n, c, x[100010], y[100010];

int main() {
    freopen("connect.in", "r", stdin);
    freopen("connect.out", "w", stdout);
    scanf("%d%d", &n, &c);
    for(int i = 1; i <= n; i++) {
	scanf("%d%d", &x[i], &y[i]);
    }
    printf("%d %d", c, n - 1);
    return 0;
}
