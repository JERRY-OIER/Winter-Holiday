#include<bits/stdc++.h>

using namespace std;

int inf = 2147483647;

int dp[1 << 18 + 1], hhw[1 << 18 + 1], w[30];

int main()
{
    freopen("elevator.in", "r", stdin);
    freopen("elevator.out", "w", stdout);
    int n, c;
    scanf("%d%d",&n, &c);
    for (int i = 1; i <= n; i++)
	scanf("%d", &w[i]);
    int mx = (1 << n) - 1;
    for (int i = 0; i <= mx; i++)
	dp[i] = inf, hhw[i] = c;
    dp[0] = 0;
    for (int i = 0; i < mx; i++) {
	for (int j = 1; j <= n; j++)
	    if (!(i & (1 << j - 1))) {
		int aa,bb;
		if (hhw[i]>=w[j]) {
		    aa=hhw[i]-w[j];
		    bb=dp[i];
		}
		else aa = c - w[j], bb = dp[i] + 1;
		if (bb < dp[i | (1 << j - 1)]) {
		    dp[i | (1 << j - 1)] = bb;
		    hhw[i | (1 << j - 1)] = aa;
		}
		else if (bb == dp[i | (1 << j - 1)])
		    hhw[i | (1 << j - 1)] = max(hhw[i | (1 <<j - 1)], aa);
	    }
    }
    if (hhw[mx] != c)
	dp[mx]++;
    printf("%d\n", dp[mx]);
    return 0;
}
