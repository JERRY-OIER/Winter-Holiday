#include <bits/stdc++.h>

using namespace std;

const int N = 20;

int n, m;
int res = 20;
int a[N];
bool book[N];

void dg(int tot, int num, int k) {
	if(tot == n) {
		res = min(res, num + (k > 0));
		return ;
	}
	if(num > res) return ;
	for(int i = 1; i <= n; i++)
		if(!book[i]) {
			book[i] = 1;
			if(k + a[i] <= m)
				dg(tot + 1, num, a[i] + k);
			else
				dg(tot + 1, num + 1, a[i]);
		}
}

int main() {
	freopen("elevator.in", "r", stdin);
	freopen("elevator.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; i++)
		scanf("%d", &a[i]);
	dg(0, 0, 0);
	printf("%d\n", res);
	return 0;
}
