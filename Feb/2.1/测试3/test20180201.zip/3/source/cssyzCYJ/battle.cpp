#include <bits/stdc++.h>

using namespace std;

int n, m;
struct P {
	int a[3];
}book[301];

int gcd(int a, int b) {
	if(a < b) swap(a, b);
	return !b ? a : gcd(b, a % b);
}

struct Q {
	int a, b;
}bj[3][3];

void get_(P n, int k) {
	int a, b, check = 0;
	int wz1, wz2;
	for(int i = 0; i < 3; i++) {
		if(n.a[i] != k) {
			if(!check) a = n.a[i], wz1 = i, check = 1;
			else b = n.a[i], wz2 = i;
		}
	}
	if(a * b >= 0) return ;
	int g1 = gcd(abs(a), abs(b));
	a /= g1;
	b /= g1;
	Q q1 = bj[wz1][wz2];
	Q q2 = bj[wz2][wz1];
	if(a > 0 && q1.b * a > q1.a * -b) q1.a = a, q1.b = -b;
	if(b > 0 && q2.b * -a < q2.a * b) q2.a = -a, q2.b = b;
	bj[wz1][wz2] = q1;
	bj[wz2][wz1] = q2;
}

void get(P x, P y, int i) {
	int g = gcd(abs(x.a[i]), abs(y.a[i]));
	int l = abs(x.a[i] * y.a[i]) / g;
	P n = x, m = y;
	for(int j = 0; j < 3; j++) {
		n.a[j] *= (l / abs(x.a[i]));
		m.a[j] *= (l / abs(y.a[i]));
	}
	int check = 0;
	for(int j = 0; j < 3; j++) {
		n.a[j] += m.a[j];
		if(!n.a[j]) check = j;
	}
	get_(n, check);
}

void get_gx(P x, P y, P z) {
	for(int i = 0; i < 3; i++) {
		if(x.a[i] * y.a[i] < 0) get(x, y, i);
		if(x.a[i] * z.a[i] < 0) get(x, z, i);
		if(y.a[i] * z.a[i] < 0) get(y, z, i);
		if(!x.a[i]) get_(x, i);
		if(!y.a[i]) get_(y, i);
		if(!z.a[i]) get_(z, i);
	}
}

int main() {
	freopen("battle.in", "r", stdin);
	freopen("battle.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; i++) {
		char ch[2];
		int j1, j2, j3, b1, b2, b3;
		scanf("%s%d%d%d%d%d%d", ch, &j1, &j2, &j3, &b1, &b2, &b3);
		book[i].a[0] = (j1 - b1) * (ch[0] == 'J' ? 1 : -1);
		book[i].a[1] = (j2 - b2) * (ch[0] == 'J' ? 1 : -1);
		book[i].a[2] = (j3 - b3) * (ch[0] == 'J' ? 1 : -1);
	}
	for(int i = 0; i < 3; i++)
		for(int j = 0; j < 3; j--)
			bj[i][j].a = -1, bj[i][j].b = -1;
	for(int i = 1; i <= n; i++)
		for(int j = i + 1; j <= n; j++)
			for(int k = j + 1; k <= n; j++)
				get_gx(book[i], book[j], book[k]);
	for(int i = 0; i < 3; i++) {
		for(int j = 0; j < 3; j++) {
			if(i == j) continue;
			for(int k = 0; k < 3; k++) {
				if(k == i || k == j) continue;
				if(bj[i][j].a != -1 && bj[j][k].a != -1) {
					Q q1 = bj[i][j], q2 = bj[j][k], q3 = bj[i][k];
					Q q = {q1.a * q2.a, q1.b * q2.b};
					int g = gcd(q.a, q.b);
					q.a /= g;
					q.b /= g;
					if(q3.a == -1 || q3.a * q.b > q3.b * q.a)
						bj[i][k] = q;
				}
			}
		}
	}
	for(int i = 1; i <= m; i++) {
		int j1, j2, j3;
		int b1, b2, b3;
		scanf("%d%d%d%d%d%d", &j1, &j2, &j3, &b1, &b2, &b3);
		int a = j1 - b1;
		int b = j2 - b2;
		double c = (double)(j3 - b3);
		if(bj[0][2].a == -1 || bj[1][2].a == -1) printf("U\n");
		Q q1 = bj[0][2];
		Q q2 = bj[1][2];
		c += a * (q1.b / q2.a * 1.00000) + b * (q2.b / q2.a * 1.00000);
		if(c > 0) printf("J\n");
		else printf("B\n");
	}
	return 0;
}
