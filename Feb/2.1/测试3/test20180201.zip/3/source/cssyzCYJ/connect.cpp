#include <bits/stdc++.h>

using namespace std;

const int N1 = 1000;
const int N2 = 100000;

int n, c;
struct P{
	int x, y, s;
}Node[N2 + 1];

int tot;
int fi[N1 + 1];
int ne[N1 * N1 + 1];
int to[N1 * N1 + 1];

void add(int u, int v) {
	ne[++tot] = fi[u];
	fi[u] = tot;
	to[tot] = v;
}

bool pd(P a, P b) {
	if(abs(a.x - b.x) + abs(a.y - b.y) <= c)
		return true;
	return false;
}

bool book[N1 + 1];

int DFS(int x) {
	if(book[x]) return 0;
	book[x] = true;
	int res = 1;
	for(int i = fi[x]; i; i = ne[i])
		res  += DFS(to[i]);
	return res;
}

int main() {
	freopen("connect.in", "r", stdin);
	freopen("connect.out", "w", stdout);
	scanf("%d%d", &n, &c);
	for(int i = 1; i <= n; i++)
		scanf("%d%d", &Node[i].x, &Node[i].y);
	if(n <= 1000) {
		for(int i = 1; i <= n; i++)
			for(int j = 1; j < i; j++)
				if(pd(Node[i], Node[j]))
					add(i, j), add(j, i);
		int tot = 0, res = 0;
		for(int i = 1; i <= n; i++)
			if(!book[i])
				res = max(res, DFS(i)), tot++;
		printf("%d %d\n", tot, res);
	}
	return 0;
}
