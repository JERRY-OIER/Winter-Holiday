#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=100010;
inline int read(){
	int X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
struct point{
	int x,y;
}p[N];
struct lin{
	int v,id,y;
}t[N],tmp[N];
bool cmp(point a,point b){
	return a.x<b.x||(a.x==b.x&&a.y<b.y);
}
int fa[N],sz[N],n,c;
int find(int x){
	if(fa[x]==x)return x;
	return fa[x]=find(fa[x]);
}
void unionn(int a,int b){fa[a]=b;sz[b]+=sz[a];}
void msort(int x,int y,bool h){
	if(x==y)return;
	int mid=(x+y)>>1;
	msort(x,mid,h);msort(mid+1,y,h);
	int l=x,r=mid+1,cnt=x;
	while(l<=mid&&r<=y){
		if(t[l].y<t[r].y){
			if(t[r].v-t[l].v<=c&&!h){
				int a=find(t[r].id),b=find(t[l].id);
				if(a!=b)unionn(a,b);
			}
			tmp[cnt++]=t[l];l++;
		}else{
			if(t[r].v-t[l].v<=c&&h){
				int a=find(t[r].id),b=find(t[l].id);
				if(a!=b)unionn(a,b);
			}
			tmp[cnt++]=t[r];r++;
		}
	}
	while(l<=mid){
		tmp[cnt++]=t[l];l++;
	}
	while(r<=y){
		tmp[cnt++]=t[r];r++;
	}
	for(int i=x;i<=y;i++)t[i]=tmp[i];
}
void solve(){
	for(int i=1;i<=n;i++){
		t[i].v=p[i].x+p[i].y;
		t[i].id=i;t[i].y=p[i].y;
	}
	msort(1,n,0);
	for(int i=1;i<=n;i++){
		t[i].v=p[i].x-p[i].y;
		t[i].id=i;t[i].y=p[i].y;
	}
	msort(1,n,1);
	return;
}
int main(){
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	n=read(),c=read();
	for(int i=1;i<=n;i++){
		p[i].x=read(),p[i].y=read();
		fa[i]=i;sz[i]=1;
	}
	if(n>5000){
		sort(p+1,p+n+1,cmp);
		solve();
	}else{
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				if(abs(p[i].x-p[j].x)+abs(p[i].y-p[j].y)<=c){
					int a=find(i),b=find(j);
					if(a!=b)unionn(a,b);
				}
			}
		}
	}
	int ans=0,maxn=0;
	for(int i=1;i<=n;i++){
		if(fa[i]==i){
			ans++;
			maxn=max(maxn,sz[i]);
		}
	}
	printf("%d %d\n",ans,maxn);
	return 0;
}
