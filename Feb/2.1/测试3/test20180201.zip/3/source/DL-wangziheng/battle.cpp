#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=310;
const int M=2010;
inline int read(){
	int X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
bool win[N];
int a[N][4],b[3];
vector<int>q[4];
int main(){
	freopen("battle.in","r",stdin);
	freopen("battle.out","w",stdout);
	int n=read(),m=read();
	int P=sqrt(10000/n);
	for(int i=1;i<=n;i++){
		char ch=0;
		while(ch!='J'&&ch!='B')ch=getchar();
		for(int j=1;j<=3;j++)a[i][j]=read();
		for(int j=1;j<=3;j++)a[i][j]-=read();
		if(ch=='B')win[i]=1;
	}
	for(int j=1;j<=P;j++){
		for(int k=1;k<=P;k++){
			for(int l=1;l<=P;l++){
				if(j*100<k)continue;
				if(j*100<l)continue;
				if(k*100<j)continue;
				if(k*100<l)continue;
				if(l*100<j)continue;
				if(l*100<k)continue;
				bool ok=1;
				for(int p=1;p<=n&&ok;p++){
					int h=a[p][1]*j+a[p][2]*k+a[p][3]*l;
					if(!win[p]){
						if(h<=0)ok=0;
					}else{
						if(h>=0)ok=0;
					}
				}
				if(!ok)continue;
				q[1].push_back(j);
				q[2].push_back(k);
				q[3].push_back(l);
			}
		}
	}
	for(int i=1;i<=m;i++){
		int L=0,W=0;
		for(int j=1;j<=3;j++)b[j]=read();
		for(int j=1;j<=3;j++)b[j]-=read();
		for(int j=0;j<q[1].size();j++){
			int a1=q[1][j],a2=q[2][j],a3=q[3][j];
			int h=a1*b[1]+a2*b[2]+a3*b[3];
			if(h>0)L++;
			if(h<0)W++;
		}
		if(L==0&&W==0)puts("U");
		else if(L==0&&W)puts("B");
		else if(W==0&&L)puts("J");
		else puts("U");
	}
	return 0;
}
