#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=20;
const int M=524288;
const int INF=214748364;
inline int read(){
	int X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
int n,w,c[N],dp[M];
inline int getnum(int k){
	int ans=0,cnt=0,sumw=0;
	while(k){
		int l=k-k/2*2;cnt++;
		if(l){
			ans++;
			sumw+=c[cnt];
		}
		k/=2;
		if(sumw>w)return -1;
	}
	return ans;
}
int main(){
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
	n=read(),w=read();
	for(int i=1;i<=n;i++)c[i]=read();
	for(int i=1;i<(1<<(n+1));i++){
		if(getnum(i)==1)dp[i]=1;
		else dp[i]=INF;
	}
	for(int i=1;i<(1<<(n+1));i++){
		if(getnum(i)!=-1)dp[i]=1;
		else for(int j=0;j<i;j++){
			int k=i^j;
			dp[i]=min(dp[i],dp[j]+dp[k]);
		}
	}
	printf("%d\n",dp[(1<<(n+1))-1]);
	return 0;
}
