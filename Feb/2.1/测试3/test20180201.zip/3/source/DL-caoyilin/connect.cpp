#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=1e5+5;
struct point 
{
	int x,y,id;
	inline void read()
	{
		scanf("%d%d",&x,&y);
	}
}p[N];
int n,c;
int fa[N],sz[N],que[N];
bool vis[N];
int find(int u)
{
	return fa[u]=(fa[u]==u?u:find(fa[u]));
}
int dist(int u,int v)
{
	return abs(p[u].x-p[v].x)+abs(p[u].y-p[v].y);
}
bool check(int u,int v)
{
	return dist(u,v)<=c;
}
void solve1()
{
	//int ans=0,cnt=0;
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if(check(i,j)) 
			{
			int u=find(i),v=find(j);
			if(u==v) continue;
			fa[v]=u;
			sz[u]+=sz[v];
		}
		//printf("%d %d\n",n-cnt,ans);
}
bool cmp1(point u,point v)
{
	return u.x<v.x;
}
void solve2()
{
	sort(p+1,p+n+1,cmp1);
	int ql=1,qr=0;
	for(int i=1;i<=n;i++)
	{
		while(ql<=qr&&dist(que[ql],i)>c) ql++;
		if(ql<=qr)  
		{
			int u=find(i),v=find(que[ql]);
			if(u!=v) fa[u]=v,sz[v]+=sz[u];
		}
		while(ql<=qr&&p[i].y<p[que[qr]].y) qr--;
		que[++qr]=i;
	}
	ql=1,qr=0;
	for(int i=1;i<=n;i++)
	{
		while(ql<=qr&&dist(que[ql],i)>c) ql++;
		if(ql<=qr)  
		{
			int u=find(i),v=find(que[ql]);
			if(u!=v) fa[u]=v,sz[v]+=sz[u];
		}
		while(ql<=qr&&p[i].y>p[que[qr]].y) qr--;
		que[++qr]=i;
	}
}
int main()
{
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	scanf("%d%d",&n,&c);
	for(int i=1;i<=n;i++) p[i].read(),fa[i]=i,sz[i]=1,p[i].id=i;
	if(n<=5000) solve1();else
	 solve2();
	int ans1=0,ans2=0;
	for(int i=1;i<=n;i++)
	{
		int v=find(i);
//		printf("fa[%d]=%d\n",i,v);
		if(!vis[v]) vis[v]=1,ans1++,ans2=max(ans2,sz[v]);
}
	printf("%d %d\n",ans1,ans2);
	return 0;
}
/*
4 2
1 1
3 3
2 2
10 10
*/
