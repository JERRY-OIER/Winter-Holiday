#include<cstdio>
using namespace std;
int main()
{
	freopen("battle.out","w",stdout);
	puts("J");
	puts("J");
	puts("U");
	return 0;
}
