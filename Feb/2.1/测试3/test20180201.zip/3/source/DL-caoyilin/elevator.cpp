#include<cstdio>
#include<algorithm>
using namespace std;
const int N=105;
const int M=(1<<20)+5;
int n,w;
int a[N],dp[M],sum[M];
bool vis[N];
void solve2()
{
	sort(a+1,a+n+1);
	int t=0,ans=0;
	for(int i=n;i>=1;i--)
	{
		t=a[i];
		if(vis[i]) continue;
		ans++;
		for(int j=i-1;j>=1;j--)
		{
			if(vis[j]||t+a[j]>w) continue;
			t+=a[j];
			vis[j]=1;
		}
	}
	printf("%d\n",ans);
	return ;
}
void solve1()
{
	for(int i=1;i<=n;i++) sum[(1<<i-1)]=a[i];
	for(int i=1;i<(1<<n);i++)
	{
		if(sum[i]) continue;
		sum[i]=sum[i-(i&-i)]+sum[i&-i];
	}
	for(int i=1;i<(1<<n);i++)
		{
		dp[i]=20;
		for(int j=1;j<=i;j++)
		{
			if((i&j)!=j||sum[j]>w) continue;
			dp[i]=min(dp[i],dp[i-j]+1);
		}
//		printf("%d:%d\n",i,dp[i]);
	}
	printf("%d",dp[(1<<n)-1]);
	return ;
}
bool ok=0;
int ele[N];
bool dfs(int num,int dep)
{
	if(dep==n+1) return true;
	for(int i=1;i<=num;i++)
	{
		if(ele[i]+a[dep]<=w) 
		{
			ele[i]+=a[dep];
			if(dfs(num,dep+1)) return true;
			ele[i]-=a[dep];
		}
	}
	return false;
}
bool cmp(int a,int b)
{
	return a>b;
}

void solve3()
{
	sort(a+1,a+n+1,cmp);
	int ans=0;
	while(++ans)
	{
		if(dfs(ans,1))
		{
			printf("%d\n",ans);
			return ;
		}
	}
}
int main()
{
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
	scanf("%d%d",&n,&w);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
//	if(n<=13) solve1();else
	solve3();
	return 0;
}
/*
4 10
5 6 3 7
18 94
51 51 51 51 51 51 72 93 47
42 21 6 37 12 36 48 50 29  
*/
