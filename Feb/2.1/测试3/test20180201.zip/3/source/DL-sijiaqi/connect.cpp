#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
#define MAXN 100010
//#define ivorysi
using namespace std;
typedef long long ll;
int fa[MAXN],size[MAXN],cnt,maxsize;
int n,C;
struct node {
	int x,y,id;
	bool operator < (const node &rhs) const {
		return x < rhs.x;
	}
}poi[MAXN];
node tmp1[MAXN],tmp2[MAXN];
int getfa(int x) {
	return fa[x] == x ? x : fa[x] = getfa(fa[x]);
}
void merge(int a,int b) {
	fa[getfa(a)] = getfa(b);
}
void solve(int l,int r) {
	if(l == r) return;
	int mid = (l + r) >> 1;
	solve(l,mid);solve(mid + 1,r);
	int id = -1,maxv = -1;
	int p = l;
	for(int i = mid + 1 ; i <= r ; ++i) {
		while(p <= mid && poi[p].y <= poi[i].y) {
			if(poi[p].x + poi[p].y >= maxv) {
				maxv = poi[p].x + poi[p].y;
				id = poi[p].id;
			}
			++p;
		}
		if(id != -1) {
			if(poi[i].x + poi[i].y - maxv <= C) {
				merge(poi[i].id,id);
			}
		}
	}
	for(int i = l ; i <= mid ; ++i) tmp1[i] = poi[i];
	for(int i = mid + 1 ; i <= r ; ++i) tmp2[i] = poi[i];
	int ls = l,rs = mid + 1;
	p = l;
	while(ls <= mid && rs <= r) {
		if(tmp1[ls].y <= tmp2[rs].y) {
			poi[p++] = tmp1[ls++];
		}
		else {
			poi[p++] = tmp2[rs++];
		}
	}
	while(ls <= mid) poi[p++] = tmp1[ls++];
	while(rs <= r) poi[p++] = tmp2[rs++];
}
int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
#else
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
#endif
	scanf("%d%d",&n,&C);
	for(int i = 1 ; i <= n ; ++i) {
		scanf("%d%d",&poi[i].x,&poi[i].y);
		poi[i].id = i;
		fa[i] = i;
	}	
	sort(poi + 1,poi + n + 1);
	solve(1,n);
	for(int i = 1 ; i <= n ; ++i) {
		poi[i].x = 1000000000 - poi[i].x;
	}
	sort(poi + 1,poi + n + 1);
	solve(1,n);
	for(int i = 1 ; i <= n ; ++i) {
		poi[i].y = 1000000000 - poi[i].y;
	}
	sort(poi + 1,poi + n + 1);
	solve(1,n);
	for(int i = 1 ; i <= n ; ++i) {
		poi[i].x = 1000000000 - poi[i].x;
	}
	sort(poi + 1,poi + n + 1);
	solve(1,n);
	for(int i = 1 ; i <= n ; ++i) {
		size[getfa(i)]++;
		if(i == getfa(i)) ++cnt;
		maxsize = max(size[getfa(i)],maxsize);
	}
	printf("%d %d\n",cnt,maxsize);
	return 0;
}