#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
//#define ivorysi
using namespace std;
typedef long long ll;
ll f[(1 << 18) + 5],g[(1 << 18) + 5],h[(1 << 18) + 5];
ll W,C[25];
int n,num[(1 << 18) + 5];

int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
#else
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
#endif
	scanf("%d%lld",&n,&W);
	for(int i = 1 ; i <= n ; ++i) {
		scanf("%lld",&C[i]);

	}
	for(int i = 0 ; i < 1 << n ; ++i) {
		ll sum = 0;
		for(int j = 1 ; j <= n ; ++j) {
			if(i & (1 << (j - 1))) sum += C[j];
		}
		if(sum <= W) f[i] = 1;
	}
	if(f[(1 << n) - 1]) {
		puts("1");
		return 0;
	}
	for(int i = 1 ; i < 1 << n ; ++i) {
		num[i] = num[i - (i & -i)] + 1;
	}
	for(int i = 1 ; i < 1 << n ; i <<= 1) {
		for(int j = 0 ; j  < 1 << n ; j += (i << 1)) {
			for(int k = 0 ; k < i ; ++k) {
				f[i + j + k] += f[j + k];
			}
		}
	} 
	for(int i = 0 ; i < 1 << n ; ++i) g[i] = f[i];
	for(int i = 1 ; i <= n ; ++i) {
		for(int j = 0 ; j < 1 << n ; ++j) {
			g[j] *= f[j];
		}
		ll cnt = 0;
		for(int j = 0 ; j < 1 << n ; ++j) {
			if(num[j] & 1) cnt -= g[j];
			else cnt += g[j];
		}
		if(cnt != 0) {
			printf("%d\n",i + 1);
			break;
		}
	}
	return 0;
}