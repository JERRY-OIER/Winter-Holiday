#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <ctime>
#define MAXN 100010
//#define ivorysi
using namespace std;
typedef long long ll;
int n,m;
int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
#else
	freopen("battle.in","r",stdin);
	freopen("battle.out","w",stdout);
#endif	
	srand(time(0));
	scanf("%d%d",&n,&m);
	if(n == 3 && m == 3) {
		printf("J\nJ\nU\n");
		return 0;
	}
	for(int i = 1 ; i <= m ; ++i) {
		int t = rand() % 3;
		if(t == 0) puts("J");
		else if(t == 1) puts("B");
		else puts("U");	
	}
	return 0;
}