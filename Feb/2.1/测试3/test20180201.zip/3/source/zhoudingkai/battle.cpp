#include<cstdio>
#include<iostream>
using namespace std;
int a,b,c,a1,b1,c1;
int n,m,x[2005],y[2005],z[2005],f[2005];
char s[2005];
int zx(int a,int b)
{
	int r=1;
	while (r>0)
	{
		r=a%b;
		b=a;
		a=r;
	}
	return b;
}
int main()
{
	freopen("battle.in","r",stdin);
	freopen("battle.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
	{
		cin>>s[i]>>a>>b>>c>>a1>>b1>>c1;
		x[i]=a-a1;
		y[i]=b-b1;
		z[i]=c-c1;
		if (s[i]=='J') f[i]=1;else f[i]=-1;
	}
	for (int i=1;i<=m;i++)
	{
		cin>>a>>b>>c>>a1>>b1>>c1;
		a=a-a1;b=b-b1;c=c-c1;	
		for (int j=1;j<=n;j++)
		{
			int flag=f[j];
			int k=zx(a,x[j]);
			if (k<0) flag=flag*-1;
			if (b*k-y[j]*k>=0&&c*k-z[j]*k>=0&&flag>0)
			{
				printf("J\n");
				break;
			}
			if (b*k-y[j]*k<=0&&c*k-z[j]*k<=0&&flag<0)
			{
				printf("B\n");
				break;
			}
			if (j==n) printf("U\n");
		}
	}
	return 0;
}
