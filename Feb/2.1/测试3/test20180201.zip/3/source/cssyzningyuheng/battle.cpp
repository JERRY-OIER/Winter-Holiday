#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<algorithm>
using namespace std;
long long n,m,i,j,k,l,flag,flag2,top,a[310],b[310],c[310],d[310],e[310],f[310],
		  o[1000020],p[1000020],q[1000020],r[2020],s[2020],t[2020],u[2020],v[2020],w[2020];
char s1[310];
int main(){
	freopen("battle.in","r",stdin);
	freopen("battle.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(i=1;i<=n;i++)
		cin>>s1[i]>>a[i]>>b[i]>>c[i]>>d[i]>>e[i]>>f[i];
	for(i=1;i<=100;i++)
		for(j=1;j<=100;j++)
			for(k=1;k<=100;k++){
				for(l=1;l<=n;l++)
					if(((a[l]*i+b[l]*j+c[l]*k>=d[l]*i+e[l]*j+f[l]*k)+(s1[l]=='J'))==1){
						flag=1;
						break;
					}
				if(flag==0){
					top++;
					o[top]=i;
					p[top]=j;
					q[top]=k;
				}
				flag=0;
			}
	for(i=1;i<=m;i++)
		scanf("%lld%lld%lld%lld%lld%lld",&r[i],&s[i],&t[i],&u[i],&v[i],&w[i]);
	for(i=1;i<=m;i++){
		for(j=1;j<=top;j++)
			if(r[i]*o[j]+s[i]*p[j]+t[i]*q[j]>u[i]*o[j]+v[i]*p[j]+w[i]*q[j])
				flag++;
			else if(r[i]*o[j]+s[i]*p[j]+t[i]*q[j]<u[i]*o[j]+v[i]*p[j]+w[i]*q[j])
				flag2++;
		if(flag==top)
			cout<<"J"<<endl;
		else if(flag2==top)
			cout<<"B"<<endl;
		else
			cout<<"U"<<endl;
		flag=0;flag2=0;
	}
	return 0;
}


















