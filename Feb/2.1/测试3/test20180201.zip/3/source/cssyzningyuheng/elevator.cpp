#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<algorithm>
using namespace std;
long long n,c,i,j,k,l,a[30],book[30],book2[30],flag,flag2,ans=20,max1,max2;
int main(){
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
	scanf("%lld%lld",&n,&c);
	for(i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	sort(a+1,a+n+1);
	for(i=1;i<=n;i++)
		if(a[i]+max1<=c){
			max1+=a[i];
		}
		else{
			max1=a[i];
			max2++;
		}
	ans=min(ans,max2+1);
	max1=0;
	max2=0;
	for(i=n;i>=1;i--)
		if(a[i]+max1<=c){
			max1+=a[i];
		}
		else{
			max1=a[i];
			max2++;
		}
	ans=min(ans,max2+1);
	i=0;j=n;max1=a[n];max2=0;
	while(i+1<j){
		if(a[i+1]+max1<=c){
			i++;
			max1+=a[i];
		}
		else{
			j--;
			max1=a[j];
			max2++;
		}
	}
	ans=min(ans,max2+1);
	max1=0;max2=0;
	while(flag!=n){
		for(i=n;i>=1;i--)
			if(a[i]+max1<=c&&book[i]==0){
				max1+=a[i];
				book[i]=1;
				flag++;
			}
		max2++;
		max1=0;
	}
	ans=min(ans,max2);
	flag=0;max1=0;max2=0;
	for(k=1;k<=n;k++){
		for(i=1;i<=n;i++){
			l=1000000001;
			for(j=1;j<=k;j++)
				if(book2[j]<l){
					l=book2[j];
					flag2=j;
				}
			book2[flag2]+=a[i];
		}
		for(i=1;i<=k;i++){
			if(book2[i]>c)
				flag=1;
			book2[i]=0;
		}
		if(flag==0){
			max2=k;
			break;
		}
		flag=0;
	}
	ans=min(ans,max2);
	flag=0;max1=0;max2=0;flag=0;
	for(k=1;k<=n;k++){
		flag2=0;
		for(i=1;i<=k;i++)
			book2[i]=0;
		for(i=1;i<=n;i++){
			while(1){
				if(book2[flag2%k+1]+a[i]<=c){
					book2[flag2%k+1]+=a[i];
					flag2++;
					break;
				}
				flag2++;
				if(flag2>n*k){
					flag=1;
					break;
				}		
			}
		}
		
		if(flag==0&&max2==0)
			max2=k;
		flag=0;
	}
	ans=min(ans,max2);
	flag=0;max1=0;max2=0;flag=0;
	for(k=1;k<=n;k++){
		flag2=0;
		for(i=1;i<=k;i++)
			book2[i]=0;
		for(i=n;i>=1;i--){
			while(1){
				if(book2[flag2%k+1]+a[i]<=c){
					book2[flag2%k+1]+=a[i];
					flag2++;
					break;
				}
				flag2++;
				if(flag2>n*k){
					flag=1;
					break;
				}		
			}
			
		}
		if(flag==0&&max2==0)
			max2=k;
		flag=0;
	}
	ans=min(ans,max2);
	cout<<ans<<endl;
	return 0;
}


















