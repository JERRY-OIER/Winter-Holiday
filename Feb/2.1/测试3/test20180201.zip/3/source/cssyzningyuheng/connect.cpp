#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<algorithm>
using namespace std;
int n,c,i,j,k,l,x[100010],y[100010],top,fir[100010],book[100010],nex[3000010],to[3000010],ans,max1,max2;
struct ll{
	int p,q,r;
}o[100010];
int lj(int u,int v){
	top++;
	to[top]=v;
	nex[top]=fir[u];
	fir[u]=top;
}
int ss(int v){
	book[v]=i;
	max1++;
	int top1=fir[v];
	while(top1!=0){
		if(book[to[top1]]==0)
			ss(to[top1]);
		top1=nex[top1];
	}
}
bool cmp1(ll w,ll z){
	return w.p<z.p||w.p==z.p&&w.q<z.q;
}
bool cmp2(ll w,ll z){
	return w.q<z.q||w.q==z.q&&w.p<z.p;
}
bool cmp3(ll w,ll z){
	return w.p+w.q<z.p+z.q;
}
bool cmp4(ll w,ll z){
	return w.p-w.q<z.p-z.q;
}
int main(){
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	scanf("%d%d",&n,&c);
	if(n<=1000){
		for(i=1;i<=n;i++)
			scanf("%d%d",&x[i],&y[i]);
		for(i=1;i<=n;i++)
			for(j=i+1;j<=n;j++)
				if(abs(x[i]-x[j])+abs(y[i]-y[j])<=c){
					lj(i,j);
					lj(j,i);
				}
		for(i=1;i<=n;i++)
			if(book[i]==0){
				ans++;
				max1=0;
				ss(i);
				max2=max(max1,max2);
			}
	}
	else{
		for(i=1;i<=n;i++){
			scanf("%d%d",&o[i].p,&o[i].q);
			o[i].r=i;
		}
		sort(o+1,o+n+1,cmp1);
		for(i=2;i<=n;i++)
			if(abs(o[i].p-o[i-1].p)+abs(o[i].q-o[i-1].q)<=c){
				lj(o[i-1].r,o[i].r);
				lj(o[i].r,o[i-1].r);
			}
		sort(o+1,o+n+1,cmp2);
		for(i=2;i<=n;i++)
			if(abs(o[i].p-o[i-1].p)+abs(o[i].q-o[i-1].q)<=c){
				lj(o[i-1].r,o[i].r);
				lj(o[i].r,o[i-1].r);
			}
		sort(o+1,o+n+1,cmp3);
		for(i=2;i<=n;i++)
			if(abs(o[i].p-o[i-1].p)+abs(o[i].q-o[i-1].q)<=c){
				lj(o[i-1].r,o[i].r);
				lj(o[i].r,o[i-1].r);
			}
		sort(o+1,o+n+1,cmp4);
		for(i=2;i<=n;i++)
			if(abs(o[i].p-o[i-1].p)+abs(o[i].q-o[i-1].q)<=c){
				lj(o[i-1].r,o[i].r);
				lj(o[i].r,o[i-1].r);
			}
		for(i=1;i<=n;i++)
			if(book[i]==0){
				ans++;
				max1=0;
				ss(i);
				max2=max(max1,max2);
			}
	}
	printf("%d %d\n",ans,max2);
	return 0;
}
