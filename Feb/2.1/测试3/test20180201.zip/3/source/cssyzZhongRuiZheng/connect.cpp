#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
int n, c;
struct dd {
	int x, y, fa;
}a[100001];
int find(int x) {
	if (x == a[x].fa) return x;
	return a[x].fa = find(a[x].fa);
}
int cnt[100001];
int main() {
	freopen ("connect.in", "r", stdin);
	freopen ("connect.out", "w", stdout);
	cin>>n>>c;
	for (int i = 1; i <= n; i++) {
		scanf ("%d%d", &a[i].x, &a[i].y);
		a[i].fa = i;
	}
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			if (abs(a[j].x - a[i].x) + abs(a[j].y - a[i].y) <= c) {
				a[find(j)].fa = find(i);
			}
		}
	}
	int jsq = 0;
	for (int i = 1; i <= n; i++) {
		if (a[i].fa == i) {
			jsq++;
		}
	}
	cout<<jsq<<" ";
	for (int i = 1; i <= n; i++) {
		++cnt[find(i)];
	}
	int flag = 0;
	for (int i = 1; i <= n; i++) {
		flag = max(flag, cnt[i]);
	}
	cout<<flag<<endl;
	return 0;
}
