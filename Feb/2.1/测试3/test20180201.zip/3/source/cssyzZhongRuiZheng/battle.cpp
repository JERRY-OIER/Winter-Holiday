#include <iostream>
#include <cstdio>
using namespace std;
int n, m, cnt;
struct dd{
	int c1,c2,c3;
}cz[90001];
int main() {
	freopen ("battle.in","r",stdin);
	freopen ("battle.out","w",stdout);
	cin>>n>>m;
	for (int i = 1; i <= n; i++){
		char x;
		int j1, j2, j3, b1, b2, b3;
		scanf ("\n%c ", &x);
		
		scanf("%d%d%d%d%d%d", &j1, &j2, &j3, &b1, &b2, &b3);
		if (x == 'J') {
			cz[i].c1 = j1 - b1;
			cz[i].c2 = j2 - b2;
			cz[i].c3 = j3 - b3;
		}
		 
		else {
			cz[i].c1 = b1 - j1;
			cz[i].c2 = b2 - j2;
			cz[i].c3 = b3 - j3;
		}
	}
	
	cnt = n;
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			cz[++cnt].c1 = cz[i].c1 + cz[j].c1;
			cz[cnt].c2 = cz[i].c2 + cz[j].c2;
			cz[cnt].c3 = cz[i].c3 + cz[j].c3;
		}
	}

	for (int i = 1; i <= m; i++) {
		int j1, j2, j3, b1, b2, b3;
		scanf("%d%d%d%d%d%d",&j1,&j2,&j3,&b1,&b2,&b3);
		int aaa = j1 - b1, bbb = j2 - b2, ccc = j3 - b3, flag = 0;
		for (int j = 1; j <= cnt; j++) {
			if (aaa >= cz[j].c1 && bbb >= cz[j].c2 && ccc >= cz[j].c3) {
				printf("J\n");
				flag++;
				break;
			}
			if (aaa <= -cz[j].c1 && bbb <= -cz[j].c2 && ccc <= -cz[j].c3) {
				printf("B\n");
				flag++;
				break;
			}
		}
		if (!flag) {
			cout<<"U\n";
		}
	}
	return 0;
}
