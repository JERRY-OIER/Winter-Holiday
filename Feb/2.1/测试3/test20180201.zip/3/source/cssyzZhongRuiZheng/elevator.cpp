#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std;
int n, w, c[20], ans, jsq;
bool used[20];
int sy[20];
int main() {
	freopen("elevator.in", "r", stdin);
	freopen("elevator.out", "w", stdout);
	cin>>n>>w;
	for (int i = 1; i <= n; i++ ) {
		scanf ("%d", &c[i]);
		sy[i] = w;
	}
	sort(c + 1, c + n + 1);
	for (int i = n; i >= 1; i--) {
		if (!used[i]) {
			used[i] = 1;
			int flag = 0;
			for (int j = 1; j <= n; j++) {
				if (j != i && used[j] && sy[j] >= c[i]) {
					sy[j] -= c[i];
					sy[i] = sy[j];
					flag++;
					break;
				}
			}
			if (flag) continue;
			ans++;
			sy[i] -= c[i];
			int x = w - c[i];
			int y = lower_bound(c + 1, c + n + 1, x) - c;
			if (x != c[y]) y--;
			while (used[y]) {
				y--;
			}
			used[y] = 1;
			sy[i] -= c[y];
			sy[y] = sy[i];
		}
	}
	cout<<ans<<endl;
	return 0;
}
