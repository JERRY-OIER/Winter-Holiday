#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,j1,j2,j3,b1,b2,b3;
struct data{
    int t1,t2,t3;
}comp[501000];
int cnt,t;
char sym;
int main()
{
    freopen("battle.in","r",stdin);
    freopen("battle.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;++i)
    {
        cin>>sym;
        scanf("%d%d%d%d%d%d",&j1,&j2,&j3,&b1,&b2,&b3);
        if(sym=='J')
        {
            comp[++cnt].t1=j1-b1;
            comp[cnt].t2=j2-b2;
            comp[cnt].t3=j3-b3;
        }
        if(sym=='B')
        {
            comp[++cnt].t1=b1-j1;
            comp[cnt].t2=b2-j2;
            comp[cnt].t3=b3-j3;
        }
    }
    //zhe li xun huan^^^;
    for(int i=1;i<=n;++i)
        for(int j=i+1;j<=n;++j)
        {
            comp[++cnt].t1=comp[i].t1+comp[j].t1;
            comp[cnt].t2=comp[i].t2+comp[j].t2;
            comp[cnt].t3=comp[i].t3+comp[j].t3;
        }
    comp[++cnt].t1=0;
    comp[cnt].t2=comp[cnt].t3=0;
    for(int i=1;i<=m;++i)
    {
        scanf("%d%d%d%d%d%d",&j1,&j2,&j3,&b1,&b2,&b3);
        j1-=b1;j2-=b2;j3-=b3;
        if(j1==0&&j2==0&&j3==0)
        {printf("U\n");continue;}
        for(t=1;t<=cnt;++t)
        {
            if(j1>=comp[t].t1&&j2>=comp[t].t2&&j3>=comp[t].t3)
            {
                printf("J\n");
                break;
            }
            else if(j2<=comp[t].t1&&j2<=comp[t].t2&&j3<=comp[t].t3)
            {
                printf("B\n");
                break;
            }
        }
        if(t<=cnt)continue;
        printf("U\n");
    }
    return 0;
}
