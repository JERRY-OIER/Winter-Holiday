#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,w,maxn;
int ans;
int c[30],d[1<<19][20];
int main()
{
    freopen("elevator.in","r",stdin);
    freopen("elevator.out","w",stdout);
    scanf("%d%d",&n,&w);
    memset(d,-1,sizeof(d));
    maxn=(1<<n)-1;
    for(int i=0;i<n;++i)scanf("%d",&c[i]);
    for(int i=0;i<n;++i)
        d[1<<i][1]=w-c[i];
    for(int i=1;i<=maxn;++i)
    {
        for(int j=1;j<=n;++j)
        {
            if(d[i][j]==-1)continue;
            for(int k=0;k<n;++k)
            {
                if(i&(1<<k))continue;
                if(c[k]>d[i][j])
                    d[i|(1<<k)][j+1]=max(d[i|(1<<k)][j+1],w-c[k]);
                else
                    d[i|(1<<k)][j]=max(d[i|(1<<k)][j],d[i][j]-c[k]);
            }
        }
    }
    for(int i=1;i<=n;++i)
        if(d[maxn][i]>-1)
        {ans=i;break;}
    printf("%d\n",ans);
    return 0;
}
