//brute_force
//xian duan shu ma?
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,c,ans1,ans2,ta;
int book[10010];
struct data{
    int to,nxt;
}con[100100];
struct node{
    int x,y;
}nd[10010];
int head[10010],cnt;
bool cmp(node a,node b)
{   return a.x<b.x;}
void link(int x,int y)
{
    con[++cnt].to=y;
    con[cnt].nxt=head[x];
    head[x]=cnt;
}
void search(int x)
{
    book[x]=1;ta++;
    for(int i=head[x];i;i=con[i].nxt)
    {
        if(book[con[i].to])continue;
        search(con[i].to);
    }
}
int main()
{
    freopen("connect.in","r",stdin);
    freopen("connect.out","w",stdout);
    scanf("%d%d",&n,&c);
    for(int i=1;i<=n;++i)scanf("%d%d",&nd[i].x,&nd[i].y);
    sort(nd+1,nd+n+1,cmp);
    for(int i=1;i<=n;++i)
        for(int j=i+1;j<=n;++j)
        {   
            if(abs(nd[i].x-nd[j].x)+abs(nd[i].y-nd[j].y)<=c)
            link(i,j),link(j,i);
            if(nd[j].x-nd[i].x>c)break;
        }
    for(int i=1;i<=n;++i)
    {
        if(book[i])continue;
        ans1++;ta=0;search(i);
        ans2=max(ans2,ta);
    }
    printf("%d %d\n",ans1,ans2);
    return 0;
}
