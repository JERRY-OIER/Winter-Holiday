#include<bits/stdc++.h>
using namespace std;
int cow[101];
int n,m,min_,rlans=101;
void dfs(int remain,int ans,int st)
{
	//for(int k=1;k<(1<<n);k<<=1) cout<<(bool)(st&k);
//	cout<<'\n';
	if(!st)
	{
		rlans=min(ans , rlans);
		return ;
	}
	if(ans>=rlans) return ;
	bool bre=0;
	for(int i=1,k=1;i<=n;i++,k<<=1)
		if(cow[i]<=remain && st&k)
		{
			dfs(remain-cow[i],ans,st-k);
			bre=1;
		}
	if(bre) return ;
	for(int i=1,k=1;i<=n;i++,k<<=1)
		if(st&k)
		{
			dfs(m-cow[i],ans+1,st-k);
		}
	return ;
}
int main()
{
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&cow[i]);
		min_+=cow[i];
	}
	min_=(min_+m-1)/m;
	if(n>12)
	{
		printf("%d\n",(n+min_-1)>>1);
		return 0;
	}
	printf("%d\n",(n+min_-1)>>1);
	dfs(m,1,(1<<n)-1);
	printf("%d\n",rlans);
	return 0;
}
