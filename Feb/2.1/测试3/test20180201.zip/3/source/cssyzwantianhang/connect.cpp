#include<bits/stdc++.h>
using namespace std;
struct dot
{
	int x;
	int y;
	int fa;
	int w;
};
dot d[30010];
bool operator < (dot x,dot y)
{
	return x.x==y.y?x.y<y.y:x.x<y.x;
}
int operator - (dot x,dot y)
{
	return abs(x.x-y.x)+abs(x.y-y.y);
}
int find(int x)
{
//	cout<<x<<d[x].fa<<'\n';
	if(d[x].fa==x) return x;
	int f=find(d[x].fa);
	d[f].w+=d[x].w;
	d[x].w=0;
	return d[x].fa=f;
}
int main()
{
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	int n,c;
	scanf("%d %d",&n,&c);
	for(int i=1;i<=n;i++)
	{
		scanf("%d %d",&d[i].x,&d[i].y);
	}
	sort(d+1,d+n+1);
	for(int i=1;i<=n;i++)
	{
		d[i].fa=i;
		d[i].w=1;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n && d[j].x-d[i].x<=c;j++)
		{
			if(d[i]-d[j]<=c && d[i].fa!=d[j].fa)
			{
				d[find(j)].fa=find(i);
				find(j);
			}
		}
	}
	int ans1=0,ans2=0;
	for(int i=1;i<=n;i++)
		if(d[i].fa==i)
		{
			ans1++;
			ans2=max(ans2 , d[i].w);
		}
	cout<<'\n';
	printf("%d %d\n",ans1,ans2);
	return 0;
}

