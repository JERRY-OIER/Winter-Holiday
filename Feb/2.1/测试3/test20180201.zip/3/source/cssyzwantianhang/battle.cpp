#include<bits/stdc++.h>
using namespace std;
int winb[90010],winc[90010];
int gcd(int x,int y)
{
	if(!y) return x;
	return gcd(y,x%y);
}
int main()
{	
	freopen("battle.in","r",stdin);
	freopen("battle.out","w",stdout);
	int n,m;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		char ch;
		int a1,b1,c1,a2,b2,c2;
		scanf("%c %d %d %d %d %d %d",&ch,&a1,&b1,&c1,&a2,&b2,&c2);
		if(ch=='J')
		{
			a[i]=a1-a2;
			b[i]=b1-b2;
			c[i]=c1-c2;
		}
		else
		{
			a[i]=a2-a1;
			b[i]=b2-b1;
			c[i]=c2-c1;
		}
		if(a[i]>0) nt1[++p1]=i;
		if(a[i]<0) nt2[++p2]=i;
		if(a[i]==0 && b[i]*c[i]<0)
		{
			winb[++p]=b[i];
			winc[p]=c[i];
			if(winb>0) wt1[++w1]=p;
			if(winb<0) wt2[++w2]=p;
		}
	}
	for(int i1=1;i1<=p1;i1++)
	{
		int i=nt[i1];
		for(int i2=1;i2<=p2;i2++)
		{
			int j=nt[i2];
			int g=gcd(a[i],-a[j]);
			winb[++p]=b[i]*(-a[j])/g+b[j]*a[i]/g;
			winc[p]=c[i]*(-a[i])/g+c[j]*a[i]/g;
			if(winb[p]*winc[p]>0) p--;
			else if(winb[p]>0) wt1[++w1]=p;
			else if(winb[p]<0) wt2[++w2]=p;
		}
	}
	if(w1) int q1b=winb[wt1[1]],q1c=winc[wt1[1]];
	for(int i1=2;i1<=w1;i1++)
	{
		int i=wt1[i1];
		int g=gcd(q1b,winb[i]);
		if(winc[i]*q1b/g<q1c*winb[i]/g) q1b=winb[i],q1c=winc[i];
	}
	if(w2) int q2b=winb[wt2[1]],q2c=winc[wt2[1]];
	for(int i2=2;i2<=w2;i2++)
	{
		int i=wt2[i2];
		int g=gcd(q2b,winb[i]);
		if(winc[i]*q2b/g<q2c*winb[i]/g) q2b=winb[i],q2c=winc[i];
	}
	for(int i=1;i<=m;i++)
	{
		int a1,b1,c1,a2,b2,c2;
		scanf("%d %d %d %d %d %d",&a1,&b1,&c1,&a2,&b2,&c2);
		a[0]=a1-a2;
		b[0]=b1-b2;
		c[0]=c1-c2;
		if(a[0]>0)
		{
			for(int i1=)
	return 0;
}
