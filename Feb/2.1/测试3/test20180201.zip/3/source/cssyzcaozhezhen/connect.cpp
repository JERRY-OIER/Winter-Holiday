#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,c;
struct P{
	int x,y;
}point[100010];
int abs(int x)
{
	if(x>0)  return x;
	else     return -x;
}
int x[100010];
int y[100010];
int book[100010],ans;
int boss[100010];
bool cmp(P a,P b)
{
	if(a.x<b.x)  		return true;
	else if(a.x>b.x)    return false;
	else{
		if(a.y<b.y)     return true;
		else            return false;
	}
}
bool check(int p1,int p2)
{
	if(abs(x[p1]-x[p2])+abs(y[p1]-y[p2])<=c)   return true;
	else                                       return false;
}
bool work(int p)
{
	int l=lower_bound(x+1,x+n+1,x[p]-c)-x;
	int r=upper_bound(x+1,x+n+1,x[p]+c)-x-1;
	int sum=0,flag=0;
	for(int i=l;i<=r;i++)
	{
		if(i!=p&&check(p,i)==true)
		{
			if(book[i]==1)  flag=1;
			book[i]=1;
		}
	}
	if(flag==1)  return false;
	else         return true;
}
int dfs(int p)
{
	book[p]=1;
	int l=lower_bound(x+1,x+n+1,x[p]-c)-x;
	int r=upper_bound(x+1,x+n+1,x[p]+c)-x-1;
	int sum=0;
	for(int i=l;i<=r;i++)
	{
		if(i!=p&&book[i]==0)
		{
			sum++;
		}
	}
	if(sum==0)  return 1;
	sum=0;
	for(int i=l;i<=r;i++)
	{
		if(i!=p&&book[i]==0)
		{
			book[i]=1;
			sum+=dfs(i);
		}
	}
	return sum+1;	
}
int main()
{
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	scanf("%d%d",&n,&c);
	for(int i=1;i<=n;i++)   scanf("%d%d",&point[i].x,&point[i].y);
	sort(point+1,point+n+1,cmp);
	for(int i=1;i<=n;i++)   x[i]=point[i].x;
	for(int i=1;i<=n;i++)   y[i]=point[i].y;
	for(int i=1;i<=n;i++)
	{
		if(book[i]==0)
		{
			if(work(i)==true)  ans++;
		}
	}
	printf("%d ",ans);
	memset(book,0,sizeof(book));
	ans=0;
	for(int i=1;i<=n;i++)
	{
		if(book[i]==0)
		{
			ans=max(ans,dfs(i));			
		}
	}
	printf("%d\n",ans);
	return 0;
}
