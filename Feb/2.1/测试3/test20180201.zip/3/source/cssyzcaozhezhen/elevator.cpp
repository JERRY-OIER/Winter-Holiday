#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int dp[1<<18+2][20];
int sum[1<<18+2][20];
int n,w;
int c[20];
int main()
{
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
	scanf("%d%d",&n,&w);
	for(int i=1;i<=n;i++)   scanf("%d",&c[i]);
	int cntx=0;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=n;j++)
	    if(i!=j&&c[i]+c[j]<=w)  cntx++;
	if(cntx==0)
	{
		printf("%d\n",n);
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		dp[1<<(i-1)][1]=1;
		sum[1<<(i-1)][1]=c[i];
	}
	
	for(int j=1;j<=n;j++)
	{
		for(int i=1;i<=(1<<(n-1));i++)
		{
			if(dp[i][j]==1)
			{
				for(int k=1;k<=n;k++)
				{
					if((i&(1<<(k-1)))==0&&sum[i][j]+c[k]<=w)
					{
						dp[i|(1<<(k-1))][j]=1;
						sum[i|(1<<(k-1))][j]=sum[i][j]+c[k];
					} 		
				}
			}
		}
		for(int i=1;i<=(1<<n);i++)
		{
			if(dp[i][j]==1)
			{
				for(int k=1;k<=n;k++)
				{
					if((i&1<<(k-1))==0)
					{
						dp[i|(1<<(k-1))][j+1]=1;
						sum[i|(1<<(k-1))][j+1]=(sum[i|(1<<(k-1))][j+1]+c[k])%w;
					}
				}
			}
		}
	}
	int ans;
	for(int i=1;i<=n+1;i++)
	{
		if(dp[(1<<n)-1][i]==1)
		{
			ans=i;
			break;
		}
	}
	printf("%d\n",ans);
	return 0;
}
