#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 20
using namespace std;
int n,w,c[N],dp[1<<19],sta;
bool ojbk(int i,int x)
{	
	if (i==x) return 0;
	int sum=0;
	for (int j=0;j<n;j++)
		if (((i&(1<<j))!=0 && (x&(1<<j))==0)) return 0;
		else if ((i&(1<<j))==0 && (x&(1<<j))!=0) sum+=c[j+1];
	return sum<=w;
}
int F(int x)
{
	int ret=n+1;
	if (dp[x]!=-1) return dp[x];
	for (int i=0;i<(1<<n);i++)
		if (ojbk(i,x)) ret=min(ret,F(i)+1);
	return dp[x]=ret;
}
int main()
{
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
	scanf("%d%d",&n,&w);
	for (int i=1;i<=n;i++)
		scanf("%d",c+i);
	memset(dp,-1,sizeof(dp));
	dp[0]=0;
	printf("%d\n",F((1<<n)-1));
	return 0;
}
/*
4 10
5
6
3
7
*/
