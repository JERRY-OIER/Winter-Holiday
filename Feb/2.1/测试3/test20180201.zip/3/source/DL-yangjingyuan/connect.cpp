#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 100005
using namespace std;
int n,fa[N],sz[N],c,ans,mx;
struct node
{
	int x,y,id;
	void read() {scanf("%d%d",&x,&y);}
	int c1(){return x+y;}
	int c2(){return x-y;}
}p[N],tmp[N];
inline int dis(const node &a,const node &b){return abs(a.x-b.x)+abs(a.y-b.y);}
inline int find(int x){return fa[x]=fa[x]==x?x:find(fa[x]);}
void merge(int i,int j)
{
//	printf("I TRY TO MERGE %d & %d\n",i,j);
	if (i==0 || j==0) return ;
	int x=find(i),y=find(j);
	if (x==y) return;
	if (sz[x]>sz[y]) swap(x,y);
	fa[x]=y,sz[y]+=sz[x];
}
void solve1()
{
	for (int i=1;i<=n;i++)
		for (int j=i+1;j<=n;j++)
			if (dis(p[i],p[j])<=c)
				merge(i,j);
	for (int i=1;i<=n;i++)
		if (find(i)==i)
			ans++,mx=max(mx,sz[i]);
	printf("%d %d\n",ans,mx);
}
int ef(int l,int r,int w)
{
//	printf("now is :");
//	for (int i=l;i<=r;i++)
//		printf("%d%c",p[i].c1()," \n"[i==r]);
	if (p[l].c1()>w || p[r].c1()<w-c) return 0;
	if (p[r].c1()<=w && p[r].c1()>=w-c) return r;
//	for (int i=l;i<=r;i++)
//		if (p[i+1].c1()<=w) continue;
//		else if (p[i].c1()>=w-c) return i;
//		else return 0;
	while (l<r) 
	{
		int mid=l+r+1>>1;
		if (p[mid].c1()<=w) l=mid;
		else r=mid-1;
	}
	if (p[l].c1()>=w-c) return l;
	return 0;
}
void merge_sort1(int l,int r)
{
	if (l==r) return ;
	int mid=l+r>>1,i=l,j=mid+1,k;
	merge_sort1(l,mid),merge_sort1(mid+1,r);
	for (int qwq=l;qwq<=mid;qwq++)
	{
		int qaq=ef(mid+1,r,p[qwq].c1()+c);
	//	printf("Now L & R is %d %d\n",l,r);
	//	printf("I now have %d and I want to find %d , I get %d\n",p[qwq].c1(),p[qwq].c1()+c,p[qaq].c1());
		merge(p[qwq].id,p[qaq].id);
	}
	for (int qwq=mid+1;qwq<=r;qwq++)
	{
		int qaq=ef(l,mid,p[qwq].c1()+c);
//		printf("Now L & R is %d %d\n",l,r);
//		printf("I now have %d and I want to find %d , I get %d\n",p[qwq].c1(),p[qwq].c1()+c,p[qaq].c1());
		merge(p[qwq].id,p[qaq].id);
	}
	for (k=l;i<=mid && j<=r;k++)
		if (p[i].c1()<p[j].c1()) tmp[k]=p[i++];
		else tmp[k]=p[j++];
	while (i<=mid) tmp[k++]=p[i++];
	while (j<=r) tmp[k++]=p[j++];
	for (int i=l;i<=r;i++)
		p[i]=tmp[i];
}
void merge_sort2(int l,int r)
{
	if (l==r) return ;
	int mid=l+r>>1,i=l,j=mid+1,k;
	merge_sort2(l,mid),merge_sort2(mid+1,r);
	for (int qwq=l;qwq<=mid;qwq++)
	{
		int qaq=ef(mid+1,r,p[qwq].c2()+c);
		merge(p[qwq].id,p[qaq].id);
	}
	for (int qwq=mid+1;qwq<=r;qwq++)
	{
		int qaq=ef(l,mid,p[qwq].c2()+c);
		merge(p[qwq].id,p[qaq].id);
	}
	for (k=l;i<=mid && j<=r;k++)
		if (p[i].c2()<p[j].c2()) tmp[k]=p[i++];
		else tmp[k]=p[j++];
	while (i<=mid) tmp[k++]=p[i++];
	while (j<=r) tmp[k++]=p[j++];
	for (int i=l;i<=r;i++)
		p[i]=tmp[i];
}
void solve2()
{
	merge_sort1(1,n);
//	for (int i=1;i<=n;i++)
//		swap(p[i].y,p[i].x),p[i].x=-p[i].x;
//	merge_sort1(1,n);
//	merge_sort2(1,n);
//	for (int i=1;i<=n;i++)
	//	printf("%d%c",p[i].c1()," \n"[i==n]);
	for (int i=1;i<=n;i++)
		if (find(i)==i)
			ans++,mx=max(mx,sz[i]);
	printf("%d %d\n",ans,mx);
}
int main()
{
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	scanf("%d%d",&n,&c);
	for (int i=1;i<=n;i++)
		p[i].read(),p[i].id=fa[i]=i,sz[i]=1;
	if (n<=5000) solve1();
	else solve2();
	return 0;
}
/*
4 2
1 1
3 3
2 2
10 10
*/
