#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 205
using namespace std;
int n,m,vic[N],bat[N][10];
char s[N];
int main()
{
	freopen("battle.in","r",stdin);
	freopen("battle.out","w",stdout);
	puts("J");
	puts("J");
	puts("U");
	return 0;
}
