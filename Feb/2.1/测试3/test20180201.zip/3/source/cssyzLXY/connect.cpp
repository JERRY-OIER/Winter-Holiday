#include <bits/stdc++.h>

using namespace std;

const int MAXN = 100000;

struct Node {
	int x;
	int y;
};

int top;
int fi[MAXN + 1];
vector<int>ne;
vector<int>to;
bool arrive[MAXN + 1];
Node node[MAXN + 1];

void add(int, int);

int main() {
	freopen("connect.in", "r", stdin);
	freopen("connect.out", "w", stdout);
	int N;
	int C;
	scanf("%d%d", &N, &C);
	for (int i = 1; i <= N; i++) scanf("%d%d", &node[i].x, &node[i].y);
	ne.push_back(0);
	to.push_back(0);
	for (int i = 1; i <= N; i++) {
		for (int j = i + 1; j <= N; j++) {
			int far = abs(node[i].x - node[j].x) + abs(node[i].y - node[j].y);
			if (far <= C) {
				add(i, j);
				add(j, i);
			}
		}
	}
	int haveK = 0;
	int maxK = 0;
	for (int i = 1; i <= N; i++) {
		if (arrive[i]) continue;
		arrive[i] = true;
		haveK++;
		int ans = 0;
		queue<int>q;
		q.push(i);
		while (!q.empty()) {
			int f = q.front();
			q.pop();
			ans++;
			for (int j = fi[f]; j; j = ne[j]) {
				if (arrive[to[j]]) continue;
				arrive[to[j]] = true;
				q.push(to[j]);
			}
		}
		maxK = max(maxK, ans);
	}
	printf("%d %d\n", haveK, maxK);
	return 0;
}

void add(int u, int v) {
	top++;
	ne.push_back(fi[u]);
	to.push_back(v);
	fi[u] = top;
}
