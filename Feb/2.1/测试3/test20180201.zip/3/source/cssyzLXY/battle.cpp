#include <bits/stdc++.h>

using namespace std;
const int MAXN = 300;

struct Zero {
	int a;
	int b;
	int c;
};

Zero z[MAXN + 1];

int main() {
	freopen("battle.in", "r", stdin);
	freopen("battle.out", "w", stdout);
	int N;
	int M;
	scanf("%d%d", &N, &M);
	for (int i = 1; i <= N; i++) {
		char buff[5];
		memset(buff, 0, sizeof(buff));
		int j1, j2, j3;
		int b1, b2, b3;
		scanf("%s%d%d%d%d%d%d", buff, &j1, &j2, &j3, &b1, &b2, &b3);
		if (buff[0] == 'J') {
			z[i].a = j1 - b1;
			z[i].b = j2 - b2;
			z[i].c = j3 - b3;
		}
		else {
			z[i].a = b1 - j1;
			z[i].b = b2 - j1;
			z[i].c = b3 - j3;
		}
	}
	for (int i = 1; i <= M; i++) printf("J\n");
	return 0;
}
