#include <bits/stdc++.h>

using namespace std;
const int MAXN = 18;

struct Ele {
	int usedN;
	int canPu;
	int okCow;
	int sumC;
};

int C[MAXN + 1];
bool away[MAXN + 1];
int way[1000000 + 1];
bool can[1000000 + 1];

int main() {
	freopen("elevator.in", "r", stdin);
	freopen("elevator.out", "w", stdout);
	int N;
	int W;
	scanf("%d%d", &N, &W);
	for (int i = 1; i <= N; i++) scanf("%d", &C[i]);
	if (W <= 1000000) {
		int need = 0;
		int ok = 0;
		while (ok < N) {
			need++;
			memset(can, 0, sizeof(can));
			memset(way, 0, sizeof(way));
			can[0] = true;
			int maxSize = 0;
			for (int i = 1; i <= N; i++) {
				if (away[i]) continue;
				for (int j = W; j >= C[i]; j--) {
					if (can[j - C[i]] && !can[j]) {
						can[j] = true;
						way[j] = way[j - C[i]] | (1 << (i - 1));
						if (j > maxSize) maxSize = j;
					}
				}
			}
			for (int i = 1; i <= N; i++) {
				if (way[maxSize] & (1 << (i - 1))) {
					away[i] = true;
					ok++;
				}
			}
		}
		printf("%d\n", need);
	}
	else {
		Ele begin;
		begin.usedN = 0;
		begin.canPu = 0;
		begin.okCow = 0;
		begin.sumC = 0;
		for (int i = 1; i <= N; i++) begin.sumC += C[i];
		queue<Ele>q;
		q.push(begin);
		int minUse = N;
		while (!q.empty()) {
			Ele f = q.front();
			q.pop();
			for (int i = 1; i <= N; i++) {
				if (f.okCow & (1 << (i - 1))) continue;
				Ele go = f;
				if (go.canPu < C[i]) {
					go.usedN++;
					go.canPu = W;
				}
				go.canPu -= C[i];
				go.okCow |= (1 << (i - 1));
				go.sumC -= C[i];
				if (go.usedN + (go.sumC / W) >= minUse) continue;
				if (go.okCow == ((1 << N) - 1)) minUse = min(minUse, go.usedN);
				else q.push(go);
			}
		}
		printf("%d\n", minUse);
	}
	return 0;
}
