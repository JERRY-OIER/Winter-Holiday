#include<cstdio>
#include<algorithm>
#define N (1<<19)+10
using namespace std;
int n,c,a[20],now,f[N],rem[N];

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

int main()
{
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
	n=read();c=read();
	for (int i=1;i<=n;i++) a[i]=read();
	now=(1<<n)-1;
	for (int i=0;i<=now;i++)
	{
		f[i]=n;
		rem[i]=c;
	}
	f[0]=0;
	for (int i=0;i<now;i++)
		for (int j=1;j<=n;j++)
			if (!(i&(1<<(j-1))))
			{
				int nowf,nowrem;
				if (rem[i]>=a[j])
				{
					nowf=f[i];
					nowrem=rem[i]-a[j];
				}
				else
				{
					nowf=f[i]+1;
					nowrem=c-a[j];
				}
				if (nowf<f[i|(1<<(j-1))])
				{
					f[i|(1<<(j-1))]=nowf;
					rem[i|(1<<(j-1))]=nowrem;
				}
				else 
				if (nowf==f[i|(1<<(j-1))])
					rem[i|(1<<(j-1))]=max(rem[i|(1<<(j-1))],nowrem);
			}
	if (rem[now]!=c) f[now]++;
	printf("%d\n",f[now]);
	return 0;
}
/*
4 10
5
6
3
7
*/
