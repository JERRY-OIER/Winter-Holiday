#include<cstdio>
#include<algorithm>
#define N 100010
using namespace std;
int n,head[5010],c,cnt=1,tot,x[N],y[N],a[N],ans,qwq;
bool vis[5010];
struct hhh
{
	int to,next;
}edge[5000*5000];

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

int ABS(int x) { return x>0?x:-x; }

void add(int u,int v)
{
	printf("add: %d %d\n",u,v);
	edge[cnt].to=v;edge[cnt].next=head[u];head[u]=cnt++;
	edge[cnt].to=u;edge[cnt].next=head[v];head[v]=cnt++;
}

void dfs(int x)
{
	vis[x]=1;
	++tot;
	for (int i=head[x];i;i=edge[i].next)
		if (!vis[edge[i].to]) dfs(edge[i].to);
}

int main()
{
	freopen("connect.in","r",stdin);
	n=read();c=read();
	for (int i=1;i<=n;i++) x[i]=read(),y[i]=read();
	for (int i=1;i<=n;i++)
		for (int j=i+1;j<=n;j++)
			if (ABS(x[i]-x[j])+ABS(y[i]-y[j])<=c) 
				add(i,j);
	for (int i=1;i<=n;i++)
		if (!vis[i]) 
		{
			printf("%d\n",i);
			qwq++;
			tot=0;
			dfs(i);
			ans=max(ans,tot);
		}
	printf("%d %d\n",qwq,ans);
	return 0;
}
/*
4 2
1 1
3 3
2 2
10 10
*/
