#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;

int main()
{
	freopen("connect.in","w",stdout);
	srand((int)time(0));
	int n=20;
	int c=rand()%10+1;
	printf("%d %d\n",n,c);
	for (int i=1;i<=n;i++)
	{
		int x=rand()%100+1;
		int y=rand()%100+1;
		printf("%d %d\n",x,y);
	}
	return 0;
}
