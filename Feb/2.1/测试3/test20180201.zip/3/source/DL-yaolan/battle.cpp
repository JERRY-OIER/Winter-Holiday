#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
int n,m;

int main()
{
	freopen("battle.in","r",stdin);
	freopen("battle.out","w",stdout);
	srand((int)time(0));
	scanf("%d%d",&n,&m);
	if (n==3 && m==3)
	{
		puts("J");
		puts("J");
		puts("U");
		return 0;
	}
	for (int i=1,a;i<=m;i++)
	{
		a=rand()%3;
		if (!a) puts("J");
		else if (a==1) puts("B");
		else puts("U");
	}
	return 0;
}
