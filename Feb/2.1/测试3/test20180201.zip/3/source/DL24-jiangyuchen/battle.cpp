#include <cstdio>
#include <cstring>
#include <map>
#include <algorithm>
using namespace std;

int n, m, cnt, x1, x2, x3, y1, y2, y3, ecnt, jj;
int head[1010], nxt[100010], edge[100010], st[1010], ed[1010], vis[1010];
char s[5];

struct point{
	int a, b, c; 
	friend bool operator < (point x, point y)
	{
		if(x.a == y.a && x.b == y.b)
		    return x.c < y.c;
		if(x.a == y.a)
		    return x.b < y.b;
		return x.a < y.a;
	}
}p[1010];

map <point, int> mmp;

void dfs(int u)
{
	if(ed[u])
	{
		jj = 1;
		return;
	}
	for(int i = head[u]; i; i = nxt[i])
	{
		int v = edge[i];
		if(!vis[v])
		{
			vis[v] = 1;
			dfs(v);
		}
	}
	return;
}

void add(int u, int v)
{
	nxt[++ecnt] = head[u];
	head[u] = ecnt;
	edge[ecnt] = v;
	return;
}

void cut_jj()
{
	if(x1 > y1)
	{
		x1 -= y1;
		y1 = 0;
	}
	else
	{
		y1 -= x1;
		x1 = 0;
	}
	if(x2 > y2)
	{
		x2 -= y2;
		y2 = 0;
	}
	else
	{
		y2 -= x2;
		x2 = 0;
	}
	if(x3 > y3)
	{
		x3 -= y3;
		y3 = 0;
	}
	else
	{
		y3 -= x3;
		x3 = 0;
	}
	return;
}

void add_jj()
{
	int flag = 0;
	point ha, hb;
	ha.a = x1, ha.b = x2, ha.c = x3;
	hb.a = y1, hb.b = y2, hb.c = y3;
	if(!mmp[ha])
	{
		flag++;
		mmp[ha] = ++cnt;
		p[cnt].a = ha.a, p[cnt].b = ha.b, p[cnt].c = ha.c;
	}
	if(!mmp[hb])
	{
		flag++;
		mmp[hb] = ++cnt;
		p[cnt].a = hb.a, p[cnt].b = hb.b, p[cnt].c = hb.c;
	}
	if(flag)
	{
		if(s[1] == 'J')
		    add(mmp[ha], mmp[hb]);
		else
		    add(mmp[hb], mmp[ha]);
	}
	return;
}

void buy_jj()
{
	jj = 0;
	memset(st, 0, sizeof(st));
	memset(ed, 0, sizeof(ed));
	memset(vis, 0, sizeof(vis));
	for(int i = 1; i <= cnt; i++)
	{
		if(p[i].a <= x1 && p[i].b <= x2 && p[i].c <= x3)
			st[i] = 1;
		if(p[i].a >= y1 && p[i].b >= y2 && p[i].c >= y3)
		    ed[i] = 1;
	}
	for(int i = 1; i <= cnt; i++)
	{
		if(st[i])
		    dfs(i);
		if(jj)
		{
			printf("J\n");
			return;
		}
	}
	memset(st, 0, sizeof(st));
	memset(ed, 0, sizeof(ed));
	memset(vis, 0, sizeof(vis));
	for(int i = 1; i <= cnt; i++)
	{
		if(p[i].a <= y1 && p[i].b <= y2 && p[i].c <= y3)
			st[i] = 1;
		if(p[i].a >= x1 && p[i].b >= x2 && p[i].c >= x3)
		    ed[i] = 1;
	}
	for(int i = 1; i <= cnt; i++)
	{
		if(st[i])
		    dfs(i);
		if(jj)
		{
			printf("B\n");
			return;
		}
	}
	printf("U\n");
    return;
}

int main()
{
	freopen("battle.in", "r", stdin);
	freopen("battle.out", "w", stdout);
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; i++)
	{
		scanf("%s", s + 1);
		scanf("%d %d %d %d %d %d", &x1, &x2, &x3, &y1, &y2, &y3);
	    cut_jj();
	    if((x1 == 0 && x2 == 0 && x3 == 0) || (y1 == 0 && y2 == 0 && y3 == 0))
	    	continue;
	    add_jj();
	}
	for(int i = 1; i <= m; i++)
	{
		scanf("%d %d %d %d %d %d", &x1, &x2, &x3, &y1, &y2, &y3);
		cut_jj();
		if(x1 == 0 && x2 == 0 && x3 == 0)
		{
			printf("B\n");
			continue;
		}
		if(y1 == 0 && y2 == 0 && y3 == 0)
		{
			printf("J\n");
		    continue;
		}
		buy_jj();
	}
	return 0;
}

/*
3 3
J 6 5 4 5 4 7
B 5 4 2 3 5 5
J 9 0 10 8 2 7
6 6 4 5 4 7
9 0 10 8 2 6
3 4 8 4 4 6
*/
