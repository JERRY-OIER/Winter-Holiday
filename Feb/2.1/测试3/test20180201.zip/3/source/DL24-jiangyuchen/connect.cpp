#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

int n, c, ans, anscnt;
int fa[5010], saize[5010]; 

struct point{
	int x, y;
}p[5010];

inline int find(int x)
{
	if(fa[x] != x)
	    fa[x] = find(fa[x]);
	return fa[x];
}

void solve1()
{
	for(int i = 1; i <= n; i++)
	    scanf("%d %d", &p[i].x, &p[i].y);
	for(int i = 1; i <= n; i++)
	    fa[i] = i;
	anscnt = n;
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			if(abs(p[i].x - p[j].x) + abs(p[i].y - p[j].y) <= c)
			{
				int fi = find(i), fj = find(j);
				if(fi != fj)
				{
					fa[fi] = fj;
					anscnt--;
				}
			}
		}
	}
	for(int i = 1; i <= n; i++)
	    saize[find(i)]++;
	for(int i = 1; i <= n; i++)
	    ans = max(ans, saize[i]);
	printf("%d %d\n", anscnt, ans);
    return;
}

int main()
{
	freopen("connect.in", "r", stdin);
	freopen("connect.out", "w", stdout);
	scanf("%d %d", &n, &c);
	if(n <= 5000)
	    solve1();
	return 0;
}

