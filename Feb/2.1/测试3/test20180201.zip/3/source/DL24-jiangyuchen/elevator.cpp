#include <cstdio>
#include <algorithm>
using namespace std;

int n, w, cnt;
int a[50], vis[50];

bool cmp(int x, int y)
{
	return x > y;
}

int main()
{
	freopen("elevator.in", "r", stdin);
	freopen("elevator.out", "w", stdout);
	int ans = 0;
	scanf("%d %d", &n, &w);
	for(int i = 1; i <= n; i++)
	    scanf("%d", &a[i]);
	sort(a + 1, a + 1 + n, cmp);
	for(ans = 1; ; ans++)
	{
		int nw = 0;
        for(int i = 1; i <= n; i++)
        {
        	if(vis[i])
        	    continue;
        	if(nw + a[i] <= w)
        	{
        		nw += a[i];
        		cnt++;
        		vis[i] = 1;
        	}
        }
        if(cnt == n)
            break;
	}
	printf("%d\n", ans);
	return 0;
}
