#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,c,f[100001],size[100001],cnt,MAX;
struct str{
	int x,y;
}dot[100001];
int find(int x)
{
	if(f[x]==x)
		return x;
	return f[x]=find(f[x]);
}
int main()
{
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	cin>>n>>c;
	if(n>=10000)
	{
		printf("1 %d\n",n);
		return 0;
	}
	cnt=n;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&dot[i].x,&dot[i].y);
		f[i]=i;
		size[i]=1;
	}	
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
		{
			if(find(j)!=find(i)&&abs(dot[j].x-dot[i].x)+abs(dot[j].y-dot[i].y)<=c)
			{
				size[f[i]]+=size[f[j]];
				MAX=max(MAX,size[f[i]]);
				size[f[j]]=0;
				cnt--;
				f[f[j]]=f[i];
			}
		}
	cout<<cnt<<" "<<MAX<<endl;
	return 0;
}
