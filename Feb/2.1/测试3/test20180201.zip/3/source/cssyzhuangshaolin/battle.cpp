#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
int n,m,a;
int main()
{
	srand(time(0));
	freopen("battle.in","r",stdin);
	freopen("battle.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		a=rand()%3;
		if(!a)
			printf("U\n");
		else
			if(a==1)
				printf("J\n");
			else
				printf("B\n");
	}
	return 0;
}
