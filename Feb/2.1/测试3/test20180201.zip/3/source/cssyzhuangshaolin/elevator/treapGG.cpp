#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,c,ans=1,MAX,x[100001],y[100001],jsq,g[100001],size[100001],root=1;
struct {
	int nx,ny,f,ls,rs;
	bool used;
}nod[100001];
void lr(int s)
{
	int r=nod[s].rs;
	nod[s].rs=nod[r].ls;
	nod[nod[r].ls].f=s;
	if(nod[nod[s].f].ls==s)
	{
		nod[nod[s].f].ls=r;
		nod[r].f=nod[s].f;
	}
	else
	{
		nod[nod[s].f].rs=r;
		nod[r].f=nod[s].f;
	}
	nod[s].f=r;
	nod[r].ls=s;
}
void rr(int s)
{
	int r=nod[s].ls;
	nod[s].ls=nod[r].rs;
	nod[nod[r].rs].f=s;
	if(nod[nod[s].f].ls==s)
	{
		nod[nod[s].f].ls=r;
		nod[r].f=nod[s].f;
	}
	else
	{
		nod[nod[s].f].rs=r;
		nod[r].f=nod[s].f;
	}
	nod[s].f=r;
	nod[r].rs=s;
}
void wh(int s)
{
	if((abs(nod[nod[s].ls].ny)<abs(nod[nod[s].rs].ny)||!nod[s].rs)&&abs(nod[nod[s].ls].ny)<abs(nod[s].ny))
	{
		rr(f[s]);
		wh(nod[s].f);
	}
	else
		if((abs(nod[nod[s].rs].ny<abs(nod[nod[s].ls].ny))||!nod[s].ls)&&abs(nod[nod[s].rs].ny)<abs(nod[s].ny))
		{
			lr(f[s]);
			wh(nod[s].f);
		}
	return;
}
void insert(int o,int x,int y)
{
	if(abs(x)>=abs(nod[o].nx))
	{
		if(nod[o].rs)
			build(nod[o].rs,x,y);
		else
		{
			nod[o].rs=++jsq;
			nod[jsq].nx=x;
			nod[jsq].ny=y;
			nod[jsq].f=o;
			wh(o);
		}
	}
	else
		if(nod[o].ls)
			build(nod[o].ls,x,y);
		else
		{
			nod[o].ls=++jsq;
			nod[jsq].nx=x;
			nod[jsq].ny=y;
			nod[jsq].f=o;
			wh(o);
		}
	return;		
}
void search(int o)
{
	if(abs(nod[o].nx)+abs(nod[o].ny)<c)
	{
		g[o]=root;
		size[root]++;
		MAX=max(MAX,size[root]);
		used[o]=true;
	}
	else
		return;
	search(nod[o].ls);
	search(nod[o].rs);
}
int main()
{
	freopen("connect.in","r",stdin);
	freopen("connect.out","w",stdout);
	cin>>n>>c;
	for(int i=1;i<=n;i++)
		scanf("%d",&x[i],&y[i]);
	for(int i=1;i<=n;i++)
		insert(0,x[i]-x[1],y[i]-y[1]);
	for(int i=1;i<=n;i++)
	{
		root=i;
		search(root);
	}
	cout<<ans<<" "<<MAX<<endl;
	return 0;
}
