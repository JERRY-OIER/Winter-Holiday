#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,c[20],jsq,ans;
bool cmp(int a,int b)
{return a>b;}
int search(int l,int r,int s)
{
	int mid=(l+r)>>1;
	if(!r)
		return -1;
	if(l==r)
		if(c[l]<=s)
			return l;
		else
			return -1;
	if(c[mid]>s)
		return search(mid+1,r,s);
	else
		return search(l,mid,s);
}
void solve(int sum)
{
	int	ad=search(1,n,m-sum);
	if(sum==m||ad==-1)
	{
		ans++;
		return;
	}
	sum+=c[ad];
	c[ad]=0;
	for(int i=ad;i<=n;i++)
		c[i]=c[i+1];
	n--;
	solve(sum);
	return;
}
int main()
{
	freopen("elevator.in","r",stdin);
	freopen("elevator.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]);
	sort(c+1,c+n+1,cmp);
	while(n)
		solve(0);
	cout<<ans<<endl;
	return 0;
}
