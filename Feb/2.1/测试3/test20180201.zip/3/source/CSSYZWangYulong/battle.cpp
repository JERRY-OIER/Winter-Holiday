#include <iostream>
#include <cstdio>
using namespace std;
int main() {
	//freopen("battle.in", "r", stdin);
	//freopen("battle.out", "w", stdout);

	return 0;
}
