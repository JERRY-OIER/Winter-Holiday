#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n;
int used[100005];
long long c;
int cxy[100005];

bool cmp(pos a, pos b) {
	return a.y - a.x < b.y - b.x; 
}
bool cmp2(pos a, pos b) {
	return a.Sxy < b.Sxy; 
}

int mxl[100005], mxr[100005];

int ls[5000006], rs[5000006], root[100005], cnt = 1, sz;
long long ptree[5000006];

void bd(int l, int r, int i) {
	//cout <<"$$" <<  l << " " << r << " " << i <<endl;
	if (l == r) {
		return ;
	}
	int mid = (r + l) >> 1;
	ls[i] = ++cnt;
	bd(l, mid, ls[i]);
	rs[i] = ++cnt;
	bd(mid + 1, r, rs[i]);
	return ;
}





int main() {
	freopen("connect.in", "r", stdin);
	//freopen("connect.out", "w", stdout);
	scanf("%d%lld", &n, &c);
	for (int i = 1; i <= n; ++i) {
		scanf("%lld%lld", &p[i].x , &p[i].y);
		p[i].Sxy = p[i].x + p[i].y;
	}
	
	sort(p + 1, p + 1 + n, cmp2);
	
	
	int head = 1;
	p[1].val = 1;
	for (int i = 1; i <= n; ++i) {
		p[i].val = i;
		while (i > head && p[i].Sxy - p[head].Sxy > c) {
			mxr[p[head].val] = i - 1;
			head++;
		}
		mxl[p[i].val] = head;
		//cout << head << endl;
	}
	
	while (head <= n) {
		mxr[head++] = n;
	}
	
	/*for (int i = 1; i <= n; ++i) {
		printf("%d %lld %lld %lld\n", p[i].val, p[i].Sxy, p[i].x, p[i].y);
		printf("%d %d\n", mxl[p[i].val], mxr[p[i].val]);
		
	}*/
	
	root[0] = 1;
	bd(1, n, 1);
	
	/*for (int i = 1; i <= cnt; ++i) {
		printf("%d %d\n", ls[i], rs[i]);
		
	}*/
	
	sort(p + 1, p + 1 + n, cmp);
	
	for (int i = 1; i <= n; ++i) {
		cxy[i] = p[i].y - p[i].x;
	}
	
	for (int i = 1; i <= n; ++i) {
		int l = lower_bound(cxy + 1, cxy + 1 + i, p[i].x - p[i].y - c) - cxy;
		int r = upper_bound(cxy + 1, cxy + 1 + i, p[i].x - p[i].y + c) - cxy - 1;
		q(root[l - 1], root[r], 1, n, mxl[p[i].val], mxr[p[i].val]);
		ist(p[i].val);
	}
	
	
	return 0;
}
