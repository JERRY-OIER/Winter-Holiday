#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
long long c[50];
int used[50];
int main() {
	freopen("elevator.in", "r", stdin);
	freopen("elevator.out", "w", stdout);
	int n, w;
	scanf("%d%d", &n, &w);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &c[i]);
	}
	sort(c + 1, c + 1 + n);
	int ans = 0;
	int res = w;
	for (int i = n; i >= 1; i--) {
		if (used[i]) continue;
		//printf("%d\n", c[i]);
		ans++;
		used[i] = 1;
		res = w - c[i];
		int j = i;
		while (j >= 1) {
			while (j >= 1 && (used[j] || res < c[j])) {
				j--;
			}
			//printf("%d ", c[j]);
			res -= c[j];
			used[j] = 1;
		}
		//printf("\n");
	}
	printf("%d", ans - 1);
	return 0;
}

/*
4 10
5
6
3
7
*/
