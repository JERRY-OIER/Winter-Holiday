#include <cstdio>
#include <cstring>
#include <cctype>
#include <iostream>
#include <algorithm>
#include <cstdlib>
using namespace std;

char buf[1010];
int main() {
	system("g++ perica.cpp -ostd -g -Wall");
	for (int i = 1; i <= 10; ++i) {
		printf("Running Case %d...\n", i);
		sprintf(buf, "./std < perica.in.%d > perica.ans.%d", i, i);
		system(buf);
		sprintf(buf, "diff perica.ans.%d perica.out.%d", i, i);
		if (system(buf) == 0)
			puts("AC");
		else
			puts("WA");
	}
	return 0;
}
