#include <cstdio>
#include <cstring>
#include <cctype>
#include <iostream>
#include <algorithm>
#include <cstdlib>
using namespace std;

char buf[1010];
int main() {
	system("g++ uzastopni.cpp -ostd -g -Wall");
	for (int i = 1; i <= 20; ++i) {
		printf("Running Case %d...\n", i);
		sprintf(buf, "./std < uzastopni.in.%d > uzastopni.ans.%d", i, i);
		system(buf);
		sprintf(buf, "diff uzastopni.ans.%d uzastopni.out.%d", i, i);
		if (system(buf) == 0)
			puts("AC");
		else
			puts("WA");
	}
	return 0;
}
