#include <cstdio>
#include <cstring>
#include <cctype>
#include <iostream>
#include <algorithm>
#include <cstdlib>
using namespace std;

char buf[1010];
int main() {
	system("g++ poplava.cpp -ostd -g -Wall");
	for (int i = 1; i <= 10; ++i) {
		printf("Running Case %d...\n", i);
		sprintf(buf, "./std < poplava.in.%d > poplava.ans.%d", i, i);
		system(buf);
	}
	return 0;
}
