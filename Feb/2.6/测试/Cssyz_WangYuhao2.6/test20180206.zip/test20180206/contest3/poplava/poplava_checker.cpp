#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;

typedef long long ll;

FILE *fin, *fout, *fans, *fscore, *freport;

void setscore(int score) {
	fprintf(fscore, "%d", score);
}

void close_output_files() {
	fclose(fscore);
	fclose(freport);
}

#define N 1000010
int n, m;
ll x;
int p[N];
ll sp[N];
pair<int, int> a[2100000];
int cnt[N];
pair<int, int> find(int tl, int tr) {
	pair<int, int> ans = make_pair(0, 0);
	for (tl += m - 1, tr += m + 1; tl ^ tr ^ 1; tl >>= 1, tr >>= 1) {
		if (~tl & 1)
			ans = max(ans, a[tl ^ 1]);
		if (tr & 1)
			ans = max(ans, a[tr ^ 1]);
	}
	return ans;
}

ll ans = 0;
void solve_l(int r) {
	if (r == 1)
		return;
	int nxt = find(1, r - 1).second;
	ans += (ll)p[nxt] * (r - nxt - 1) - (sp[r - 1] - sp[nxt]);
	solve_l(nxt);
}
void solve_r(int l) {
	if (l == n)
		return;
	int nxt = find(l + 1, n).second;
	ans += (ll)p[nxt] * (nxt - l - 1) - (sp[nxt - 1] - sp[l]);
	solve_r(nxt);
}

int main(int argc, char *argv[]) {
	fscore = fopen(argv[5], "w");
	freport = fopen(argv[6], "w");
	fans = fopen(argv[3], "r");
	fin = fopen(argv[1], "r");
	fout = fopen(argv[2], "r");
	
	//fscore = fopen("score", "w");
	//freport = fopen("report", "w");
	//fans = fopen("poplava.out.5", "r");
	//fin = fopen("poplava.in.5", "r");
	//fout = fopen("poplava.ans.5", "r");

	fscanf(fin, "%d%lld", &n, &x);
	fclose(fin);

	int check;
	fscanf(fans, "%d", &check);
	fclose(fans);

	fscanf(fout, "%d", &p[1]);
	if (p[1] == -1 && check == -1) {
		setscore(10);
		fclose(fout);
		close_output_files();
		return 0;
	}
	else if (p[1] == -1 && check != -1) {
		setscore(0);
		fclose(fout);
		close_output_files();
		return 0;
	}
	else if (p[1] != -1 && check == -1) {
		setscore(0);
		fclose(fout);
		close_output_files();
		return 0;
	}
	else {
		for (int i = 2; i <= n; ++i)
			fscanf(fout, "%d", &p[i]);
		int extra;
		if (fscanf(fout, "%d", &extra) == 1) {
			setscore(0);
			fclose(fout);
			close_output_files();
		}
		fclose(fout);
		for (int i = 1; i <= n; ++i)
			if (p[i] < 1 || p[i] > n) {
				setscore(0);
				close_output_files();
			}
		for (int i = 1; i <= n; ++i)
			++cnt[p[i]];
		for (int i = 1; i <= n; ++i)
			if (cnt[i] != 1) {
				setscore(0);
				close_output_files();
			}
		
		for (int i = 1; i <= n; ++i)
			sp[i] = sp[i - 1] + p[i];
		for (m = 1; m < n + 2; m <<= 1);
		for (int i = 1; i <= n; ++i)
			a[m + i] = make_pair(p[i], i);
		for (int i = m - 1; i >= 1; --i)
			a[i] = max(a[i << 1], a[i << 1 | 1]);
		
		int mx_pos = find(1, n).second;
		solve_l(mx_pos);
		solve_r(mx_pos);

		setscore((x == ans) ? 10 : 0);
		close_output_files();
	}

	return 0;
}
