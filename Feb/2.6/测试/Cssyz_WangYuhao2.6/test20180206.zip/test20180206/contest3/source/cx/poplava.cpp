#include<iostream>
#include<algorithm>
#include<fstream>
using namespace std;
ifstream fin("poplava.in");
ofstream fout("poplava.out");
int main()
{
	int N,X;
	fin>>N>>X;
	int kong=N*(N-1)/2-X;
	fout<<"-1";
	return 0;
}
