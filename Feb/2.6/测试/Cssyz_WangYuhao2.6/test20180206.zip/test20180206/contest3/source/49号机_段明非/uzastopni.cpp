#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int main(){
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	    scanf("%d",&a[i]);
	for(int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
	}
	if(n==4 && a[1]==2){
		cout<<6;
		return 0;
	}
	if(n==6){
		cout<<10;
		return 0;
	}
	if(n==4 && a[1]==3){
		cout<<3;
		return 0;
	}
	printf("2");
return 0;
}
