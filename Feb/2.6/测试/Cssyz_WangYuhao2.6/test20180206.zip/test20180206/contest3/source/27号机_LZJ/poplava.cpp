#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<iostream>
#include<iomanip>
#include<algorithm>
#include<ctime>
#include<cmath>
using namespace std;
int a[1000010];
bool b[1000010];
int main()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	int top=0;
	long long k,n;
	scanf("%I64d%I64d",&n,&k);
	int mid=n-2;
	int maxx=(n-2)*(n-1)/2;
	if(k>maxx) 
	{
		cout<<-1;
		return 0;
	}
	b[n]=true;
	b[n-1]=true;
	while(k>0)
	{
		while(mid>k) mid--;
		k-=mid;
		a[++top]=n-1-mid;
		b[n-1-mid]=true;
		mid--;
	}
	printf("%d ",n);
	for(int i=1;i<=top;i++) printf("%d ",a[i]);
	printf("%d ",n-1);
	for(int i=n;i>=1;i--) if(!b[i]) printf("%d ",i);
	return 0;
}
