#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,x,y;
int main()
{
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)  scanf("%d",&x);
	for(int i=1;i<=n-1;i++)  scanf("%d%d",&x,&y);
	printf("%d\n",n*2-2);
	return 0;
}
