#include <bits/stdc++.h>

using namespace std;

const int N = 1000000;

int n, k;
int res[N + 1];
int top, bot;

int main() {
	freopen("poplava.in", "r", stdin);
	freopen("poplava.out", "w", stdout);
	scanf("%d%d", &n, &k);
	if(k > (n - 2) * (n - 1) / 2) {
		printf("-1\n");
		return 0;
	}
	int top = 1;
	int bot = n + 1;
	res[1] = n;
	for(int i = n - 2; i >= 1; i--)
		if(k - i >= 0)	k -= i, res[++top] = n - i - 1;
		else				    res[--bot] = n - i - 1;
	res[++top] = n - 1;
	for(int i = 1; i <= n; i++) printf("%d ", res[i]);
	putchar('\n');
	return 0;
}
