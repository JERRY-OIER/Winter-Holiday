#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
#include<set>
using namespace std;
int n,a[10020],top,nex[20020],to[20020],fir[20020],x,y,ans;
bool dp[10020][102][102];
int lj(int u,int v){
	top++;
	to[top]=v;
	nex[top]=fir[u];
	fir[u]=top;
}
int ss(int u,int v){
	int top1=fir[v],i,j,k,flag=0;
	while(top1!=0){
		if(to[top1]!=u){
			ss(v,to[top1]);
			for(i=1;i<=a[v]-1;i++)
				for(j=i;j<=a[v]-1;j++)
					if(dp[v][i][j]==0&&i<=a[to[top1]]&&a[to[top1]]<=j)
						dp[v][i][j]=dp[to[top1]][i][j];
			for(i=a[v]+1;i<=100;i++)
				for(j=i;j<=100;j++)
					if(dp[v][i][j]==0&&i<=a[to[top1]]&&a[to[top1]]<=j)
						dp[v][i][j]=dp[to[top1]][i][j];
			flag=1;
		}
		top1=nex[top1];
	}
	dp[v][a[v]][a[v]]=1;
	if(flag==1)
		for(j=1;j<=100;j++)
			for(i=1;i+j<=100;i++)
				if(dp[v][i][i+j]==0)
					for(k=i;k<=i+j;k++)
						if(dp[v][i][k]==1&&dp[v][k+1][i+j]==1){
							dp[v][i][i+j]=1;
							break;
						}
	return 0;
}
int main(){
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	int i,j;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		lj(x,y);
		lj(y,x);
	}
	ss(1,1);
	for(i=1;i<=100;i++)
		for(j=i;j<=100;j++)
			if(i<=a[1]&&a[1]<=j)
				ans+=dp[1][i][j];
	cout<<ans<<endl;
	return 0;
}
