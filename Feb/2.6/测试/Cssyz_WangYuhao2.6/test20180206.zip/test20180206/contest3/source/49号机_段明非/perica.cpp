#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#define MOD 1000000007
using namespace std;
int n,k;
long long ans=0ll;
int a[100500];
int c[100500][50];
int find(int n,int m){
	if(c[n][m])
	   return c[n][m];
	if(n==m)
	   return 1;//23
	if((n==0 && m==0) || (n==1 && m==0) || (n==1 && m==1))
	   return 1;//32
	if(!m)
	   return 1;
	return c[n][m]=(find(n-1,m-1)+find(n-1,m))%MOD;
}
int main(){
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	memset(c,0,sizeof(c));
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	    scanf("%d",&a[i]);
	sort(a+1,a+n+1);
    ans=a[k];
	for(int i=k+1;i<=n;i++){
		ans=ans+(a[i]%MOD*(find(i,k)-find(i-1,k))%MOD)%MOD;
		ans=ans%MOD;
	}
	printf("%d",ans%MOD);
	fclose(stdin);fclose(stdout);
	//system("pause");
return 0;
}
