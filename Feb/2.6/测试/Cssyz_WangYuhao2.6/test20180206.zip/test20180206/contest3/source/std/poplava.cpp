#include <cstdio>
#include <climits>
#include <cstring>
#include <cctype>
using namespace std;

typedef long long ll;

#define N 1000010
int ans[N], cnt;
bool select[N];
int main() {
	freopen("poplava.in", "r", stdin);
	freopen("poplava.out", "w", stdout);
	
	int n;
	ll x;
	scanf("%d%lld", &n, &x);
	if (x > (ll)(n - 1) * (n - 2) / 2)
		puts("-1");
	else {
		for (int i = n - 2; i >= 1; --i) {
			if (x >= i)
				ans[++cnt] = n - 1 - i, x-= i;
		}
		select[n] = select[n - 1] = 1;
		printf("%d", n);
		for (int i = 1; i <= cnt; ++i)
			printf(" %d", ans[i]), select[ans[i]] = 1;
		printf(" %d", n - 1);
		for (int i = n; i >= 1; --i)
			if (!select[i])
				printf(" %d", i);
	}

	fclose(stdin);
	fclose(stdout);
	
	return 0;
}

