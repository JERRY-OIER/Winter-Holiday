#include<cstdio>
#include<queue>
#define M 10010
struct link
{
	int next;
	int to;
	link(int next=0,int to=0):next(next),to(to) {};
}G[M<<1];
int bian[M],w[M],p;
/*inline */void add(int x,int y)
{
	G[++p].next=bian[x];
	G[p].to=y;
	bian[x]=p;
}
bool operator < (link x,link y)
{
	return x.next<y.next;
}
int dfs(int x,int from)
{
//	printf("x%d\n",x);
	if(!G[bian[x]].next) return 1;
	std::priority_queue<link> big,small;
	for(int i=bian[x];i;i=G[i].next)
	{
		int go=G[i].to;
		if(go==from) continue;
		if(w[go]>w[x]) big.push(link(w[go],go));
		else small.push(link(-w[go],go));
	}
	while(!big.empty() && big.top().next-w[x]!=big.size()) big.pop();
	while(!small.empty() && small.top().next+w[x]!=small.size()) small.pop();
	int ans=big.size()+small.size()-1,bg=1,sl=1;
	if(!big.empty()) ans+=(bg=dfs(big.top().to,x))*small.size();
	else ans++;
	if(!small.empty()) ans+=(sl=dfs(small.top().to,x))*big.size();
	else ans++;
	ans+=bg*sl;
//	printf("x%dans%d\n",x,ans);
	return ans;
}
int main()
{
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	int n;
	scanf("%d\n",&n);
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
	for(int i=1,a,b;i<n;i++)
	{
		scanf("%d %d",&a,&b);
		add(a,b);
		add(b,a);
	}
	printf("%d\n",dfs(1,0));
	return 0;
}
