#include<cstdio>  
#include<cstdlib>  
#include<cmath>  
#include<ctime>  
#include<algorithm>  
#include<cstring>  
#include<string>  
#include<iostream>  
#include<iomanip>  
#include<vector>  
#include<map>  
#include<set>  
#include<functional>  
#include<sstream>  
#include<iterator>   
#include<queue>  
using namespace std;  
int n,u,v,k;
int a[12345];
bool b[12345];
int stc[12345];
int main()  
{
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) 
	{
	scanf("%d",&a[i]);
	if(!b[a[i]]) 
	{
		stc[++k]=a[i];b[a[i]]=true;
	}
	
    }
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&u,&v);
	}
	if(k==1) printf("1");
	else if(k==2) 
	{
		if(abs(stc[1]-stc[2])==1) printf("3");
		else                      printf("2");
	}
	else cout<<rand();
	fclose(stdin);
	fclose(stdout);
    return 0;  
} 


