#include <bits/stdc++.h>

using namespace std;

long long n, x, a[100005],cnt = 0;
bool used[100005];

void cut(long long t)
{
	while(t >= a[cnt])
	{
		cnt++;
		t -= cnt;
		a[cnt] = cnt;
	}
	for (int i = cnt; i >= 1; i--)
		if (a[i] + t < n - 1) { a[i] += t; break; }
	return;
}

int main()
{
	freopen("poplava.in", "r", stdin);
	freopen("poplava.out", "w", stdout);
	//ios::sync_with_stdio(false);
	cin >> n >> x;
	if (x > (n - 1) * (n - 2) / 2 || n < 3) { printf("-1\n"); return 0; }
	cut(x);
	cout << n - 1 << " ";
	for (int i = 1; i <= cnt; i++) { cout << n - 1 - a[i] << " "; used[n - 1 - a[i]] = true; }
	cout << n << " ";
	for (int i = n - 2; i >= 1; i--)
		if (used[i] == false) cout << i << " ";
	cout << endl;
	return 0;
}
