#include <bits/stdc++.h>
#define MAX_N 1000010
typedef unsigned long long ll;
using namespace std;

ll N, x;
ll q[MAX_N];
int front = 1, rear;
ll sum;
ll res[MAX_N], rsl;
bool book[MAX_N];

inline ll calc (ll x) {return N - 1 - x;}

void solve () {
  sum = 0;
  while (sum < x && front < rear) {
    //printf("sum:%lld l:%d r:%d\n", sum, front, rear);
    //if (x - sum < 2 * calc(q[front]) - 1 && x - sum != q[front]) {++front; continue;}
    if (sum + calc(q[front]) > x) {++front; continue;}
    sum += (N - 1 - q[front]);
    book[front] = true;
    res[++rsl] = q[front];
    ++front;
  }
  if (sum != x) {printf("-1\n"); exit(0);}
  printf("%lld ", N - 1);
  for (int i = 1;i <= rsl; ++i) printf("%lld ", res[i]);
  printf("%lld ", N);
  for (int i = N - 2;i > 0; --i) {
    if (!book[i]) printf("%lld ", q[i]);
  }
  printf("\n");
}

int main () {
  freopen ("poplava.in", "r", stdin);
  freopen ("poplava.out", "w", stdout);
  scanf("%lld%lld", &N, &x);
  for (int i = 1;i <= N; ++i) {
    q[++rear] = i;
  }
  for (int i = 1;i < N - 1; ++i) {
    sum += i;
  }
  if (x > sum) {printf("-1\n");return 0;}
  solve();
  return 0;
}
