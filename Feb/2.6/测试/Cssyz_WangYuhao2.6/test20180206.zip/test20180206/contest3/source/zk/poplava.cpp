#include <iostream>
#include <cstdio>
using namespace std;
long long n, x;
int ot[1000001]; bool it[1000001];
int main(){
	freopen("poplava.in", "r", stdin);
	freopen("poplava.out", "w", stdout);
	cin>>n>>x;
	if(x>(n-1)*(n-2)/2) puts("-1");
	else{
		int sma=n-2, cnt=0; x=(n-1)*(n-2)/2-x;
		while(x){
			if(x>=sma){
				x-=sma;
				it[n-1-sma]=1; ot[cnt++]=n-1-sma;
				sma--;
			}
			else{
				ot[cnt++]=n-1-x;
				it[n-1-x]=1;
				x=0;
			}
		}
		for(int i=0;i<cnt;i++)
			printf("%d ", ot[i]);
		printf("%d ", n-1);
		for(int i=1;i<n-1;i++)
			if(!it[i])
				printf("%d ", i);
		printf("%d\n", n);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}