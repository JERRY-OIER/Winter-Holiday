#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	int n;
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	cin>>n;
	if(n>100) cout<<rand()%10000+100;
	else cout<<"5";
	return 0;
}
