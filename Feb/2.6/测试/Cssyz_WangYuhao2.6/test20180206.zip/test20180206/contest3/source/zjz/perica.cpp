#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
const int BASE=1000000007;
int num[1000005],ans=0;
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
    int n,K,U;
	cin>>n>>K;
	for(int i=0;i<n;i++)
	    cin>>num[i];
	if(K==1)
	  {
	  	for(int i=0;i<n;i++)
	  	   {
	  	   	ans+=num[i]%BASE;
	  	   	ans%=BASE;
	  	   }
	  }
	else ans=rand()%BASE;
	cout<<ans;
	return 0;
}
