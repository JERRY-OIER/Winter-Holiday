#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<string>
using namespace std;
int n,k,o,a[100001],b[100001];
int kk[51];
int c[100001][51];
int ans;

/*void dfs(int x){
	
	
	
}*/
int main(){
	//freopen("perica.in","r",stdin);
	//freopen("perica.out","w",stdout);
 scanf("%d%d",&n,&k);
 //for(int i=1;i<=n;i++)scanf("%d",&a[i]);
  	
c[0][0]=c[1][0]=c[1][1]=1;		
for(int i=1;i<=n;i++)
 for(int j=1;j<=k;j++)	
 c[i][j]=c[i-1][j-1]+c[i-1][j];
 o=c[n][k];
 //dfs(o);

	
printf("%d",o);	
	return 0;
}
