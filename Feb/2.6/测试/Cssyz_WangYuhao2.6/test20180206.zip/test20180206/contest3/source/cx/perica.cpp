#include<iostream>
#include<algorithm>
#include<fstream>
using namespace std;
ifstream fin("perica.in");
ofstream fout("perica.out");

long long jc(int x)
{
	long long sum=1;
	for(int a=x;a>=1;a--)
	{
		sum=sum*a%1000000007;
	}
	return sum;
}
int z[100009];
int main()
{
	long long ans=0; 
	 int n,k;
	 fin>>n>>k;
	 for(int i=1;i<=n;i++)
	 {
	 	fin>>z[i];
	 }
	 sort(z+1,z+1+n);
	 long long M=jc(k-2),N=jc(k-1),MN=1;
	 for(int i=k;i<=n;i++)
	 {
	 	if(i-k!=0)
	 	{
	 		MN=MN*(i-k)%1000000007;
	 	}
	 	M=M*(i-1)%1000000007;
	 	ans=(ans+(z[i]*M/N/MN)%1000000007)%1000000007;
	 	
	 }
	 fout<<ans;
	 return 0;
}
