#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<iomanip>
#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int n,k;
long long ans=0;
long long a[1001000];
long long c[1000100];//��׺��
long long d[1000100];
void dfs(int x,int p)
{    
    if(p==k-1)  {ans+=d[x+1];return;}
	for(int i=x+1;i<=n-p+1;i++)  dfs(i,p+1);
} 
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)  scanf("%d",&a[i]);
    sort(a+1,a+n+1);
    c[n+1]=0;
	for(int i=n;i>=1;i--)  c[i]=a[i]+c[i+1];
	for(int i=n;i>=1;i--)  d[i]=c[i]+d[i-1];
	int end=n-k+1;
	int i=1;
	while(i<=end)
	{
		dfs(i,1);
		i++;
	}
	cout<<ans%1000000007;
	return 0;
}
