#include <iostream>
#include <cstdio>
using namespace std;
long long n, w;
int main() {
	freopen("poplava.in", "r", stdin);
	freopen("poplava.out", "w", stdout);
	
	scanf("%lld%lld", &n, &w);
	
	long long maxw = (n - 1) * (n - 2) / 2;
	
	if (w > maxw) {
		printf("-1");
		return 0;
	}

	long long tmp = 0;
	long long puti;
	for (int i = 1; i <= n; ++i) {
		tmp += i;
		if (i * (n - 1) - tmp >= w) {
			puti = i;
			break;
		}
	}
	int res = w + (n - 2) - (puti * (n - 1) - tmp);
	for (int i = puti + 1; i <= res + 1; ++i) {
		printf("%d ", i);
	}
	printf("1 ");
	for (int i = res + 2; i <= n - 1; ++i) {
		printf("%d ", i);
	}
	for (int i = 2; i <= puti; ++i) {
		printf("%d ", i);
	}
	printf("%d", n);
	return 0;
}
