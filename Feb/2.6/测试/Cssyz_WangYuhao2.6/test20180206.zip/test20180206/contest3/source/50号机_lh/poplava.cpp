#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
using namespace std;
int n,x,l;
#define     maxn   1000005
int a[maxn];
int b[maxn];
int c[maxn];
long long sum=0;
bool check(int q)
{   int num=0;
	for(int i=1;i<=l;i++)
	 	if(q!=c[i])   num++;
	 	
	if(num==l)   return 1;
	else         return 0;
	
}
int main ()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%d%d",&n,&x);
  for(int i=1;i<=n;i++)
     a[i]=i;
	for(int i=1;i<=n;i++)
	  {
	   if(n-1>a[i])
	   b[i]=n-1-a[i];
	   else 
	   b[i]=0;
	
	   sum+=b[i];
	  }
 // cout<<sum;  
    if(x==sum)
    {
    	cout<<n<<" ";
    	for(int i=1;i<=n-2;i++)
    	cout<<i<<" ";
    	cout<<n-1;
    }
    if(x>sum)  cout<<-1; // 6 1 2 3 4 5 8 7  
    if(x<sum)
   {  
   	if(x<n-1)
   	 {
   	 	cout<<n<<" "<<n-1-x<<" "<<n-1<<" ";
   	 	for(int i=1;i<=n-2;i++)
   	 	   if(i!=n-1-x)
			cout<<i<<" ";
			return 0;
   	 }
     else{
     	   memset(b,0,sizeof(b));
     	   for(int i=1;i<=n;i++)
     	    for(int j=1;j<=n;j++)
			 {
			 	if(n-1>j)
     	    	 b[i]=n-1-j;
     	    	else b[i]=0;     	    	
     	    }
     	//     int k=1;
    /* 	     while(k!=n-2)
     	     {
     	     	if(x<b[q])
     	     		q++;
		      	if(x==b[q]) 
				 {
				  x-=b[q];
			      c[l]=q;
				  l++;
			     }
				 if(x>b[q])	
				  { 	
                     x-=b[q];
                     c[l]=n-1-q;
					 q++;
					 l++;				  	
				  }	
     	     	k++;
     	     }*/
     	     int sum=0;
     	    for(int i=1;i<=n-2;i++)
			    sum+=b[i];
		       if(sum<x)   {cout<<-1; return 0;}  
			   if(sum==x)  {cout<<n<<" ";
			   	for(int i=1;i<=n-2;i++)
			   	   cout<<n-2-b[i]<<" ";
			   	   cout<<n-1;
			   }	
			 	if(sum>x)
            {
            	int t=sum-x;
            	cout<<n<<" ";
				for(int i=1;i<=n;i++)
                  {
                  	cout<<i<<" ";
                  }
				             	
            }			 	
 
			

       
     	     
     	     
     }   	  

   }


	return 0;
}
