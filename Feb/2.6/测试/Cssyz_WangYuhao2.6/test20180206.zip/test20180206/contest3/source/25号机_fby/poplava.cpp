#include<cstdio>  
#include<cstdlib>  
#include<cmath>  
#include<ctime>  
#include<algorithm>  
#include<cstring>  
#include<string>  
#include<iostream>  
#include<iomanip>  
#include<vector>  
#include<map>  
#include<set>  
#include<functional>  
#include<sstream>  
#include<iterator>   
#include<queue>  
using namespace std; 
int n,x; 
int a[1231234];
bool b[1231234];
bool e[1231234];
int main()  
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
    scanf("%d%d",&n,&x);
    long long nn=n,xx=x;
if(xx>((nn-2)*(nn-1))/2) printf("-1");
else
{
	for(int i=n-2;i>=1;i--)
	{
		if(x>=i) {x-=i;e[i]=true;}
		if(x==0) break;
	}
	int top=1,k=n-1,i=n-2;
	a[top]=n;
	while(top<=n)
	{
		bool QAQ=true;
		while(e[i])
		{
			QAQ=false;
			a[++top]=k-i;
			i--;
		}
		if(QAQ) i--;
		a[++top]=k;
		k--;
	}
	for(int j=1;j<=n;j++) printf("%d ",a[j]);
}
    fclose(stdin);
    fclose(stdout);
    return 0;  
} 
