#include <iostream>
#include <cstdio>
#include <climits>
#include <algorithm>
#define MOD 1000000007ll
using namespace std;
int a[100001];
int n,k;
bool cmp(int a,int b){
	return a>b;
}
long long c[100001][51];
long long jie[100001];
/*long long c(int a,int b){
	if(a==b)
		return 1;
	return (jie[a]/(jie[b]*jie[a-b]%MOD))%MOD;
}*/
int main(){
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	sort(a+1,a+n+1,cmp);
	jie[0]=1;
	for(int i=1;i<=n;i++)
		jie[i]=(jie[i-1]*i)%MOD;
	long long ans=0;
	ans=0;
	c[0][0]=c[1][0]=c[1][1]=1;
	for(int i=1;i<=n;i++){
		c[i][0]=1;
		for(int j=1;j<=k;j++)
			c[i][j]=(c[i-1][j-1]+c[i-1][j])%MOD;
	}
	for(int i=1;i<=n-k+1;i++){
		ans+=(c[n-i][k-1]*(long long)(a[i]))%MOD;
	}
	printf("%I64d\n",ans);
	return 0;
}
