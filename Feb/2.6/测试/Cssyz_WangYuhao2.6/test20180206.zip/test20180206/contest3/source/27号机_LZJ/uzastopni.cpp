#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<iostream>
#include<iomanip>
#include<algorithm>
#include<ctime>
#include<cmath>
#include<vector>
using namespace std;
vector <int>a[10001];
int v[10001];
int fa[10001];
bool p[10001];
int dfs(int u)
{
	p[u]=true;
	for(int i=0;i<a[u].size();i++)
	{
		if(!p[a[u][i]]) 
		{
			fa[a[u][i]]=u;
			dfs(a[u][i]);
	    }
	}
}
int fenzhi(int u)
{
	int ans=1;
	for(int i=0;i<a[u].size();i++)
	{
		if(fa[u]!=a[u][i] &&  abs(v[a[u][i]]-v[u])<=1) ans=ans*(fenzhi(a[u][i])+1);
	}
	return ans;
}
int main()
{
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&v[i]);
	for(int i=1;i<=n-1;i++)
	{
		int l,r;
		scanf("%d%d",&l,&r);
		a[l].push_back(r);
		a[r].push_back(l);
	}
	dfs(1);
	cout<<fenzhi(1);
	return 0;
}
