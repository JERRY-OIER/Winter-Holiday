#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int n;
int k;
long long  tot;
int a[30000000];
//int b[100000];
//int f[100000];
int l,r;
void dfs(int num,int maxx,int t)
{    
     if(t==k)
     {
     	tot+=maxx%1000000007;
     	return;
     }
     for(int i=num+1;i<=n;i++)
     {
     	dfs(i,max(a[i],maxx),t+1);
     }
	
}
int main()
{  
    freopen("perica.in","r",stdin);
    freopen("perica.out","w",stdout);
	scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++)
    {
    	scanf("%d",&a[i]);
    }
    
    for(int i=1;i<=n-k+1;i++)
    dfs(i,a[i],1);
   
    printf("%d",tot);
	return 0;
}
