#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std;
const long long MOD = 1000000007;
int n, k;
long long a[100001], l[100001], ans;

void make() {
	a[0] = 1;
	a[1] = 1;
	for (int i = 2; i <= n; i++) {
		a[i] = a[i - 1] * i;
		a[i] %= MOD;
	}
}

int main() {
	freopen ("perica.in", "r", stdin);
	freopen ("perica.out", "w", stdout);
	scanf ("%d%d", &n, &k);
	make();
	for (int i = 1; i <= n; i++) {
		scanf ("%lld", &l[i]);
	}
	sort (l + 1, l + n + 1);
	for (int i = n; i >= k; i--) {
		long long x = (a[i - 1] / ((a[k - 1] * a[i - k]) % MOD)) % MOD;
		ans += x * l[i];
		ans %= MOD;
	}
	cout<<ans<<endl;
	return 0;
}
