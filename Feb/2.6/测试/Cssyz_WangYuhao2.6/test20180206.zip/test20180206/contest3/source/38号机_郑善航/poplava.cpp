#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int n;
int k;
long long  tot;
int a[30000000];
//int b[100000];
//int f[100000];
int l,r;
int main()
{  
    freopen("poplava.in","r",stdin);
    freopen("poplava.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<n-1;i++)
	{
		a[i]=n-i-1;
	//	fa[a[i]]=n-1;
		tot+=a[i];
	}
	int o=0;
	a[n-1]=n-1;
	//cout<<tot;
//	for(int i=1;i<n;i++) cout<<a[i]<<" ";
	l=1,r=n-1;
	if(tot<k) 
	{
	  cout<<"-1";
	   return 0;	
	}
	
	while(1)
	{
		while(tot>k)
		{ 
		  if(a[l]==n-1) 
		  {
		  	cout<<"-1"; return 0;
		  }
		//	b[a[l]]=1;
			r++;a[r]=a[l];
			l++;
			tot-=n-1-a[r];
		//	fa[a[r]]=-1;
		}
		int pos=r;
		while(tot<k)
		{
			if(a[pos-1]==n-1||a[pos-1]<a[pos]) 			break;
			
			else
			{
				swap(a[pos],a[pos-1]);
				pos--;
				tot++;
			}
			
		}
		if(tot==k) break;
	}
	printf("%d ",n);
	for(int i=l;i<=r;i++)printf("%d ",a[i]);
	
	return 0;
}
