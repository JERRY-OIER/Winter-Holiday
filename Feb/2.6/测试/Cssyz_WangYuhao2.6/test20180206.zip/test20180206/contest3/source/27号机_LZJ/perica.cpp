#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<iostream>
#include<iomanip>
#include<algorithm>
#include<ctime>
#include<cmath>
using namespace std;
long long a[100001];
int n,k;
long long ans;
const long long mod=1000000007;
long long f[100001][51];
int cmp(int a,int b)
{
	return a>b;
}
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++) scanf("%I64d",&a[i]);
    sort(a+1,a+1+n,cmp);
	for(int i=0;i<=n;i++) f[i][0]=1;
	f[1][1]=1;
	for(int i=1;i<=n;i++)
	   for(int j=1;j<=k;j++)
	   {
			if(i==1 && j==1) continue;
			f[i][j]=(f[i-1][j-1]+f[i-1][j])%mod;	   	
	   }
	for(int i=1;i<=n;i++)
	{
		if(n-i+1<k) break;
		ans=(ans+(a[i]*f[n-i][k-1])%mod)%mod;
	} 
	cout<<ans;
	return 0;
}
