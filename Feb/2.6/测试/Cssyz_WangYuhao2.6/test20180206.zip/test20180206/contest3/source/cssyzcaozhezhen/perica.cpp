#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define maxn 100010
using namespace std;
typedef long long ll;
struct P{
	int pos,num;
}a[maxn];
bool cmp(P a,P b)
{
	return a.num<b.num;
}
int n,k;
int x[maxn];
ll mod=1000000007;
ll C[maxn];
ll ch(int x)
{
	ll y=(ll) x;
	ll pro=1;
	for(ll i=1;i<=y;i++)   pro*=i;
	return pro;       
}
void Get_C()
{
	C[k-1]=1;
	if(k-1==1)
	{
		for(int i=1;i<=n;i++)   C[i]=i;
		return;
	}
	for(ll i=(ll)k;i<=n;i++)
	{
		C[i]=(C[i-1]*(i))/(i-(k-1))%mod;
	}
}
ll ans=0;
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	scanf("%d%d",&n,&k);	
	for(int i=1;i<=n;i++)   scanf("%d",&x[i]);
	if(k==1)
	{
		ll sum=0;
		for(int i=1;i<=n;i++)   sum=(sum+x[i])%mod;
		printf("%lld",sum);
	}
	for(int i=1;i<=n;i++)   a[i].pos=i;
	for(int i=1;i<=n;i++)   a[i].num=x[i];
	sort(a+1,a+n+1,cmp);
	ll p=ch(k-1);
	Get_C();
	for(int i=n;i>=1;i--)
	{
		ans=(ans+(ll)a[i].num*C[i-1])%mod;
	}
	printf("%lld\n",ans);
	return 0;
}
/*
5 3
2 4 2 3 4
*/
