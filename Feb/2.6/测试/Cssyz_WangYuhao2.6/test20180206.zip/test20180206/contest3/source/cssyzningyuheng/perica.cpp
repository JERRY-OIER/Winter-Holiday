#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
long long n,i,j,k,l,b[102][102],a[100002],jc[100002],ans;
long long ny(long long x,long long y){
	long long o=1;
	while(y!=0){
		if(y%2==1)
			o=(o*x)%1000000007;
		x=(x*x)%1000000007;
		y/=2;
	}
	return o;
}
long long C(long long x,long long y){
	return ((jc[x]*ny(jc[y],1000000005))%1000000007*ny(jc[x-y],1000000005))%1000000007;
}
int main(){
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	jc[0]=1;
	for(i=1;i<=n;i++)
		jc[i]=jc[i-1]*i%1000000007;
	sort(a+1,a+n+1);
	for(i=n;i>=k;i--)
		ans=(ans+a[i]*C(i-1,k-1))%1000000007;
	printf("%lld\n",ans);
	return 0;
}
