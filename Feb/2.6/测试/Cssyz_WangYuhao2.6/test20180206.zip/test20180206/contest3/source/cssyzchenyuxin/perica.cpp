#include <bits/stdc++.h>

using namespace std;

const long long mod = 1000000007;
 
long long n, k, a[100005], ans = 0;

long long calc(int x, int y)
{
	long long c = 1;
	for (long long i = 1; i < x; i++) c = (((y - i + 1) % mod) * (c % mod) / (i % mod)) % mod;
	return c;
}

int main()
{
	freopen("perica.in", "r", stdin);
	freopen("perica.out", "w", stdout);
	//ios::sync_with_stdio(false);
	cin >> n >> k;
	for (long long i = 1; i <= n; i++) cin >> a[i];
	sort(a + 1, a + n + 1);
	long long dim = calc(k, n);
	//cout << dim << endl;
	long long sum = 0;
	while(dim > 0) 
	{
		if(k == n) { sum++; ans = (ans + a[n]) % mod; break; }
		else 
		{
			sum = ((k % mod) * ((n - k) % mod)) % mod;
			dim -= sum;
			//cout << sum << endl;
			ans = (ans + (sum) * (a[n] % mod)) % mod;
			n--;
		}
	}
	cout << ans << endl;
	return 0;
}
