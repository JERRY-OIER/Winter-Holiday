#include <bits/stdc++.h>

using namespace std;

int n;

int main() {
	freopen("uzastopni.in", "r", stdin);
	freopen("uzastopni.out", "w", stdout);
	scanf("%d", &n);
	printf("12\n");
	return 0;
}
