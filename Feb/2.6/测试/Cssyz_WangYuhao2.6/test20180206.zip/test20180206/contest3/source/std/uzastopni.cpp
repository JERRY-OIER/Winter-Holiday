#include <cstdio>
#include <cstring>
#include <cctype>
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

#define N 10010
#define M 110
vector<int> lp[N], rp[N], s[M];
bool is[M];
int select[N], tclock;
int head[N << 1], to[N << 1], nxt[N << 1];
void addedge(int a, int b) {
	static int q = 1;
	to[q] = b;
	nxt[q] = head[a];
	head[a] = q++;
}
void make(int a, int b) {
	addedge(a, b);
	addedge(b, a);
}

int v[N];
int q[N], pa[N];
bool vis[N];

void work(int x) {
	int i, j, k;
	memset(is, 0, sizeof is);
	is[v[x]] = 1;
	++tclock;
	for (i = 1; i <= 100; ++i)
		s[i].clear();
	for (j = head[x]; j; j = nxt[j])
		if (to[j] != pa[x]) {
			for (i = 0; i < lp[to[j]].size(); ++i)
				s[lp[to[j]][i]].push_back(to[j]);
		}
	for (i = v[x] + 1; i <= 100; ++i) {
		if (is[i - 1]) {
			for (j = 0; j < s[i].size(); ++j) {
				if (select[s[i][j]] != tclock) {
					select[s[i][j]] = tclock;
					for (k = 0; k < rp[s[i][j]].size(); ++k)
						is[rp[s[i][j]][k]] = 1;
				}
			}
		}
	}
	for (i = 1; i <= 100; ++i)
		if (is[i])
			rp[x].push_back(i);

	memset(is, 0, sizeof is);
	is[v[x]] = 1;
	++tclock;
	for (i = 1; i <= 100; ++i)
		s[i].clear();
	for (j = head[x]; j; j = nxt[j])
		if (to[j] != pa[x]) {
			for (i = 0; i < rp[to[j]].size(); ++i)
				s[rp[to[j]][i]].push_back(to[j]);
		}
	for (i = v[x] - 1; i >= 1; --i) {
		if (is[i + 1]) {
			for (j = 0; j < s[i].size(); ++j) {
				if (select[s[i][j]] != tclock) {
					select[s[i][j]] = tclock;
					for (k = 0; k < lp[s[i][j]].size(); ++k)
						is[lp[s[i][j]][k]] = 1;
				}
			}
		}
	}
	for (i = 1; i <= 100; ++i)
		if (is[i])
			lp[x].push_back(i);
}

int main() {
	freopen("uzastopni.in", "r", stdin);
	freopen("uzastopni.out", "w", stdout);
	//freopen("uzatopni.in.14", "r", stdin);
	int n, i, j, k, a, b;
	scanf("%d", &n);
	for (i = 1; i <= n; ++i)
		scanf("%d", &v[i]);
	for (i = 1; i < n; ++i) {
		scanf("%d%d", &a, &b);
		make(a, b);
	}
	
	int fr = 0, ta = 0;
	vis[q[ta++] = 1] = 1;
	while (fr < ta) {
		i = q[fr++];
		for (j = head[i]; j; j = nxt[j])
			if (!vis[to[j]])
				vis[q[ta++] = to[j]] = 1, pa[to[j]] = i;
	}

	for (i = n - 1; i >= 0; --i)
		work(q[i]);
	
	printf("%d\n", lp[1].size() * rp[1].size());

	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
