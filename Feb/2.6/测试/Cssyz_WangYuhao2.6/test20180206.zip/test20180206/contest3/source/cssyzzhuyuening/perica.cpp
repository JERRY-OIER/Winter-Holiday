#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,k;
unsigned long long ans,f=1;
int MOD=1000000007;
struct data{
    int val,id;
}a[100100];
bool cmp(data a,data b)
{
    if(a.val==b.val)return a.id<b.id;
    return a.val<b.val;
}
int main()
{
    freopen("perica.in","r",stdin);
    freopen("perica.out","w",stdout);
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;++i)scanf("%d",&a[i].val),a[i].id=i;
    sort(a+1,a+n+1,cmp);
    for(int i=k;i<=n;++i)
    {
        ans=(ans+(((long long)a[i].val*f)%MOD))%MOD;
        f=(f*i/(i-k+1))%MOD;
    }
    printf("%lld\n",ans);
    return 0;
}
