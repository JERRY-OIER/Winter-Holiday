#include<cstdio>
using namespace std;
int n,goal;
int s[1000010];
bool k[1000010];
void dfs(int x){
	if(x==n+1){
		
	}
	for(int i=n;i>=1;i--)
	 if(!k[i]){
	 	k[i]=true;
	 	dfs(x+1);
	 	k[i]=false;
	 }
}
int main(){
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%d%d",&n,&goal);
	printf("-1\n");
	return 0;
}
