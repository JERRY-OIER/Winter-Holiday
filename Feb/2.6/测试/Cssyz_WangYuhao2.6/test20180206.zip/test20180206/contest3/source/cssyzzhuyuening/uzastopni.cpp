#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int main()
{
    freopen("uzastopni.in","r",stdin);
    freopen("uzastopni.out","w",stdout);
    cout<<1<<endl;
    return 0;
}
