#include <cstdio>
#include <cstring>
#include <cctype>
#include <iostream>
#include <algorithm>
using namespace std;

#define N 100010
int a[N];
int fac[N];
static const int mod = 1000000007;

int pow(int x, int y) {
	int re = 1;
	for (; y; y >>= 1, x = (long long)x * x % mod)
		if (y & 1)
			re = (long long)re * x % mod;
	return re;
}

int C(int n, int m) {
	if (m > n)
		return 0;
	return (long long)fac[n] * pow(fac[m], mod - 2) % mod * pow(fac[n - m], mod - 2) % mod;
}
void inc(int &x, int y) {
	if ((x += y) >= mod)
		x -= mod;
}

int main() {
	freopen("perica.in", "r", stdin);
	freopen("perica.out", "w", stdout);
	
	int n, k, i, j;
	scanf("%d%d", &n, &k);
	for (i = 1; i <= n; ++i)
		scanf("%d", &a[i]);
	for (fac[0] = 1, i = 1; i <= n; ++i)
		fac[i] = (long long)fac[i - 1] * i % mod;

	int ans = 0;
	sort(a + 1, a + n + 1);
	for (int i = k; i <= n; ++i)
		inc(ans, (long long)a[i] * C(i - 1, k - 1) % mod); 

	printf("%d", ans);

	fclose(stdin);
	fclose(stdout);

	return 0;
}
