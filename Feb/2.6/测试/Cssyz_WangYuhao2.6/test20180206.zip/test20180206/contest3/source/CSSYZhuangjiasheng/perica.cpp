#include <bits/stdc++.h>
#define MAX_N 150010
#define MOD 1000000007LL
typedef unsigned long long ll;
using namespace std;

int N, k;
ll x[MAX_N];
ll res;

int main () {
  freopen ("perica.in", "r", stdin);
  freopen ("perica.out", "w", stdout);
  scanf("%d%d", &N, &k);
  for (int i = 1;i <= N; ++i) scanf("%lld", x + i);  //N
  sort(x + 1, x + N + 1);   //NlogN
  ll s = k - 1, cnt = k;
  ll t = 1;
  for (int i = k;i <= N; ++i) {    //N
    res += x[i] * t, res %= MOD;
    t = ((t * (cnt) % MOD) / ((cnt - s) % MOD)) % MOD;
    ++cnt;
  }
  printf("%lld\n", res);
  return 0;
}
