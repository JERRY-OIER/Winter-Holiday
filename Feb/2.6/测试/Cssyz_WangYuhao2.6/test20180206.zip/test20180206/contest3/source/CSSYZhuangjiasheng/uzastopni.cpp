#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstring>
#define MAX_N 10010
#define INF 2147483647
using namespace std;
struct node {
  int val, id;
}x[MAX_N];

int N;
int fa[MAX_N], cnt[MAX_N], begin[MAX_N], end[MAX_N];
int d[MAX_N], dl;
bool book[MAX_N], vis[MAX_N];
int front, rear;
int res;

bool check (int t, int w) {
  memset(cnt, 0, sizeof(cnt));
  memset(begin, 0, sizeof(begin));
  memset(end, 0, sizeof(end));
  memset(vis, 0, sizeof(vis));
  for (int i = 1;i <= N; ++i) begin[i] = x[i].val;
  for (int i = 1;i <= N; ++i) end[i] = x[i].val;
  
  for (int i = 1;i <= dl; ++i) {
    int minval = INF, maxval = 0, sum = 0;
    bool flag = false;
    for (int k = d[i]; k; k = fa[k]) {
      //printf("%d\n", k);
      if (book[k]) flag = true; //找到第一个有标记的节点，检查正式开始
      if (!book[k] && flag) return false; //子树标记但父节点未标记，不符合条件。false
      if (!book[k]) continue;  //这个没标记，对答案无贡献，跳过
      if (!vis[k]) sum++;
      vis[k] = true;
      end[k] = max(end[k], maxval);
      begin[k] = min(begin[k], minval);
      maxval = max(maxval, end[k]);
      minval = min(minval, begin[k]);
      cnt[k] += sum;  //多一颗子节点
    } //printf("\n");
  }

  //for (int i = 1;i <= N; ++i) printf("node:%d begin:%d  end:%d cnt:%d\n", i, begin[i], end[i], cnt[i]);
  for (int i = 1;i <= N; ++i) {
    if (!book[i]) continue;
    if (end[i] - begin[i] + 1 != cnt[i]) return false;
  }
  return true;
}

void print () {
  printf("%d %d\n", front, rear);
  for (int i = 1;i <= N; ++i) printf("%d ", i);printf("\n");
  printf("book: ");for (int i = 1;i <= N; ++i) printf("%d ", book[i]); printf("\n");
}

bool cmp (node a, node b) {return a.val < b.val;}
int main () {
  freopen ("uzastopni.in", "r", stdin);
  freopen ("uzastopni.out", "w", stdout);
  scanf("%d", &N);
  rear = N;
  for (int i = 1;i <= N; ++i) scanf("%d", &x[i].val), x[i].id = i;
  int u, v;
  for (int i = 1;i <= N; ++i) {
    scanf("%d%d", &u, &v);
    fa[v] = u;
    book[u] = false;
  }

  sort(x + 1, x + N + 1, cmp);
  //for (int i = 1;i <= N; ++i) printf("val:%d id:%d\n", x[i].val, x[i].id);
  for (int i = 1;i <= N; ++i) if (x[i].id == 1) front = i;
  for (int i = front;i <= N; ++i) book[i] = true;

  while (front > 0) {
    rear = N;
    while (rear >= front) {
      //print();
      if (check(front, rear)) res++;
      book[rear--] = false;
      //printf("finish\n");
    }
    book[--front] = true;
  }
  printf("%d\n", res);
  return 0;
}
