#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<ctime>
#include<string>
#include<iomanip>
using namespace std;
int a[100011];
bool b[100011];
int	n;
long long m;
void ans()
{
	cout<<n<<" ";
	for(int i=1;i<=n;i++)
	if(b[i]==1) printf("%d ",i);
	
	cout<<n-1<<" ";
	b[n]=b[n-1]=1;
	for(int i=n;i>=1;i--)
	if(b[i]==0)
	printf("%d ",i);
	exit(0);
}
int main()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);

	
	cin>>n>>m;

	for(int i=1;i<=n;i++)
	{
		a[i]=a[i-1]+i;
	}
	/*for(int i=1;i<=n;i++)
	cout<<a[i]<<" ";*/
	if(m >(n-1)*(n-2)-a[n-2] || n<3){
		cout<<-1;
		return 0;
	}
	
	
	if(m <=n-2)
	{
		b[n-m-1]=1;
		ans();
	}
	int st=n-2,mx=n-1;
	while(m-st>st-1)
	{
		b[mx-st]=1;
		m-=st;
		st--;
	}
	b[mx-st]=1;
	b[mx-(m-st)]=1;
	ans();
	fclose(stdin);fclose(stdout);
	return 0;
}

