#include<iostream>
#include<cstdio>
#define MOD 1000000007
using namespace std;
int n,k,tree[200001],jc[100001],ans,a[100001]; 
int insert(int x,int l,int r,int loc,int s)
{
	if(l==r)
		return tree[x]=s;
	int mid=l+r>>1;
	if(loc<=mid)
		return tree[x]=max(tree[x],insert(x*2,l,mid,loc,s));
	else
		return tree[x]=max(tree[x],insert(x*2+1,mid+1,r,loc,s));
}
int search(int x,int l,int r,int nl,int nr)
{
	if(l>=nl&&r<=nr)
		return tree[x];
	int mid=(l+r)>>1,ans=0;
	if(nl<=mid)
		ans=search(x*2,l,mid,nl,nr);
	if(nr>mid)
		ans=max(ans,search(x*2+1,mid+1,r,nl,nr));
	return ans;
}
void solve(int x,int last,int sum)
{
	int r;
	if(x>k)
	{
		ans+=sum;
		return;
	}
	for(int i=last+1;i<=n-k+x;i++)
	{
		r=max(sum,a[i]);
		if(i+1<=n&&search(1,1,n,i+1,n)<=a[i])
			ans=(ans+(r*jc[n-i]/jc[k-x]/jc[n-i-k+x])%MOD)%MOD;
		else
			solve(x+1,i,r);
	}
}
int main()
{
    freopen("perica.in","r",stdin);
    freopen("perica.out","w",stdout);
    cin>>n>>k;
    for(int i=1;i<=n;i++)
    {
    	scanf("%d",&a[i]);
    	insert(1,1,n,i,a[i]);
    }
    jc[0]=1;
    for(int i=1,a=1;i<=n;i++)
    {
    	a=a*i%MOD;
    	jc[i]=a;
    }
    solve(1,0,0);
    cout<<ans<<endl;
	return 0;        
}
