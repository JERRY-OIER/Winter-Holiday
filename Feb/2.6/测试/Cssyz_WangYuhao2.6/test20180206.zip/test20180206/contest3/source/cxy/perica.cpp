#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<ctime>
#include<string>
#include<iomanip>
using namespace std;
int a[1000000];
int m,ans=0;
int n;
int sq[10],t=0;
void dfs(int x,int k,int mx)
{
	if(x==m){
		ans+=mx;
		ans=ans%1000000007;
		for(int i=1;i<=t;i++)
		cout<<sq[i]<<" ";
		cout<<endl;
		return;
	}
	for(int i=k;i<=n-(m-x)+1;i++){
	//	sq[++t]=a[i];
		dfs(x+1,i+1,max(mx,a[i]));
	//	t--;
	}
	
	
}
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	
	cin>>n;
	cin>>m;
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	dfs(0,1,0);
	cout<<ans;
	fclose(stdin);fclose(stdout);
	return 0;
}

