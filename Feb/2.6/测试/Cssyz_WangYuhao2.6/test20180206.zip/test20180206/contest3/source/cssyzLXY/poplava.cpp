#include <bits/stdc++.h>

using namespace std;
const int MAXN = 1000000;

int n;
long long x;
int a[11];
bool book[11];
bool use[MAXN + 1];

void DFS(int);

int main() {
	freopen("poplava.in", "r", stdin);
	freopen("poplava.out", "w", stdout);
	scanf("%d%lld", &n, &x);
	long long maxCan = ((long long)n * (long long)n - 3 * (long long)n + 2) / 2;
	if (x == maxCan) {
		printf("%d ", n);
		for (int i = 1; i < n; i++) printf("%d ", i);
		printf("\n");
		return 0;
	}
	if (x > maxCan) {
		printf("-1\n");
		return 0;
	}
	if (n <= 10) DFS(1);
	else {
		printf("%d ", n);
		for (int i = 1; i < n; i++) {
			int add = n - 1 - i;
			if (x >= add) {
				x -= add;
				printf("%d ", i);
				use[i] = true;
			}
		}
		for (int i = n - 1; i >= 1; i--) {
			if (!use[i]) printf("%d ", i);
		}
		printf("\n");
	}
	return 0;
}

void DFS(int t) {
	if (t > n) {
		int tallest = 1;
		for (int i = 1; i <= n; i++) {
			if (a[i] > a[tallest]) tallest = i;
		}
		long long ans = 0;
		int left = 1;
		for (int i = left; i <= tallest; i++) {
			if (a[i] > a[left]) left = i;
			ans += a[left] - a[i];
		}
		int right = n;
		for (int i = right; i >= tallest; i--) {
			if (a[i] > a[right]) right = i;
			ans += a[right] - a[i];
		}
		if (ans == x) {
			for (int i = 1; i <= n; i++) printf("%d ", a[i]);
			printf("\n");
			exit(0);
		}
		return ;
	}
	for (int i = 1; i <= n; i++) {
		if (!book[i]) {
			book[i] = true;
			a[t] = i;
			DFS(t + 1);
			book[i] = false;
		}
	}
}

