#include<cstdio>  
#include<cstdlib>  
#include<cmath>  
#include<ctime>  
#include<algorithm>  
#include<cstring>  
#include<string>  
#include<iostream>  
#include<iomanip>  
#include<vector>  
#include<map>  
#include<set>  
#include<functional>  
#include<sstream>  
#include<iterator>   
#include<queue>  
using namespace std;  
int n,k;
const long long md=1000000007;
int a[121234];
long long ans,x;
int main()  
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++) scanf("%d",&a[i]);
    sort(a+1,a+1+n);
    x=1;
    ans=(x*a[k])%md;
    for(int i=k+1;i<=n;i++)
    {
    	 x=(x*(i-1)/(i-k))%md;
    	 ans=(ans+(a[i]*x)%md)%md;
    }
    cout<<ans;
    fclose(stdin);
    fclose(stdout);
    return 0;  
} 
