#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<string>
using namespace std;
int n,x;
int a[100001];
int main(){
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%d%d",&n,&x);
	for(int i=1;i<=n;i++) a[i]=n-i+1;
	
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++){
	  	
	  	
	  	
	}
		
	
	printf("-1");
	return 0;
}
