#include<cstdio>
#include<algorithm>
#define mod 1000000007
int num[100010];
int C[100010];
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	int n,m;
	scanf("%d %d\n",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&num[i]),C[i]=i;
	std::sort(num+1,num+n+1);
	for(int i=2;i<m;i++)
		for(int j=n;j>=i;j--)
		{
			C[j]=0;
			for(int k=i-1;k<j;k++) C[j]=(C[j]+C[k])%mod;
		}
	for(int i=m+1;i<=n;i++) num[i]=(num[i-1]+C[i-1]*num[i])%mod;
	printf("%d\n",num[n]);
	return 0;
}

