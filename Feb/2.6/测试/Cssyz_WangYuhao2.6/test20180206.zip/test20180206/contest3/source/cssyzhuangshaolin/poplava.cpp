#include<iostream>
#include<cstdio>
#include<stack>
using namespace std;
int jsq;
long long n,x;
stack<int>st;
int main()
{
    freopen("poplava.in","r",stdin);
    freopen("poplava.out","w",stdout);
    cin>>n>>x;
    if(2*x>=(n-1)*(n-2)||x<0)
    {
    	if(2*x==(n-1)*(n-2))
    	{
    		printf("%d",n);
    		for(int i=1;i<=n-1;i++)
    			printf(" %d",i);
    		printf("\n");
    	}
    	else
    		printf("-1\n");
    	return 0;
    }
    if(x==0)
    {
    	for(int i=1;i<=n;i++)
    		printf("%d ",i);	
    	printf("\n");
    	return 0;	
    }
    printf("%d",n-1);
    jsq=1;
	while(x&&jsq<n-1)
	{
		if(x>=n-1-jsq)
		{
			x-=n-1-jsq;
			printf(" %d",jsq);
		}
		else
			st.push(jsq);
		jsq++;
	}
	printf(" %d",n);
	while(!st.empty())
	{
		printf(" %d",st.top());
		st.pop();
	}
	printf("\n");
	return 0;
}
