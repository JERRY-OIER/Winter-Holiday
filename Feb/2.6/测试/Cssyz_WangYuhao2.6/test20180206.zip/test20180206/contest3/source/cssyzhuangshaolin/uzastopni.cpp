#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("uzastopni.in","r",stdin);
    freopen("uzastopni.out","w",stdout);
    cout<<"10"<<endl;
	return 0;        
}
