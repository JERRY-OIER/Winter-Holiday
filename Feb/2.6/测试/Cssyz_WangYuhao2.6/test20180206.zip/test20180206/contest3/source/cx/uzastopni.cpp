#include<iostream>
#include<algorithm>
#include<fstream>
using namespace std;
ifstream fin("uzastopni.in");
ofstream fout("uzastopni.out");
int main()
{
	fout<<"7";
	return 0;
}
