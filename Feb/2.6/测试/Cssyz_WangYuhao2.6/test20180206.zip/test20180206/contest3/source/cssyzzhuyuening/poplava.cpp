#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
long long n,x;
int book[1001000];
int main()
{
    freopen("poplava.in","r",stdin);
    freopen("poplava.out","w",stdout);
    scanf("%lld%lld",&n,&x);
    if(((n-1)*(n-2))/2<x)
    {printf("-1\n");return 0;}
    printf("%lld ",n);
    for(int i=1;i<n-1;++i)
    {
        if(n-1-i<=x)
        {
            printf("%d ",i);
            book[i]=1;
            x-=(n-1-i);
        }
    }
    printf("%lld ",n-1);
    for(int i=n-2;i>=1;--i)
        if(!book[i])
            printf("%d ",i);
    printf("\n");
    return 0;
}
