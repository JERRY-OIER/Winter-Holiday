#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<string>
using namespace std;


int main(){
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	
	
	
	
	
	return 0
}
