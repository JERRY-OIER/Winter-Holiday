#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
long long n, x, sum, y, num, w[1000001], cnt, jsq;
bool used[1000001];
int main() {
	freopen ("poplava.in", "r", stdin);
	freopen ("poplava.out", "w", stdout);
	scanf ("%lld%lld", &n, &x);
	if (n == 2 && x != 0) {
		cout<<-1<<endl;
		return 0;
	}
	if (x == 0) {
		for (int i = n; i >= 1; i--) {
			printf("%d ", i);
		}
		cout<<endl;
		return 0;
	}
	if (x == 1) {
		printf("%lld %lld %lld ", n, n - 2, n - 1);
		for (int i = n - 3; i >= 1; i--) 
			printf("%d ", i);
		cout<<endl;
		return 0;
	}
	for (int i = 1; i < n - 1; i++) {
		sum += i;
	}
	if (x > sum) {
		cout<<-1<<endl;
		return 0;
	}
	for (int i = 2; i <= n; i++) {
		y = x / i;
		if (y + i / 2 + (x % i) <= n) {
			 num = i;
			 break;
		}
	}
	
	while(cnt != x) {
		for (int i = y - num / 2; jsq < num; i++) {
			if (cnt + i <= x) {
				w[++jsq] = i;
				cnt += i;
				used[i] = 1;
			}
			
		}
		if (cnt < x) {
			long long a = x - cnt;
			for (int j = 1; j <= jsq; j++) {
				if (!used[w[j] + a] && w[j] + a < n) {
					w[j] = w[j] + a;
					cnt += a;
					break;
				}
			}
		}
		num++;
		y = x / num;
	}
	memset(used, 0, sizeof(used));
	printf("%lld ", n);
	for (int i = 1; i < num; i++) {
		printf("%lld ", n - w[i]);
		used[n - w[i]] = 1;
	}
	for (int i = n - 1; i >= 1; i--) {
		if (!used[i]) {
			printf("%lld ", i);
		}
	}
	cout<<endl;
	return 0;
}
