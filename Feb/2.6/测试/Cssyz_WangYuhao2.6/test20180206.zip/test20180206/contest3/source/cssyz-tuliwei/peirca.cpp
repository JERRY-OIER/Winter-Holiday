#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
using namespace std;
long long n,k,a[100005],i,l[100005],r[100005],j,ans,mod,b[100005],f,num;
int c(int aa,int bb)
{
	int nn = 1,mm = 1,nm = 1,down,tt = 1;
	for(int o = 1; o <= bb; o++)
	{
		nn *= o;
		nn = nn % mod;
	}
	for(int o = 1; o <= aa; o++)
	{
		mm *= o;
		mm = mm % mod;
	}
	for(int o = 1; o <= bb - aa; o++)
	{
		nm *= o;
		nm = nm % mod;
	}
	down = (mm * nm) % mod;
	return (nn / (mm * nm)) % mod;
}
int  main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	mod=10000*100000+7;
	scanf("%d%d",&n,&k);
	for(i = 1; i <= n; i++)
	{
		scanf("%d",&a[i]);
	}
	a[0] = 99999999999;
	a[n + 1] = 99999999999;
	//���鼯 
	for(i = 1; i <= n; i++)
	{
		j = i - 1;
		for(;;)
			if(a[i] <= a[j])
			{
				l[i] = j;
				break;
			}
			else
				j = l[j];
	}
	for(i = n; i >= 1; i--)
	{
		j = i + 1;
		for(;;)
			if(a[i] < a[j])
			{
				r[i] = j;
				break;
			}
			else
				j = r[j];
	}
	//���鼯 
	//���ҡ����� 
	for(i = 1; i <= n; i++)
	{
		j = i - 1;
		for(;;)
			if(a[i] <= a[j])
			{
				if(j == 0)
					break;
				else
				{
					num++;
					j--;
				}
			}
			else
				j = l[j];
		b[i] += i - num - 1;
		num = 0;
	}
	for(i = n; i >= 1; i--)
	{
		j = i + 1;
		for(;;)
			if(a[i] < a[j])
			{
				if(j == n+1)
					break;
				else
				{
					num++;
					j++;
				}
			}
			else
				j = r[j];
		b[i] += n - i - num;
		num = 0;
	}
	//���ҡ����� 
	//������ 
	for(i = 1; i <= n; i++)
	{
		if(b[i] >= k-1)
		{
			f = (c(k - 1 , b[i]) * a[i]) % mod;
			ans = (ans + f) % mod;
		}
	} 
	//������ 
	printf("%d",ans);
	return 0;
}
