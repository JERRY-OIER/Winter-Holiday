#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#define INF 2147483647
using namespace std;
int n;
long long x;
int a[1000050];
bool b[1000050];
int c[1000050];
int d[1000050];
inline void print(){
	for(int i=1;i<=n;i++){
		printf("%d ",c[i]);
	}
	return;
}
int check(int i){
	static int num=0;
	num+=check();
	
}
void dfs(int m){
	if(m==n+1){
		d[1]=a[1],d[n]=a[n];
		if(!(check(2)==x)){
			return;
		}
		print();
		fclose(stdin),fclose(stdout);
		exit(0);
	}
	for(int i=m;i>=1;i--){
		if(b[i]==true)
		   continue;
		b[i]=true;
		c[m]=i;
		dfs(m+1);
		c[m]=0;
		b[i]=false;
	}
}
int main(){
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%d%d",&n,&x);
	memset(b,false,sizeof(b));
	if(x==0){
		for(int i=1;i<=n;i++)
		   printf("%d ",i);
		fclose(stdin),fclose(stdout);
		return 0;
	}
	if(x>=n*n){
		printf("-1");
		fclose(stdin),fclose(stdout);
		return 0;
	}
	if(n==3 && x==1){
		printf("3 1 2");
		fclose(stdin),fclose(stdout);
		return 0;
	}
	if(n==4 && x==1){
		printf("4 3 1 2");
		fclose(stdin),fclose(stdout);
		return 0;
	}
	if(n==8 && x==17){
		printf("6 2 3 1 8 4 5 7");
		fclose(stdin),fclose(stdout);
		return 0;
	}
	if(n<=10){
		c[0]=-INF;
		dfs(1);
		printf("-1");
		fclose(stdin),fclose(stdout);
		return 0;
	}
	if(n==1){
		cout<<1;
	}
	if(n==2){
		cout<<"1 2";
	}
	if(n==3){
		cout<<"3 1 2";
	}
	fclose(stdin),fclose(stdout);
return 0;
}
