#include <iostream>
#include <cstdio>
#include <set>
using namespace std;
struct d{
	int l, r;
	d(int l_, int r_):l(l_), r(r_){}
	d(){}
	bool operator<(d x)const{
		if(l==x.l) return r<x.r;
		return l<x.l;
	}
};
struct edge{
	int to;
	edge *next;
	edge(int t):to(t), next(NULL){}
};
struct li{
	edge *pre, *last;
	void push(int t){
		if(pre) last=last->next=new edge(t);
		else pre=last=new edge(t);
	}
}graph[10001];
int n, arr[10001]; set<d> s[10001]; bool sel[10001];
void dfs2(int p, int fa, d q){
	s[p].insert(q);
	for(edge *t=graph[p].pre;t;t=t->next){
		if(t->to==fa||sel[t->to]) continue;
		for(set<d>::iterator it=s[t->to].begin();it!=s[t->to].end();it++){
			if(it->r==q.l-1){
				sel[t->to]=1;
				dfs2(p, fa, d(it->l, q.r));
				sel[t->to]=0;
			}
			if(it->l==q.r+1){
				sel[t->to]=1;
				dfs2(p, fa, d(q.l, it->r));
				sel[t->to]=0;
			}
		}
	}
}
void dfs(int p, int fa){
	for(edge *t=graph[p].pre;t;t=t->next){
		if(t->to==fa) continue;
		dfs(t->to, p);
	}
	dfs2(p, fa, d(arr[p], arr[p]));
}
int main(){
	freopen("uzastopni.in", "r", stdin);
	freopen("uzastopni.out", "w", stdout);
	scanf("%d", &n);
	for(int i=1;i<=n;i++) scanf("%d", &arr[i]);
	int a, b;
	for(int i=1;i<n;i++){
		scanf("%d%d", &a, &b);
		graph[a].push(b);
		graph[b].push(a);
	}
	dfs(1, 0);
	cout<<s[1].size()<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}