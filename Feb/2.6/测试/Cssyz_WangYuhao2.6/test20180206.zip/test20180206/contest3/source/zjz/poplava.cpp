#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstdio>
#include<ctime>
using namespace std;
const int MAXN=1000000+5;
int ans[MAXN],change[MAXN],k=0;
int main()
{
	int n;
	long long int x,maxcap=0,delta;
	int nowmax;
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	cin>>n>>x;
	ans[0]=n;
	ans[n-1]=n-1;
	for(int i=1;i<=n-2;i++)
	    {
	    maxcap+=i;
	    ans[i]=i;
	    }
	if(x>maxcap)
	  {
	  	cout<<"-1";
	  	return 0;
	  }
	delta=maxcap-x;
	nowmax=n-2;
	while(delta>nowmax)
	     {
	     	change[k++]=n-1-nowmax;
	     	ans[n-1-nowmax]=0;
	     	delta-=nowmax;
	     	nowmax--;
	     }
	if(delta)
	{
	change[k]=n-1-delta;
	ans[change[k]]=0;	
	}
	sort(change,change+k);
	for (int i=0;i<n;i++)
	    if(ans[i]) cout<<ans[i]<<' ';
	for(int i=k;i>=0;i--) 
	    if(change[i])
		  cout<<change[i]<<' ';
	//cout<<clock()-t;
	return 0;
}
