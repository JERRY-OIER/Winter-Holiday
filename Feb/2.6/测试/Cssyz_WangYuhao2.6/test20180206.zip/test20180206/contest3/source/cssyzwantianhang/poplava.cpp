#include<cstdio>
#include<algorithm>
int main()
{	
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	int n,m;
	scanf("%d %d",&n,&m);
	int mx=n-2 , water=0;
	while(m>mx && mx) m-=mx,mx--;
	if(!mx)
	{
		printf("-1\n");
		return 0;
	}
	printf("%d %d ",n,n-m-1);
	for(int i=n-mx-2;i;i--) printf("%d ",i);
	printf("%d ",n-1);
	for(int i=n-2;i>n-mx-2;i--)
		if(i!=n-m-1) printf("%d ",i);
	return 0;
}
