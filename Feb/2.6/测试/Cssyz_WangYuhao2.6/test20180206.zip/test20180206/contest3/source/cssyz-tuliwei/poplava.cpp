#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<ctime>
#include<cstring>
using namespace std;
int n,x,sum,i,s,t[1000005];
int main()
{
	freopen("poplava.in","r",stdin);
	freopen("poplave.out","w",stdout);
	scanf("%d%d",&n,&x);
	for(i = 1; i <= n-1; i++)
		sum+=i;
	if(x > sum)
	{
		printf("-1");
		return 0;
	}
	for(i = n-2; i >= 1; i--)
	{
		s+=i;
		if(s < x)
			t[n - i - 1] = 1;
		if(s >= x)
		{
			t[n - i + s - x - 1] = 1;
			break;
		}
	}
	printf("%d ",n-1);
	for(i = 1; i < n - 1; i++)
		if(t[i] == 1)
			printf("%d ",i);
	printf("%d ",n);
	for(i = n - 2; i >= 1; i--)
		if(t[i] == 0)
			printf("%d ",i);
	return 0;
}
