#include<cstdlib>
#include<cstdio>
using namespace std;
int n,x;
int a[20];
bool b[20];
void solve(int qua)
{
	if(qua==n)
	{
		int ans=0;
		int l=0,r=0;
		for(int i=2;i<=n+1;i++)
		{
			if(a[i]-a[i-1]<0&&l==0) l=i-1;
			if(a[i]-a[i-1]<0&&l!=0) r=i-1;
			if(l!=0&&r!=0)
			{
				int min=a[l];
				if(a[r]<a[l]) min=a[r];
				for(int j=l+1;j<=r-1;j++)
					ans+=(min-a[j]);
				l=r;
				r=0;
			}
		}
		if(ans==x) 
		{
			for(int i=1;i<=n;i++) 
				printf("%d ",a[i]);
			exit(0);
		}
	}
	else
	{
		for(int i=1;i<=n;i++)
		{
			if(!b[i]) 
			{
				a[qua+1]=i;
				b[i]=1;
				solve(qua+1);
				a[qua+1]=0;
				b[i]=0;
			}
		}
	}
}
int main ()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%d%d",&n,&x);
	solve(0);
	printf("-1");
	return 0;
}
