#include <bits/stdc++.h>

using namespace std;

const long long mod = 1000000007;
const int N = 100000;

int n, k;
long long a[N + 1];
long long res;
long long tim;
long long ny[N + 1];

void get_ny(int n) {
	ny[1] = 1;
	for(int i = 2; i <= n; i++)
		ny[i] = (mod - mod / i) * ny[mod % i] % mod;
}

int main() {
	freopen("perica.in", "r", stdin);
	freopen("perica.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
	sort(a + 1, a + 1 + n);
	get_ny(n);
	tim = 1;
	for(int i = k; i <= n; i++) {
		if(i > k) tim = (tim * (i - 1) * ny[i - k]) % mod;
		res = (res + a[i] * tim) % mod;
	}
	printf("%lld\n", res);
	return 0;
}
