#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int MOD=1000000007;
int n, k; long long arr[100001], res, C[51][100001];
long long getC(int w, int e){
	if(w==e||!w) return C[w][e]=1;
	if(w>e) return C[w][e]=0;
	if(C[w][e]==-1)
		C[w][e]=(getC(w, e-1)+getC(w-1, e-1))%MOD;
	return C[w][e];
}
int main(){
	freopen("perica.in", "r", stdin);
	freopen("perica.out", "w", stdout);
	scanf("%d%d", &n, &k); k--;
	for(int i=0;i<n;i++) scanf("%I64d", &arr[i]);
	sort(arr, arr+n);
	memset(C, -1, sizeof C);
	C[0][0]=C[0][1]=C[1][1]=1;
	for(int i=k;i<n;i++)
		(res+=arr[i]*getC(k, i))%=MOD;
	cout<<res<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}