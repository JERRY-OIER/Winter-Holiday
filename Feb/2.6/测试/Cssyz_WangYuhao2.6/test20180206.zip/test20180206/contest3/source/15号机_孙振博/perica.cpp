#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<iomanip>
#include<ctime>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
#include<sstream>
#include<set>
#include<vector>
#include<queue>
using namespace std;
int a[100010];
int n,k;
long long ans=0;
const int mood=1000000007;
void fight_without_speaking(int now,int maxx,int fff)
{
	if(fff==k)
		{
			ans=(ans+maxx)%mood;
			return;
		}
	for(int i=now+1;i<=n;i++)
		{
			int u=maxx;
			if(a[i]>maxx)
			maxx=a[i];
			fff++;
			fight_without_speaking(i,maxx,fff);
			fff--;
			maxx=u;
		}
}
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)		scanf("%d",&a[i]);
	fight_without_speaking(0,0,0);
	printf("%d",ans);
	return 0;
}

