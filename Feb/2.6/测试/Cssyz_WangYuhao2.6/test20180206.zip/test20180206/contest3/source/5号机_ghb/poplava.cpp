#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n,x;
int a[11];
int tot,top;
int sta[1000];
int main(){
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%d%d",&n,&x);
	if(n>10){
		puts("-1");
		return 0;
	}
	for(int i=1;i<=n;i++)
		a[i]=i;
	// while(next_permutation(a+1,a+n+1)){
	// 	for(int i=1;i<=n;i++)
	// 		printf("%d ",a[i]);
	// 	puts("");
	// }
	// return 0;
	while(next_permutation(a+1,a+n+1)){
		tot=0;
		top=0;
		sta[++top]=a[1];
		for(int i=2;i<=n;i++){
			if(a[i]>sta[top])
			while(top>0&&sta[1]<a[i]){
				tot+=sta[1]-sta[top];
				sta[--top]=0;
			}
			sta[++top]=a[i];
		}
		if(tot==x)
			break;
	}
	for(int i=1;i<=n;i++)
		printf("%d ",a[i]);
	return 0;
}