#include<iostream>
#include<cstdio>
#include<algorithm>
#define P 1000000007
#define ll long long
using namespace std;
ll res,n,k,a[101010],lastc,C=1;
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;i++)
	 scanf("%lld",&a[i]);
	sort(a+1,a+n+1);
	for(int i=k;i<=n;i++)
	{
		if(a[i]!=a[i+1])
		{
			res=(res+(ll)(C-lastc)*a[i])%P;
			lastc=C%P;
		}
		C=C*(i+1)/(i-k+1)%P;
	}
	printf("%lld\n",res);
	return 0;
}
