#include <bits/stdc++.h>

using namespace std;

int main()
{
	freopen("uzastopni.in", "r", stdin);
	freopen("uzastopni.out", "w", stdout);
	
	return 0;
}
