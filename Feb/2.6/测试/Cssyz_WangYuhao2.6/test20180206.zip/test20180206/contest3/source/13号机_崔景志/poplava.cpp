#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<iomanip>
#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
long long n,x;
long long  a[1001000];
long long  b[1001000];
int main()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	cin>>n>>x;
	if(n<=2 && x!=0)  {cout<<-1;return 0;}
	if(n==2 && x==0)  {cout<<1<<" "<<2;     return 0;}
	long long maxx=(1+(n-2))*(n-2)/2;
	if(x>maxx)  {cout<<-1;return 0;}
	
	if(x==maxx)  
	{
		a[1]=n; a[n]=n-1;
		printf("%d ",a[1]);
		for(int i=1;i<=n-1;i++)
		printf("%d ",i);
		return 0;	
	}
	
	if(x<n-1)     
	{
		a[1]=n;
		a[2]=n-1-x;
		a[3]=n-1;
		for(int i=1;i<=3;i++)
		  printf("%d ",a[i]);
		int top=3;
		b[n]=1;b[n-1]=1;b[n-1-x]=1;
		
		for(int i=n-2;i>=1;i--)
		  if(b[i]==0)  printf("%d ",i);
		  return 0;
	} 
	long long sum=0;
	a[1]=n;//n-1  Ϊ��� 
	int top=1;
	for(int i=1;i<n-1;i++)
	{
		sum+=(n-1)-i;
		a[++top]=i;
		b[i]=1;
		int t=0;
		if(sum+n-i-2>=x)
		{
			a[++top]=sum-x+n-1;
			b[sum-x+n-1]=1;
			t=1;
		}  
		if(t==1)  break;
	}
	a[++top]=n-1;
	b[n-1]=1;
	for(int i=1;i<=top;i++)
	 printf("%d ",a[i]);
	 for(int i=n-2;i>=1;i--)
	 if(b[i]==0)  printf("%d ",i);
	return 0;
}
