#include<cstdlib>
#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=1000000007;
int n,k;
int c[100010][52];
int C(int n,int m)
{
	if(c[n][m]) return c[n][m]; 
	return c[n][m]=(C(n-1,m-1)%M+C(n-1,m)%M)%M;;
}
int q[100010];
long long ans=0;
int main ()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&q[i]);
	for(int i=0;i<=n;i++)
		c[i][i]=c[0][i]=c[i][0]=1;
	sort(q+1,q+n+1);
	for(int i=k;i<=n;i++)
	{
		ans+=(C(i-1,k-1)*q[i]);
		ans%=M;
	}
	cout<<ans;
	return 0;
}
