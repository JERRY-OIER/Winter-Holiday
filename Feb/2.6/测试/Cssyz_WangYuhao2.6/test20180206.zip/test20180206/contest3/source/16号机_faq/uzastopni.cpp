#include<cstdlib>
#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n;
int a[10001];
int ans=0;
int k=1;
int main ()
{
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	sort(a+1,a+n+1);
	for(int i=2;i<=n+1;i++)
	{
		if(a[i]-a[i-1]==1) k++;
		else 
		{
			ans+=(k*(k-1)/2);
			k=1;
		}
	}
	cout<<ans;
	return 0;
}
