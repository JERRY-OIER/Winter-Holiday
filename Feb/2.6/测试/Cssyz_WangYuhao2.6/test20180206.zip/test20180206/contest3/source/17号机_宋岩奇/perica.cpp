#include<cstdio>
#include<algorithm>
#define maxn 100010
#define inf 1000000007
using namespace std;
long long a[maxn],mx,c[maxn][51];
int n,k;
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	sort(a+1,a+n+1);
	c[0][0]=c[1][0]=c[1][1]=1;
	for(int j=0;j<=k;j++)
	    for(int i=1;i<=n;i++)
	    {
	    	if(j==0) c[i][j]=c[i-1][j];
	    	else c[i][j]=(c[i-1][j-1]+c[i-1][j])%inf;
	    }
	for(int i=1;i<=n;i++) mx=(mx+a[i]*c[i-1][k-1])%inf;
	printf("%lld",mx);
	return 0;
}
