#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,maxa,cnt,c,b,res;
int ans[505][505],a[100101],fir[101010],nxt[101010],to[101010],t[202020];
bool di[505],d[101010];
void add(int x,int y)
{
	nxt[++cnt]=fir[x];
	fir[x]=cnt;
	to[cnt]=y;
} 
void dfs(int x)
{	
	if(d[x]) 
		return ;
	d[x]=1;
	t[++cnt]=x;
	for(int i=fir[x];i;i=nxt[i])
	{
		dfs(to[i]);
		t[++cnt]=x;
	}
}
	
int main()
{
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		maxa=max(a[i],maxa);
	}
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d%d",&c,&b);
		add(c,b);
		add(b,c);
	}
	dfs(1);
	for(int i=1;i<=cnt;i++)
	{
		int mia=0x3f3f3f3f,maa=-0x3f3f3f3f,zs=0,f=0;
		memset(di,0,sizeof(di));
	 	for(int j=i;j<=cnt;j++)
	 	{
	 		if(t[j]==1)
	 			f=1;
	 		mia=min(mia,a[t[j]]);
	 		maa=max(maa,a[t[j]]);
	 		if(!di[t[j]]) di[t[j]]=1,zs++;
	 		if(f&&maa-mia+1==zs)
	 			ans[mia][zs]=1;
	 	}
	}
	for(int i=1;i<=maxa;i++)
		for(int j=1;j<=maxa;j++)
		 if(ans[i][j]) res++;
	printf("%d\n",res);
	return 0;
}
	 	
