#include<iostream>
#include<cstdio>
#include<algorithm>
#define maxn 1000006
using namespace std;
typedef long long ll;
ll n;
ll k;
int ans[maxn];
int book[maxn];
int main()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	if(k>(ll)((n-2)*(n-1)/2))
	{
		cout<<"-1"<<endl;
		return 0;
	}
	if(n==2)
	{
		printf("2 1\n");
		return 0;
	}
	if(n==1)
	{
		printf("1\n");
		return 0;
	}
	if(k==0)
	{
		for(int i=1;i<=n;i++)  printf("%d ",i);
		printf("\n");
		return 0;
	}
	ans[n]=n;
	int pos=0;
	int max_;
	int work;
	for(ll i=1;i<=n-2;i++)
	{
		if(k>=((i+1)*i)/2&&k<=((2*n-3-i))*i/2)
		{
			pos=n-i-1;
			max_=(2*n-3-i)*i/2;
			work=i;
			break;
		}
	}
	ans[pos]=n-1;
	for(int i=pos+1;i<=n-1;i++)	
	{
		ans[i]=i-pos;
	}
	int add=(max_-k)/work;
	for(int i=pos+1;i<=n-1;i++)
	{
		ans[i]+=add;
	}
	int yu=(max_-k)%work;
	for(int i=n-1;i>=n-yu;i--)
	{
		ans[i]+=1;
	}
	for(int i=pos;i<=n;i++)   book[ans[i]]=1;
	int point=1;
	for(int i=1;i<=n;i++)
	{
		if(book[i]==0)
		{
			ans[point]=i;
			point++;
		}
	}
	for(int i=1;i<=n;i++) 	printf("%d ",ans[i]);
	printf("\n");
	return 0;
}
