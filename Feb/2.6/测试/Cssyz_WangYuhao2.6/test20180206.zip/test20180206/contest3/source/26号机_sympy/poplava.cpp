#include<cstdlib>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<cmath>
#include<iostream>
#include<iomanip>
using namespace std;
int n,x;
int a[1000005],sum[1000005];
int main()
{

    freopen("poplava.in","r",stdin);
    freopen("poplava.out","w",stdout);
	scanf("%d%d",&n,&x);
	if(x==0)
	for(int i=1;i<=n;i++)  printf("%d ",i);	
	int k=n;
	for(int i=2;i<n;i++)
	{
	 sum[i+1]+=sum[i]+i-1;
	}
	if(n%2==1) 
	{
	  for(int i=1;i<=n;i++)
	  {
		if(i<=n/2) {a[i]=k; k=k-2;}
		else       {k=k+2; a[i]=k;}
		if(i==n/2+1) {a[i]=1; k=0;}
	  }
	} 
	else
	{
		for(int i=1;i<=n;i++)
	  {
		if(i<=n/2) {a[i]=k; k=k-2;}
		else       {k=k+2; a[i]=k;}
		if(i==n/2+1) {a[i]=1; k=1;}
	  }
	}
	if(sum[n]<x)  printf("-1");
	else if(sum[n]==x)
	{
		for(int i=1;i<=n;i++)
			printf("%d ",a[i]);
	}
	else 
	{
		for(int i=n;i>2;i--)
		{    
			if(sum[i]>=x && sum[i-1]<x)
			{  
				int t=sum[i]-x,k=i+1; 
				for(int j=i;j<n;j++)  {printf("%d ",k); k++;}
	            int j=i-2,m=1;
	            while(m<=t)
	            {
	            	printf("%d ",j); j--; m++;
	            }
	            printf("%d ",i);
	            m=i-t-3;
	            while(m>=0)
	            {
	            	printf("%d ",j);j--; m--;
	            }
	            printf("%d ",i-1);
			     break;
			}
		}
		
	}
	return 0;
}
