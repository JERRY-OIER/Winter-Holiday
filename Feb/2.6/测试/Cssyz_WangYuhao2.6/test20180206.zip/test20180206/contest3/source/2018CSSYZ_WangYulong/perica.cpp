#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
long long a[100005];
long long cx_k_1[100005];
long long MOD = 1000000007;

bool cmp(long long x, long long y) {
	return x > y;
}

int main() {
	freopen("perica.in", "r", stdin);
	freopen("perica.out", "w", stdout);
	int n, k;
	scanf("%d%d", &n, &k);
	cx_k_1[k - 1] = 1;
	for (int i = k; i < n; ++i) {
		cx_k_1[i] = cx_k_1[i - 1] * i / (i - k + 1);
		cx_k_1[i] %= MOD;
		//cout << cx_k_1[i] << endl;
	}
	
	
	for (int i = 1; i <= n; ++i) {
		scanf("%lld", &a[i]);
	}
	sort(a + 1, a + 1 + n, cmp);
	
	/*for (int i = 1; i <= n; ++i) {
		printf("%lld %lld\n", cx_k_1[i], a[i]);
	}*/
	
	long long ans = 0;
	for (int i = 1; i <= n - k + 1; ++i) {
		ans += (cx_k_1[n - i] * a[i]) % MOD;
	//printf("%lld\n", ans);
		ans %= MOD;
	}
	printf("%lld", ans);
	return 0;
}
