#include <iostream>
#include <cstdio>
using namespace std;
const int N=100001;
int n; long long ans,x;  long long mmax[N];
void work()
{
	int i,p;  long long need;
	for (i=3;i<=n;i++)
		mmax[i]=(i-1)*(i-2)/2;
	if (x>mmax[n])
		printf("-1\n");
	else
	{
		if (mmax[n]==x)
		{
			printf("%d",n);
			for (i=1;i<n;i++)
				printf(" %d",i);
		}
		else
		{
			for (i=1;i<=n;i++)
				if (mmax[i]>x)
				{
					p=i-1;
					break;
				}
			need=x-mmax[p];
			for (i=p+2;i<=n;i++)
				printf("%d ",i);
			printf("%d",p);
			for (i=1;i<=need;i++)
				printf(" %d",i);
			printf(" %d",p+1);
			for (i=need+1;i<p;i++)
				printf(" %d",i);
		}
		printf("\n");
	}
	return;
}
int main()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%d%I64d",&n,&x);
	work();
	return 0;
}
