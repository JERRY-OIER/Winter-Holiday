#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;
int n, num[10001], fir[20001], next[10001], to[10001], ans, maxx, minn = 100000007, jsq, cnt;
queue<int>q;
bool used[10001];

void add(int u, int v) {
	next[++cnt] = fir[u];
	fir[u] = cnt;
	to[cnt] = v;
}

void dfs(int x, int from) {
	used[x] = 1;
	q.push(num[x]);
	jsq++;
	maxx = max(num[x], maxx);
	minn = min(minn, num[x]);
	if (maxx - minn + 1 == jsq) {
		ans++;
	}
	
	for (int i = fir[x]; i != 0; i = next[i]) {
		if (!used[to[i]]) dfs(to[i], x);
	}
}

int main(){
	freopen ("uzastopni.in", "r", stdin);
	freopen ("uzastopni.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf ("%d", &num[i]);
	}
	for (int i = 1; i < n; i++) {
		int u, v;
		scanf ("%d%d", &u, &v);
		add(u, v);
		add(v, u);
	}
	dfs(1, 0);
	cout<<ans<<endl;
	return 0;
}
