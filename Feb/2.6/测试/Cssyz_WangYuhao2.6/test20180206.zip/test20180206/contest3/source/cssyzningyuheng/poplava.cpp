#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
#include<set>
using namespace std;
long long n,x,i,j,k,l,ans,max1,a[1000002],head,tail;
int main(){
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%lld%lld",&n,&x);
	max1=(n-1)*(n-2)/2;head=0;tail=n;a[n]=n;
	if(x>max1)
		printf("-1\n");
	else{
		for(i=1;i<=n-2;i++)
			if(max1-(n-1-i)<x){
				tail--;
				a[tail]=i;
			}
			else{
				head++;
				max1-=(n-1-i);
				a[head]=i;
			}
		a[head+1]=n-1;
		for(i=1;i<=n;i++)
			printf("%lld ",a[i]);
		printf("\n");
	}
	return 0;
}
