#include<cstdlib>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<cmath>
#include<iostream>
#include<iomanip>
using namespace std;
int cmp(int x,int y) {return x>y;}
int n,k;
int c[100005][55],b[100005],a[100005];
long long sum=0;
int main()
{
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdou);
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++) c[i][0]=1;
    c[1][1]=1;
    for(int i=1;i<=n;i++)
     for(int j=1;j<=k;j++)
     {
     	if(i==1 && j==1)  continue;
        c[i][j]=c[i-1][j-1]+c[i-1][j];
     }
    for(int i=1;i<=n;i++)
    {
     scanf("%d",&b[i]);a[b[i]]++;
    }
    sort(b+1,b+n+1,cmp);
    int m=n,u=c[n][k],i=1;
    while(m>0 && i<=n)
    {
    	if(b[i]<b[i-1] || i==1)
    	{ 
		  m-=a[b[i]];
		  u-=c[m][k]; 
    	  sum+=b[i]*u; 
    	  u=c[m][k];
    	  sum=sum%1000000007;
        }
        i++;
    }
    printf("%I64d",sum);
    return 0;
}
