#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<iomanip>
#define maxn 1000010
using namespace std;
long long n,m,x,a[maxn];
void dfs(int t)
{
	if(t>m-x) return;
	if(t==m-x)
	{
		for(int i=1;i<n;i++) if(a[i]==1) cout<<i<<" ";
		cout<<n<<" ";
		for(int i=1;i<n;i++) if(a[i]==0) cout<<i<<" ";
		exit(0);
	}
	for(int i=n-2;i>=1;i--)
	    if(a[i]==0)
	    {
	    	if(t+(n-1-i)>m-x) break;
	    	if((n-1-i+n-2)*i/2+t<m-x) break;
		    a[i]=1;
	    	dfs(t+(n-1-i));
	    	a[i]=0;
	    }
}
int main()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	cin>>n>>x;
	if(n==1 || n==2) cout<<"-1";
	else
	{
		m=(n-1)*(n-2)/2;
		if(x>m) cout<<"-1";
		else if(x==m)
		{
			cout<<n<<" ";
		    for(int i=1;i<n;i++) cout<<i<<" ";
		}
		else dfs(0);
	}
	return 0;
}
