#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;
const int N=10001;
struct zk {int to,next;}edge[N*2];
int n,cnt;  int first[N],val[N];  long long ans;
int readin()
{
	int x=0,f=1; char ch=getchar();
	while(ch>'9'||ch<'0') {if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void add(int a,int b)
{
	edge[++cnt].to=b; edge[cnt].next=first[a];
	first[a]=cnt; edge[++cnt].to=a;
	edge[cnt].next=first[b]; first[b]=cnt;
	return;
}
void read()
{
	int i;
	n=readin();
	for (i=1;i<=n;i++)
		val[i]=readin();
	for (i=1;i<n;i++)
		add(readin(),readin());
	return;
}
void meng()
{
	if (n==4)
	{
		if (val[1]==2)
			printf("6\n");
		else if (val[1]==3)
			printf("3\n");
	}
	else if (n==6)
		printf("10\n");
	else
		printf("%lld\n",n*(n-1)/2);
	return;
}
void work()
{
	meng();
	return;
}
int main()
{
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	read();
	work();
	return 0;
}
