#include<cstdio>
#include<algorithm>
#include<cstring>
#define mod 1000000007
#define max(a,b) (a>b?a:b)
using namespace std;
int n,k,a[100010],ans;
int memo[100010][55];
int reunion(int x,int y){
	if(x<0 || y<0) return 0;
	if(x==1 && (y==1 || !y)) return 1;
	if(!x && !y) return 1;
	if(memo[x][y]!=-1) return memo[x][y];
	memo[x][y]=((reunion(x-1,y-1)%mod)+(reunion(x-1,y)%mod))%mod;
	return memo[x][y];
}
int main(){
	freopen("perica.in","r",stdin);
	freopen("perica.out","w",stdout);
	memset(memo,-1,sizeof(memo));
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	reunion(n/2,k);
	for(int i=n;i>=k;i--){
		ans=(ans+reunion(i-1,k-1)*(a[i]%mod))%mod;
		
	} 
	printf("%d\n",ans);
	return 0;
}
