#include<cstdio>
int n,x,js,cnt,sum,c;
int book[100005],a[100005];
int main()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%d%d",&n,&x);
	sum=(1+n-2)*(n-2)/2;
	if (x>sum) 
	{
		printf("-1\n");
		return 0;
	}
	c=sum-x;
	if (x==0)
	{
		for (int i=1;i<=n;i++)
			printf("%d ",i);		
		printf("\n");
	}
	for (int i=n-2;i>=1;i--)
	{
		cnt+=i;
		a[++js]=(n-2)-i+1;
		book[(n-2)-i+1]=1;
		if (cnt>c) cnt-=i,js--,book[(n-2)-i+1]=0;
		else if (cnt==c) break;
	}
	for (int i=n-1;i>=1;i--)
		if (book[i]!=1) printf("%d ",i);
	printf("%d ",n);
	for (int i=1;i<=js;i++)
		printf("%d ",a[i]);
	printf("\n");
	return 0;
}
