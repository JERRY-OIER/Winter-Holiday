#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<iomanip>
#include<ctime>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
#include<sstream>
#include<set>
#include<vector>
#include<queue>
using namespace std;
int  f[1010][1010];
int  p[1010];
bool k[1010];
int ans=0,n,minnn,maxxx;
void fight_without_a_word(int now,int minn,int maxx)
{
	for(int i=minn;i<=maxx;i++)
		{
			if(k[i]==0)	break;
			if(i==maxx)	ans++;
		}
	
	for(int j=1;j<=f[now][0];j++)
		{
			int i=f[now][j];
			
			minnn=minn;
			maxxx=maxx;
			
			if(p[i]<minn)	minnn=p[i];
			if(p[i]>maxx)	maxxx=p[i];
			
			k[p[i]]=1;
			fight_without_a_word(i,minnn,maxxx);
			k[p[i]]=0;
		}
}

int main()
{
	freopen("uzastopni.in","r",stdin);
	freopen("uzastopni.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		{f[i][0]=0;k[i]=0;}
	int a,b;
	for(int i=1;i<=n;i++)
		cin>>p[i];
	for(int i=1;i<=n-1;i++)
		{
			cin>>a>>b;
			f[a][0]++;
			f[a][f[a][0]]=b;
		}
	k[p[1]]=1;
	fight_without_a_word(1,p[1],p[1]);
	cout<<ans;
	return 0;
}

