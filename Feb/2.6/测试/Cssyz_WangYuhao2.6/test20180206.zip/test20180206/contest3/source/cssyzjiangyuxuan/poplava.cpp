#include<iostream>
#include<cstdio>
using namespace std;
long long n,m,k,l;
int main()
{
	freopen("poplava.in","r",stdin);
	freopen("poplava.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	if(m>(long long)(n-1)*(n-2)/2)
	{
		printf("-1\n");
		return 0;
	}
	int i;
	k=(n-1)*(n-2)/2;
	for(l=n-2;k>m;k-=l,l--);
	l++;
	printf("%lld ",l);
	for(i=2;i<l-m+k+1;i++)
		printf("%d ",i-1);
	printf("%lld ",l+1);
	for(i+=1;i<=l+1;i++)
		printf("%d ",i-2);
	for(;i<n;i++)
	printf("%d ",i);
	printf("%d\n",i);
	return 0;
}
	
