#include <bits/stdc++.h>

#define ll long long
#define hhw N + 2 - 2 * i
#define xxw 2 * i - N - 1

using namespace std;

int N, n;

int ans[2000005];

ll x, tot, maxn;

int find(ll);

void init();

void work();

void change(int);

void cg(ll);

int main() {
    freopen("poplava.in", "r", stdin);
    freopen("poplava.out", "w", stdout);
    scanf("%d%lld", &N, &x);
    n = N;
    maxn = (ll)(n - 1) * (n - 2) / 2;
    if(x > maxn) {
	printf("-1\n");	return 0;
    }
    work();
    for(int i = 1; i <= N; i++)
	if(ans[i] == 0) continue;
	else printf("%d ", ans[i]);
    for(int i = n; i > N; i--)
	if(ans[i] == 0) continue;
	else printf("%d ", ans[i]);
    printf("\n");
    return 0;
}

int find(ll cha) {
    if(N % 2) {
	if(cha % 2) {
	    int loca = N / 2 + 1;
	    return loca - (N - 2 - cha) / 2;
	} else {
	    int loca = N / 2 + 2;
	    return loca + (N - 3 - cha) / 2;
	}
    } else {
	if(cha % 2) {
	    int loca = N / 2;
	    return loca - (N - 3 - cha) / 2;
	} else {
	    int loca = N / 2 + 1;
	    return loca + (N - 2 - cha) / 2;
	}
    }
}

void init() {
    for(int i = 1; i <= N; i++) {
	if(hhw > 0)
	    ans[i] = hhw;
	else
	    break;
    } for(int i = N; i >= 1; i--) {
	if(xxw > 0)
	    ans[i] = xxw;
	else
	    break;
    }
    return;
}

void change(int i) {
    ans[++n] = ans[i];
    ans[i] = 0;
}

void work() {
    init();
    if(maxn == x)
	return;
    ll cha = maxn - x;
    cg(cha);
    return;
}

void cg(ll cha) {
    int MAX = n - 2;
    while(cha > 0) {
	if(cha <= MAX) {
	    change(find(cha));
	    return;
	}
	cha -= MAX;
	change(find(MAX));
	MAX--;
    }
}
