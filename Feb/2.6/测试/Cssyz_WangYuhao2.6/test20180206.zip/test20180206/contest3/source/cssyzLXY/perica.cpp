#include <bits/stdc++.h>

using namespace std;
const int MAXN = 100000;
const int MOD = 1000000007;
const int MAXK = 50;
const int N50 = 1000;

int n;
int K;
long long ans;
int a[MAXN + 1];
int f[MAXK + 1][N50 + 1][N50 + 1];

void DFS(int, int, int);

int main() {
	freopen("perica.in", "r", stdin);
	freopen("perica.out", "w", stdout);
	scanf("%d%d", &n, &K);
	for (int i= 1; i <= n; i++) scanf("%d", &a[i]);
	DFS(0, 0, 0);
	printf("%lld\n", ans);
	return 0;
}

void DFS(int t, int lastC, int maxN) {
	if (t == K) {
		ans = (ans + a[maxN]) % MOD;
		return ;
	}
	if (f[t][lastC][maxN]) {
		ans = (ans + f[t][lastC][maxN]) % MOD;
		return ;
	}
	long long oldAns = ans;
	for (int i = lastC + 1; i <= n; i++) {
		DFS(t + 1, i, (a[i] > a[maxN]) ? i : maxN);
	}
	f[t][lastC][maxN] = (ans + MOD - oldAns) % MOD;
}
