#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
const int N=100001;
const int K=51;
const int P=1000000007ll;
int n,k;  int a[N];  long long ans,c[N][K];
int readin()
{
	int x=0,f=1; char ch=getchar();
	while(ch>'9'||ch<'0') {if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void read()
{
	int i,j;
	n=readin(); k=readin()-1;
	for (i=1;i<=n;i++)
		a[i]=readin();
	sort(a+1,a+1+n);
	c[0][0]=1; c[1][0]=1; c[1][1]=1;
	for (i=2;i<=n;i++)
	{
		c[i][0]=1;
		for (j=1;j<=k;j++)
			c[i][j]=(c[i-1][j-1]+c[i-1][j])%P;
	}
	return;
}
void work()
{
	int i;
	for (i=k+1;i<=n;i++)
		ans=(ans+c[i-1][k]*(long long)a[i])%P;
	printf("%I64d\n",ans);
	return;
}
int main()
{
    freopen("perica.in","r",stdin);
    freopen("perica.out","w",stdout);
	read();
	work();
	return 0;
}
