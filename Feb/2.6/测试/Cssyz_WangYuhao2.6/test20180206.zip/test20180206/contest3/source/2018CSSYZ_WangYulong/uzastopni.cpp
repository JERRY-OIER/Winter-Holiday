#include <iostream>
#include <cstdio>
using namespace std;
int n;

int a[10004];

int head[10004], nxt[20004], to[20004], cnt;

void add(int f, int t) {
	nxt[++cnt] = head[f];
	head[f] = cnt;
	to[cnt] = t;
	return ;
}

int b[10004][102], v[10004];

void dfs(int u) {
	for (int i = head[u]; i != 0; i = nxt[i]) {
		if (!v[to[i]]) {
			v[to[i]] = 1;
			dfs(to[i]);
			for (int j = 1; j <= 100; ++j) {
				if (b[to[i]][j] >= 1)
					b[u][j] = 1;
			}
		}
	}
	
	int bb = 1;
	for (int i = 1; a[u] - i >= 1; ++i) {
		if (!b[u][a[u] - i]) {
			bb = 0;
		}
		b[u][a[u] - i] = bb;
	}
	bb = 1;
	for (int i = 1; a[u] + i <= 100; ++i) {
		if (!b[u][a[u] + i]) {
			bb = 0;
		}
		b[u][a[u] + i] = bb;
	}
	
	
	
	return ;
}

int main() {
	freopen("uzastopni.in", "r", stdin);
	freopen("uzastopni.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		scanf ("%d", &a[i]);
		b[i][a[i]] = 1;
	}
	for (int i = 1; i <= n - 1; ++i) {
		int x, y;
		scanf("%d%d", &x, &y);
		add(x, y);
		add(y, x);
	}
	
	
	/*for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= 6; ++j) {
			cout << b[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;*/
	
	v[1] = 1;
	dfs(1);
	
	int x, y;
	
	
	/*for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= 6; ++j) {
			cout << b[i][j] << " ";
		}
		cout << endl;
	}*/
	
	
	for (int i = 1; ; ++i) {
		if (!b[1][a[1] - i + 1]) {
			x = i - 1;
			break;
		}
	}
	for (int i = 1; ; ++i) {
		if (!b[1][a[1] + i - 1]) {
			y = i - 1;
			break;
		}
	}
	printf("%d", x * y);

	return 0;
}
