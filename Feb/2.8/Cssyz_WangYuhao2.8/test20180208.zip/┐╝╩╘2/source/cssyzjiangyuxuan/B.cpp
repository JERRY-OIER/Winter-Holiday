#include<iostream>
#include<cstdio>
using namespace std;
int n,ans[1010101];
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int j=2,k=i;
		while(j<=n)
		{
			if(k%j==1)
				k=(k-1+j)<=n?(k-1+j):n,j++;
			else 
			{
				for(int l=(k-1)/j;l>=0;l--)
				{
					int t=(k-l*j-1)/(l+1);
					if(j+t>n) break;
					if((k-l*j-1)-t*(l+1)==0)
					{
						j+=t;k=j*l+1;
						break;
					}
				}
				if(k%j==1)
					k=(k-1+j)<=n?(k-1+j):n,j++;
				else 
				{
					k-=n-j+1;
					j=n+1;
				}
			}
		}
		ans[k]=i;
	}
	for(int i=1;i<=n;i++)
	 printf("%d ",ans[i]);
	 printf("\n");
	return 0;
}		
			
