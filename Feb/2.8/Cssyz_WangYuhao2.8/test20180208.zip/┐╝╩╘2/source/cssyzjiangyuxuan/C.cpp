#include<iostream>
#include<cstdio>
using namespace std;
int n,k,a[100100],d[101010],ans;
int main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	int f=1,t=0;
	for(int i=1;i<=n;i++)
	{
		if(d[a[i]])
			ans=max(ans,++d[a[i]]);
		else 
		{
			if(t<=k)
			{
				t++;
				ans=max(ans,++d[a[i]]);
			}
			else 
			{
				do	d[a[f++]]--;
				while(d[a[f-1]]&&f<=i);
				d[a[i]]++;
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
				
			
