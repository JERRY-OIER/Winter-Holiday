#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

int n, a[1000005];

void change(int, int);
void solve(int);

int main() {
    freopen("B.in", "r", stdin);
    freopen("B.out", "w", stdout);
    scanf("%d", &n);
    solve(n);
    return 0;
}

void change(int l, int r) {
    //printf("%d--%d\n", l, r);
    if(l >= r)
	return;
    int hhw = a[l];
    for(int i = l; i < r; i++)
	a[i] = a[i + 1];
    a[r] = hhw;
    return;
}

void solve(int N) {
    //printf("%d:\n", N);
    for(int i = 1; i <= N; i++)
	a[i] = i;
    for(int i = 1; i <= N; i++)
	for(int j = i; j <= N + i; j += i) {
	    if(j - i > N) {
		break;
	    } else {
		change(j - i + 1, min(j, N));
		if(j == N)
		    break;
	    }
	}
    for(int i = 1; i <= N; i++) {
	printf("%d ", a[i]);
    }
    printf("\n");
    return;
}
