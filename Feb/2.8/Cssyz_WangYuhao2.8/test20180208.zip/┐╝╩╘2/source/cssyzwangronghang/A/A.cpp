#include <cstdio>

#define ll long long

using namespace std;

int N, ans, x_x;

int a[1000005];

ll tot[1000005], l[1000005], r[1000005];

int main() {
    freopen("A.in", "r", stdin);
    freopen("A.out", "w", stdout);

    scanf("%d", &N);

    for(int i = 1; i <= N; i++)
	scanf("%d", &a[i]);

    for(int i = 1; i <= N; i++)
	tot[i] = tot[i - 1] + a[i];

    x_x = (int)tot[N] / N;

    for(int i = 1; i <= N; i++)
	l[i] = tot[i - 1] - x_x * (i - 1);

    ans = N - 1;

    for(int i = 2; i <= N; i++)
	if(l[i] == 0)
	    ans--;

    printf("%d\n", ans);

    return 0;
}
