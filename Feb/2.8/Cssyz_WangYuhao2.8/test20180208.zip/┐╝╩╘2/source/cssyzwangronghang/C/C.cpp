#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>

using namespace std;

int n, k, a[100005], b[100005], ans, xxw[100005];

bool hhw[100005];

bool cmp(int a, int b) {return a > b;};

int work(int);

int main() {
    freopen("C.in", "r", stdin);
    freopen("C.out", "w", stdout);
    scanf("%d%d", &n, &k);
    for(int i = 1; i <= n; i++) {
	scanf("%d", &a[i]);
	xxw[a[i]]++;
	hhw[a[i]] = true;
    }
    if(k == 1) {
	for(int i = 1; i <= n; i++) {
	    if(hhw[i] == false)
		continue;
	    ans = max(ans, work(i));
	}
	printf("%d\n", ans);
    } else {
	sort(xxw + 1, xxw + n + 1, cmp);
	printf("%d\n", xxw[1]);
    }
    return 0;
}
    
int work(int i) {
    memset(b, 0, sizeof(b));
    int j = 0, k = 0;
    while(a[++j]) {
	if(a[j] != i)
	    b[++k] = a[j];
    }
    int tot = 0, tt = 0;
    for(j = 1; j <= k; j++) {
	if(b[j] != b[j - 1]) {
	    tot = max(tot, tt);
	    tt = 0;
	}
	tt++;
    }
    return tot;
}
