#include <vector>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <bitset>
#include <complex>
#include <string>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
using namespace std;
int  f[2000100];
int t;
int goal;
int n;
int tot;
int main()
{    
     freopen("B.in","r",stdin);
     freopen("B.out","w",stdout);
	//int n=1000000;

	int x,y;
	scanf("%d",&n);int i;
	for(i=1;i<=n;i++)f[i]=i;
	for(i=2;i<=n;i++)
	{
		y=n+i-1;
		x=(n-1)/i*i+i-1;
		while(x>0)f[y]=f[x],y=x,x-=i;
	}
	for(i=n;i<2*n;i++)printf("%d ",f[i]);
	return 0;
	
}
