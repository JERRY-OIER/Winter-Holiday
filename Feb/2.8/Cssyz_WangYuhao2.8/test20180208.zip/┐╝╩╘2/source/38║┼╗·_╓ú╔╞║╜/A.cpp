#include <iostream>
#include <cstdio>
using namespace std;
int  a[1000010];
int  t=0;
long long  goal;
int n;
long long  tot;
int main()
{    
     freopen("A.in","r",stdin);
     freopen("A.out","w",stdout);
	//int n=1000000;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
{
	 scanf("%d",&a[i]);
	 tot+=a[i];
}
	goal=tot/n;
	//for(int i=1;i<=n;i++) a[i]-=goal;
  // sort(a+1,a+n+1);
  //for(int i=1;i<=n;i++) a[i]-=goal;
   for(int i=1;i<=n;i++)
   {
   	 if(a[i]!=goal)
   	 {
   	 	a[i+1]+=(a[i]-goal);
   	 	t++;
   	 }
   }
  cout<<t;
  return 0;
}
