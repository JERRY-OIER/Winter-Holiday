#include <vector>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <bitset>
#include <complex>
#include <string>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
using namespace std;
int  a[1000000];
int  b[1000000];
int d[1000000];
int top=0;
int t;
int goal;
int n;
int m;
int ans;
int tot;
int main()
{    
     freopen("C.in","r",stdin);
     freopen("C.out","w",stdout);
	//int n=1000000;
    scanf("%d",&n);
    scanf("%d",&m);
    int l=1,r=1;
    for(int i=1;i<=n;i++)
    {
    	scanf("%d",&a[i]);
        d[r]=a[i];
        b[a[i]]++;
        
         if(b[a[i]]==1) t++;
        if(t>m+1)
        {
        	while(t>m+1&&l<=r)
        	{
        		b[d[l]]--;
        		//if(b[d[l]]>ans) ans=b[d[l]];
        		if(b[d[l]]==0)
        		t--;
        		l++;
        	}
        }
        r++;
        if(b[a[i]]>ans) ans=b[a[i]];
    }
    //sort(c+1,c+top+1);
    //dfs(0,n);
    printf("%d",ans);
}
