#include<cstdio>
#include<cstdlib>
#include<iomanip>
#include<iostream>
#include<cstring>
#include<string>
#include<ctime>
#include<cmath>
#include<algorithm>
using namespace std;
struct tree
{
	int size,son,fa,deep;
	tree():size(0),son(0),fa(0),deep(0){}
}a[40001];
int n;
struct load
{
	int l,r,v;
}l[40001];
struct xianduan
{
	int v,maxx,minn,l,r;
	bool fan;
}xian[2000001];
int first[40001];
int next[40001];
int seq[40001];
int pos[40001];
int top[40001];
int point[40001];
bool pd[40001]; 
int zhi[40001];
void dfs1(int x)
{
	a[x].deep=a[a[x].fa].deep+1;
	a[x].size=1;
	int o=first[x];
	while(o!=0)
	{
		if(!pd[o])
		{
			if(l[o].r!=a[x].fa)
			{
				if(o>n-1) pd[o-n+1]=true;
	    	 	else pd[o+n-1]=true;
				a[l[o].r].fa=x;
				dfs1(l[o].r);
				a[x].size+=a[l[o].r].size;
			}
			if(a[l[o].r].size>a[a[x].son].size) a[x].son=l[o].r;
		}
		o=next[o];
	}
}
int t;
void dfs2(int x)
{
	pos[x]=++t;
	seq[pos[x]]=x;
	if(a[a[x].fa].son==x) top[x]=top[a[x].fa];
	else top[x]=x;
	if(a[x].son) dfs2(a[x].son);
	for(int i=first[x];i;i=next[i])
	{
		if(a[x].son!=l[i].r && l[i].r!=a[x].fa && !pd[i]) dfs2(l[i].r);
	}
}
void maketree(int b,int l,int r)
{
	xian[b].l=l;
	xian[b].r=r;
	xian[b].fan=false;
	if(l==r) 
	{
		xian[b].maxx=xian[b].minn=zhi[l];
		xian[b].v=zhi[l];
		return;
	}
	int mid=((l+r)>>1);
	maketree(2*b,l,mid);
	maketree(2*b+1,mid+1,r);
	xian[b].v=xian[2*b].v+xian[2*b+1].v;
	xian[b].maxx=max(xian[2*b].maxx,xian[2*b+1].maxx);
	xian[b].minn=min(xian[2*b].minn,xian[2*b+1].minn);
}
void update(int b)
{
	xian[b].v=xian[2*b].v+xian[2*b+1].v;
	xian[b].maxx=max(xian[2*b].maxx,xian[2*b+1].maxx);
	xian[b].minn=min(xian[2*b].minn,xian[2*b+1].minn);
}
void push_down(int b)
{
	if(xian[b].fan)
	{
		xian[b].fan=false;
		swap(xian[b].maxx,xian[b].minn);
		xian[b].maxx=xian[b].maxx*(-1);
		xian[b].minn=xian[b].minn*(-1);
		xian[b].v=xian[b].v*(-1);
		xian[2*b].fan=!xian[2*b].fan;
		xian[2*b+1].fan=!xian[2*b+1].fan;
	}
}
void xian_searchmax(int l1,int r1,int b,int &ans1)
{
	int ll=xian[b].l;
	int rr=xian[b].r;
	push_down(2*b);
	push_down(2*b+1);
	if(l1>rr || r1<ll) return;
	if(ll>=l1 && rr<=r1) {ans1=max(ans1,xian[b].maxx);return;} 
	xian_searchmax(l1,r1,2*b,ans1);
	xian_searchmax(l1,r1,2*b+1,ans1);
	update(b);
}
void xian_searchmin(int l1,int r1,int b,int &ans1)
{
	int ll=xian[b].l;
	int rr=xian[b].r;
	push_down(2*b);
	push_down(2*b+1);
	update(b);
	if(l1>rr || r1<ll) return;
	if(ll>=l1 && rr<=r1) {ans1=min(ans1,xian[b].minn);return;} 
	xian_searchmin(l1,r1,2*b,ans1);
	xian_searchmin(l1,r1,2*b+1,ans1);
	
}
void xian_searchv(int l1,int r1,int b,int &ans1)
{
	int ll=xian[b].l;
	int rr=xian[b].r;
	push_down(2*b);
	push_down(2*b+1);
	update(b);
	if(l1>rr || r1<ll) return;
	if(ll>=l1 && rr<=r1) {ans1+=xian[b].v;return;} 
	xian_searchv(l1,r1,2*b,ans1);
	xian_searchv(l1,r1,2*b+1,ans1);
}
void xian_changev(int v,int z,int b)
{
	int ll=xian[b].l;
	int rr=xian[b].r;
	push_down(2*b);
	push_down(2*b+1);
	update(b);
	if(z>rr || z<ll) return;
	if(ll==rr)
	{
		xian[b].maxx=v;
		xian[b].minn=v;
		xian[b].v=v;
		return;
	}
	xian_changev(v,z,2*b);
	xian_changev(v,z,2*b+1);
}
void xian_changeo(int l1,int r1,int b)
{
	int ll=xian[b].l;
	int rr=xian[b].r;
	push_down(2*b);
	push_down(2*b+1);
	if(l1>rr || r1<ll) return;
	if(ll>=l1 && rr<=r1) {xian[b].fan=true;push_down(b);return;} 
	xian_changeo(l1,r1,2*b);
	xian_changeo(l1,r1,2*b+1);
	update(b);
}
void main_changeo(int x,int y)
{
	int fx=top[x],fy=top[y];
	while(fx!=fy)
	{
		if(a[fx].deep<a[fy].deep) {swap(x,y);swap(fx,fy);}
		x=a[fx].fa;fx=top[x];
	}
	if(x==y) return;
	if(a[x].deep<a[y].deep) swap(x,y);
	xian_changeo(pos[a[y].son],pos[x],1);
}
int find_ans(int x,int y,int pd)
{
	int fx=top[x],fy=top[y];
	int trueans;
	if(pd==1) trueans=-2147483647;
	else if(pd==2) trueans=2147483647;
	else if(pd==3) trueans=0;
	while(fx!=fy)
	{
		if(a[fx].deep<a[fy].deep) {swap(x,y);swap(fx,fy);}
		if(pd==1) 
		{
			int ans=-2147483647;
			xian_searchmax(pos[fx],pos[x],1,ans);
		    if(ans>trueans) trueans=ans;
		}
		if(pd==2)
		{
			int ans=2147483647;
			xian_searchmin(pos[fx],pos[x],1,ans);
			if(ans<trueans) trueans=ans;
		}
		if(pd==3)
		{
			int ans=0;
			xian_searchv(pos[fx],pos[x],1,ans);
			trueans+=ans;
		}
		x=a[fx].fa;fx=top[x];
	}
	if(x==y) return trueans;
	if(a[x].deep<a[y].deep) swap(x,y);
	if(pd==1) 
	{
		int ans=-2147483647;	
		xian_searchmax(pos[a[y].son],pos[x],1,ans);
	    if(ans>trueans) trueans=ans;
	}
	if(pd==2)
	{
		int ans=2147483647;
		xian_searchmin(pos[a[y].son],pos[x],1,ans);
		if(ans<trueans) trueans=ans;
	}
	if(pd==3)
	{
		int ans=0;
		xian_searchv(pos[a[y].son],pos[x],1,ans);
		trueans+=ans;
	}
	return trueans;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n-1;i++)
	{
		int ll,rr,vv;
		scanf("%d%d%d",&ll,&rr,&vv);
		ll++;
		rr++;
		l[i].l=ll;
		l[i].r=rr;
		l[i+n-1].l=rr;
		l[i+n-1].r=ll;
		l[i+n-1].v=vv;
		l[i].v=vv;
		next[n+i-1]=first[rr];
		first[rr]=n+i-1;
	    next[i]=first[ll];
	    first[ll]=i;
	}
	//a[1]=tree();
	//a[0]=tree();
	dfs1(1);
	dfs2(1);
	for(int i=1;i<n;i++)  
    {  
        int x=l[i].l;
		int y=l[i].r;  
        zhi[pos[a[x].deep>a[y].deep ? x:y]]=l[i].v;  
    } 
	maketree(1,1,n);
	int m;
	scanf("%d",&m);
	char c[10];
	int x,y;
	char b[4];
	for(int i=1;i<=m;i++)
	{
		scanf("%s",c);
		scanf("%d%d",&x,&y);
		if(c[0]=='C') 
		{
			int t=(a[l[x].l].deep>a[l[x].r].deep ? l[x].l: l[x].r);
			xian_changev(y,t,1);
	    }
		if(c[0]=='N') main_changeo(x+1,y+1);
		if(c[0]=='S') printf("%d\n",find_ans(x+1,y+1,3));
		if(c[0]=='M' && c[1]=='A') printf("%d\n",find_ans(x+1,y+1,1));
		if(c[0]=='M' && c[1]=='I') printf("%d\n",find_ans(x+1,y+1,2)); 
	}
	return 0;
}
