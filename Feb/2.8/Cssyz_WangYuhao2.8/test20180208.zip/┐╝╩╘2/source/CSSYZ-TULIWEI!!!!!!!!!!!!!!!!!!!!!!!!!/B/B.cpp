#include<iostream>
#include<cstdio>
using namespace std;
int n,a[1000005],t;
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
	for(int i = 1; i <= n; i++)
	{
		a[i] = i;
	}
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j += i)
		{
			t = a[j];
			for(int k = j; k <= j + i - 1 && k < n; k++)
			{
				a[k] = a[k+1];
			}
			if(j + i - 1 > n)
			{
				a[n] = t;
			}
			else
			{
				a[j + i - 1] = t;
			}
		}
	}
	for(int i = 1; i <= n; i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}
