#include<iostream>
#include<cstdio>
using namespace std;
int n,a[1000005],i,x,ans;
long long sum;
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%d",&n);
	for(i = 1; i <= n; i++)
	{
		scanf("%d",&a[i]);
		sum+=a[i];
	}
	x = sum / n;
	sum = 0;
	for(i = 1; i <= n; i++)
	{
		a[i] = a[i] - x;
		sum += a[i];
		if(sum == 0) ans--;
	}
	ans += n;
	printf("%d",ans);
	return 0;
}
