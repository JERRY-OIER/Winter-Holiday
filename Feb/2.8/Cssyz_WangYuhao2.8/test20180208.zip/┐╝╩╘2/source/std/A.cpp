#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
using namespace std;
const int maxn=1e6+5;long long a[maxn],sum;int n;
int main(){freopen("A.in","r",stdin);freopen("A.out","w",stdout);cin>>n;for(int i=1;i<=n;i++)scanf("%lld",&a[i]),sum+=a[i];sum/=n;int ans=0;
for(int i=1;i<=n;i++)if(a[i]!=sum)a[i+1]+=a[i]-sum,ans++;cout<<ans<<endl;}
