#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,a[1001000],ans;
long long sum;
int main()
{
    freopen("A.in","r",stdin);
    freopen("A.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;++i)
        scanf("%d",&a[i]),sum+=a[i];
    sum/=n;
    for(int i=1;i<=n;++i)
        a[i]-=sum,a[i]+=a[i-1];
    for(int i=1;i<=n;++i)
        if(a[i])ans++;
    printf("%d\n",ans);
    return 0;
}
