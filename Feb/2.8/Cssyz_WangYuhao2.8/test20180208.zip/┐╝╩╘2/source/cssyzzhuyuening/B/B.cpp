#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,head,k,tp,tn;
int a[1001000],b[1001000];
int main()
{
    freopen("B.in","r",stdin);
    freopen("B.out","w",stdout);
    scanf("%d",&n);
    head=1;
    for(int i=1;i<=n;++i)
      a[i]=i;
    for(int i=2;i<=n;++i)
    {
        for(int j=n-n%i;j;j--)
        {
            if(j%i==1)b[j+i-1]=a[j];
            else b[j-1]=a[j];
        }
        if(n%i)
        {
            for(int j=n;j>n-n%i+1;j--)
            b[j-1]=a[j];
            b[n]=a[n-n%i+1];
        }
        for(int j=1;j<=n;++j)a[j]=b[j];
    }
    for(int i=1;i<=n;++i)printf("%d ",a[i]);printf("\n");
    return 0;
}
