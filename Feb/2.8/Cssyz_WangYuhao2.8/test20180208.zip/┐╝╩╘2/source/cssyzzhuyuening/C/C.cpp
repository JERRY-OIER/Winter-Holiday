#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,a[1001000],k,ans;
int v[1001000],ed=1,cnt;
int main()
{
    freopen("C.in","r",stdin);
    freopen("C.out","w",stdout);
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;++i)scanf("%d",&a[i]);
    for(int i=1;i<=n;++i)
    {
        if(!v[a[i]])
        {
            if(cnt<=k)ans=max(ans,1),cnt++;
            else
            {
                v[a[ed]]--;ed++;
                while(ed<=i&&v[a[ed-1]])
                    v[a[ed]]--,ed++;
            }
        }
        else ans=max(ans,v[a[i]]+1);
        v[a[i]]++;
    }
    printf("%d\n",ans);
    return 0;
}
