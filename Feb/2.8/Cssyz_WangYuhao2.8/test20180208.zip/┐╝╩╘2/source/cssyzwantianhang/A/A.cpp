#include<cstdio>
#include<algorithm>
#define M 1000100
int magic[M];
int main()
{	
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	int n,ans=0;
	long long total=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&magic[i]),total+=magic[i];
	total/=n;
	for(int i=1;i<=n;i++)
	{
		if(magic[i]!=total)
		{
			magic[i+1]+=magic[i]-total;
			ans++;
		}
	}
	printf("%d\n",ans);
	return 0;
}
