#include<cstdio>
#include<algorithm>
#define M 100010
int a[M],have[M];
int main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	int n,ans=1,use;
	scanf("%d %d",&n,&use);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	have[a[1]]=1;
	for(int l=1,r=2;r<=n;r++)
	{
		if(!have[a[r]] && !use)
			do
			{
				have[a[l++]]--;
			}
			while(have[a[l-1]]);
		if(use) use--;
		ans=std::max(ans,++have[a[r]]);
	}
	printf("%d\n",ans);
	return 0;
}
