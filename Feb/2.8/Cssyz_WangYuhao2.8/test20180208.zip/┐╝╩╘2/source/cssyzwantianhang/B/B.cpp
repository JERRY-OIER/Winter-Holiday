#include<cstdio>
#include<algorithm>
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int now=i;
		for(int j=n;j>1;j--)
		{
			if(now==n) now=(n-1)/j*j;
			else if(now%j==0) now-=j;
			now++;
			
		}
		printf("%d ",now);
	}
	return 0;
}
