//C
#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	cout<<"10";
	return 0;
}
