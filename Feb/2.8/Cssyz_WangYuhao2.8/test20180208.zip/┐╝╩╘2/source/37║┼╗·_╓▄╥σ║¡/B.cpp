#include<cstdio>
#include<algorithm>
using namespace std;
int n;
struct Point{
	int ord,rank;
	bool operator < (const Point x) const { return rank<x.rank; }
}a[1000010];
int main(){
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) a[i].ord=a[i].rank=i;
	for(int i=1;i<=n;i++)
	 for(int t=1;t<=n;t++){
	 	if(!((a[t].rank-1)%i)){
	 		a[t].rank+=i-1;
	 		if(a[t].rank>n) a[t].rank=n;
	 	} 
	 	else a[t].rank--;
	 }
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++) printf("%d ",a[i].ord);
	printf("\n");
	return 0;
}
