#include<cstdio>
#include<iostream>
using namespace std;
int n,m;
int a[100010],ans,p[100010],maxx;
bool k[100010];
void dfs(int x,int st){
	int sc=1,las=-1,sum=0;
	for(int i=1;i<=n;i++) {
		if(!k[a[i]]) continue;
		sum++;
		if(a[i]!=las){
			las=a[i];
			if(sc>ans) ans=sc;
			sc=1;
		}
		else sc++;
	}
	if(sum<ans) return;
	if(sc>ans) ans=sc;
	if(x==m) return ;
	for(int i=st;i<=n;i++){
		if(k[i]){
			k[i]=false;
			dfs(x+1,i+1);
			k[i]=true;
		}
	}
	return;
}
int main(){
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) {
		scanf("%d",&a[i]);
		k[a[i]]=true;
		p[a[i]]++;
		if(p[a[i]]>maxx) maxx=p[a[i]];
	}
	if(maxx==1){
		printf("1\n");
		return 0;
	}
	dfs(0,0);
	printf("%d\n",ans);
	return 0;
}
