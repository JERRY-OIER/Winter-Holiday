#include<cstdio>
#include<iostream>
using namespace std;
int a[1000010],n,ans;
long long sum,ave;
int main(){
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){ scanf("%d",&a[i]); sum+=a[i]; } 
	ave=sum/n;
	for(int i=1;i<=n;i++) a[i]-=ave;
	for(int i=1;i<=n;i++) if(a[i]){ a[i+1]+=a[i]; ans++; }
	cout<<ans<<endl;
	return 0;
} 
