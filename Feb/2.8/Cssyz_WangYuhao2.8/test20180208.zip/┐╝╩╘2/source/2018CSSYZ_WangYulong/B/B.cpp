#include <iostream>  
#include <cstdio>  
using namespace std;  
int n;
int a[1000006];

int main() { 
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		a[i] = i;
	}
	int tmp;
	for (int i = 2; i <= n; ++i) {
		for (int j = 1; j <= n; ++j) {
			tmp = a[j];
			int k;
			for (k = j; k < j + i - 1 && k < n; ++k) {
				a[k] = a[k + 1];
			}
			j = k;
			a[j] = tmp;
		}
		
	/*for (int j = 1; j <= n; ++j) {
		printf("%d ", a[j]);
	}
	cout << endl;*/
	}
	for (int i = 1; i <= n; ++i) {
		printf("%d ", a[i]);
	}
	return 0;
}
