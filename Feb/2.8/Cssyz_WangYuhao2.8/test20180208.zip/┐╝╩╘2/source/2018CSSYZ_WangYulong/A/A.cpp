#include <iostream>  
#include <cstdio>  
using namespace std;  
long long q[1000006];
int main() { 
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);
	long long n, p = 0, ans = 0; 
	cin >> n;  
	for (int i = 1; i <= n; ++i) {
		cin >> q[i]; 
		p += q[i];
	} 
	p /= n;  
	for (int i = 1; i <= n; ++i) q[i] -= p;  
	for (int i = 1; i <= n; ++i) {
		if (q[i] == 0) 
			continue; 
		q[i + 1] += q[i]; 
		ans++; 
	}  
	cout << ans;  
	return 0;
}  
