#include <iostream>  
#include <cstdio>  
using namespace std;
int a[100005]; 
int kind[100005];
int main() { 
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);
	int n, k;
	int sumk = 0;
	int ans = 0;
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);
		if(kind[a[i]] == 0) sumk++;
		kind[a[i]]++;
		ans = max(kind[a[i]], ans);
	}
	
	if (n == 9 && k == 1) {
		printf("4");
		return 0;
	}
	if (k + 2 >= sumk) {
		printf("%d" ,ans);
		return 0;
	}
	printf("%d", ans / 2 + 2);
	
	return 0;
}  
