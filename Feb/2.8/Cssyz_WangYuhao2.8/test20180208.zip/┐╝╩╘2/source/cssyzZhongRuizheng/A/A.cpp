#include <iostream>
#include <cstdio>
using namespace std;
long long n, a[1000001], sum, ans, now;
int main() {
	freopen ("A.in", "r", stdin);
	freopen ("A.out", "w", stdout);
	scanf ("%I64d", &n);
	for (int i = 1; i <= n; i++) {
		scanf ("%I64d", &a[i]);
		sum += a[i];
	}
	sum /= n;
	now = a[1] - sum;
	if (now != 0) ans++;
	for (int i = 2; i <= n; i++) {
		now += a[i] - sum;
		if (now == 0) {
			continue;
		}
		ans++;
	}
	cout<<ans<<endl;
	return 0;
}
