#include <iostream>
#include <cstdio>
using namespace std;
int n, a[2000005], cnt, book = 1, jsq;
int main() {
	freopen ("B.in", "r", stdin);
	freopen ("B.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		a[i] = i;
	}
	for (int i = 2; i <= n; i++) {
		int x = n / i, y = n % i;
		for (int j = 1; j < n - y; j += i) {
			int z = a[j];
			for (int k = 1; k < i; k++) {
				a[k + j - 1] = a[k + j];
			}
			a[j + i - 1] = z;
		}
		if (y != 0) {
			int z = a[x * i + 1];
			for (int j = i * x + 1; j < n; j++) {
				a[j] = a[j + 1];
			}
			a[n] = z;
		}
	}
	for (int i = 1; i <= n; i++) {
		printf("%d ", a[i]);
	}
	cout<<endl;
	return 0;
}
