#include <iostream>
#include <cstdio>
using namespace std;
int n, k, num[100001], x[100001], cnt, ans, sum[100001];
bool u[100001], d[100001];
void solve(int a) {
	if (a > k) {
		int cnt = 1, maxx = 0, la = 1;
		for (int i = 2; i <= n; i++) {
			if (d[num[i]]) {
				continue;
			}
			if (num[i] == num[la]) {
				cnt++;
			}
			else {
				maxx = max(maxx, cnt);
				cnt = 1;
			}
			la = i;
		}
		ans = max(maxx, ans);
		return;
	}
	for (int i = 1; i <= cnt; i++) {
		if (!d[x[i]]) {
			d[x[i]] = 1;
			solve(a + 1);
			d[x[i]] = 0;
		}
	}
}
int main() {
	freopen ("C.in", "r", stdin);
	freopen ("C.out", "w", stdout);
	scanf ("%d%d", &n, &k);
	for (int i = 1; i <= n; i++) {
		scanf ("%d", &num[i]);
		if (!u[num[i]]) {
			x[++cnt] = num[i];
		}
		u[num[i]] = 1;
	}
	if (k == n - 1) {
		for (int i = 1; i <= n; i++) {
			sum[num[i]]++;
		}
		for (int i = 1; i <= n; i++) {
			ans = max(ans, sum[i]);
		}
		cout<<ans<<endl;
		return 0;
	}
	if (n <= 1000) {
		solve(1);
		cout<<ans<<endl;
		return 0;
	}
	else {
		for (int i = 1; i <= n; i++) {
			sum[num[i]]++;
		}
		for (int i = 1; i <= n; i++) {
			ans = max(ans, sum[i]);
		}
		cout<<ans<<endl;
		return 0;
	}
}
