#include<iostream>
#include<cstdio>
using namespace std;
int n,num[1000001][2];
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		num[i][1]=i;
	for(int i=2;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(j%i&&j!=n)
				num[j][0]=num[j+1][1];
			else
				if(!(j%i))
					num[j][0]=num[j-i+1][1];
				else
					num[j][0]=num[j/i*i+1][1];
		}
		for(int j=1;j<=n;j++)
			num[j][1]=num[j][0];
	}
	for(int i=1;i<=n;i++)
		printf("%d ",num[i][1]);
	printf("\n");
	return 0;
}
