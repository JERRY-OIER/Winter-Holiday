#include<iostream>
#include<cstdio>
using namespace std;
int n,num[1000001],tot,ans;
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&num[i]);
		tot+=num[i];
	}	
	tot/=n;
	for(int i=1;i<n;i++)
	{
		if(num[i]!=tot)
			ans++;
		num[i+1]-=tot-num[i];
	}	
	cout<<ans<<endl;
	return 0;
}
