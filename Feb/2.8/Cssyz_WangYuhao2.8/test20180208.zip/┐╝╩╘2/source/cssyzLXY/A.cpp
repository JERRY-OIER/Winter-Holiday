#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <functional>
#include <algorithm>
#include <fstream>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <vector>

using namespace std;
const int MAXN = 1000000;

int a[MAXN + 1];

int main() {
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);
	int N;
	scanf("%d", &N);
	for (int i = 1; i <= N; i++) scanf("%d", &a[i]);
	long long need = 0;
	for (int i = 1; i <= N; i++) need += a[i];
	need /= N;
	int ans = 0;
	for (int i = 1; i <= N; i++) {
		ans += (a[i] != need);
		a[i + 1] -= need - a[i];
	}
	printf("%d\n", ans);
	return 0;
}
