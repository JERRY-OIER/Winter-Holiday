#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int MAXN = 100000;

int a[MAXN + 1];
int book[MAXN + 1];

int main() {
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);
	int n;
	int k;
	scanf("%d%d", &n, &k);
	int maxAns = 0;
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		book[a[i]]++;
		maxAns = max(maxAns, book[a[i]]);
	}
	printf("%d\n", maxAns);
	return 0;
}
