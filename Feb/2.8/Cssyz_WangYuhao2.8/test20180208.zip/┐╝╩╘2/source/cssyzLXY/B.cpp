#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <functional>
#include <algorithm>
#include <fstream>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <vector>

using namespace std;
const int MAXN = 1000000;

int p[2 * MAXN + 1];

int main() {
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) p[i] = i;
	for (int i = 1; i <= n; i++) {
		int tI = 0, nI = 0;
		for (int t = i; t <= n + i; t += i) {
			tI = p[t];p[t] = nI;nI = tI;
		}
		if (nI) p[n + i] = nI;
	}
	for (int i = n + 1; i <= 2 * n; i++) printf("%d ", p[i]);
	printf("\n");
	return 0;
}
