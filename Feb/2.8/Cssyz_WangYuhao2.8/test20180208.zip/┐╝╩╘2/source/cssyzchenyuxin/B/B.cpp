#include <iostream>
#include <cstdio>

using namespace std;

int n, a[1000005], next[1000005];

void print(int x)
{
	if (next[x] == 0) return;
	else printf("%d ", next[x]);
	print(next[x]);
}

int main()
{
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) a[i] = i;
	for (int i = 0; i < n; i++) next[i] = a[i + 1];
	for (int i = 2; i <= n; i++)
	{
		int phi = (n / i) * i + 1;
		if (n % i > 1)  
		{
			int g = next[phi];
			next[phi] = next[n];
			next[n] = next[phi - 1];
			next[phi - 1] = g;
		}
		for (int j = phi - i; j >= 1; j -= i)
		{
			int g = next[j];
			next[j] = next[j + i - 1];
			next[j + i - 1] = next[j - 1];
			next[j - 1] = g;
		}                
	} 
	print(0); 
	printf("\n");
	return 0;
}
