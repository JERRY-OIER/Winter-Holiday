#include <cstdio>
#include <vector>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <bitset>
#include <complex>
#include <string>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cctype>
#define MAX_N 1000010
using namespace std;

int x[MAX_N];
int N;

int main () {
  freopen ("B.in", "r", stdin);
  freopen ("B.out", "w", stdout);
  scanf("%d", &N);
  for (int i = 1;i <= N; ++i) x[i] = i;
  for (int i = 2;i <= N; ++i) {
    int book;
    for (int j = 1;j <= N / i * i; ++j) {
      if (j % i == 1) book = x[j];
      if (j % i == 0) {x[j] = book;continue;}
      x[j] = x[j + 1];
    }
    for (int j = N / i * i + 1;j <= N; ++j) {
      if (j % i == 1) book = x[j];
      if (j == N) {x[j] = book;continue;}
      x[j] = x[j + 1];
    }

  }

  for (int i = 1;i <= N; ++i) printf("%d ", x[i]); printf("\n");
  return 0;
}
