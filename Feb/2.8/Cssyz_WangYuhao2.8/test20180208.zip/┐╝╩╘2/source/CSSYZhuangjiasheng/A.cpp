#include <cstdio>
#include <vector>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <bitset>
#include <complex>
#include <string>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cctype>
#define MAX_N 1000001
typedef unsigned long long ll;
using namespace std;

ll N, x[MAX_N], p;
ll res;

ll sum_range (int be, int en) {
  ll ans = 0;
  for (int i = be;i <= en; ++i) ans += x[i];
  return ans;
}

int main () {
  freopen ("A.in", "r", stdin);
  freopen ("A.out", "w", stdout);
  scanf("%lld", &N);
  for (int i = 1;i <= N; ++i) scanf("%lld", x + i);
  int sum = sum_range(1, N);
  p = sum / N;
  for (int i = 1;i <= N; ++i) {
    if (x[i] == p) continue;
    if (x[i] > p) {
      res++;
      x[i + 1] += x[i] - p;
      x[i] = p;
    }
    else {
      res++;
      x[i + 1] -= (p - x[i]);
      x[i] += p - x[i];
    }
  }
  printf("%lld\n", res);
  return 0;
}
