#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstring>
#define MAX_N 100010
#define for_i_in_range(l, r) for(int i = l;i <= r; ++i) 
using namespace std;
struct seg {
  int l, r;
  int val, m;
  seg() {}
  seg (int l_, int r_, int val_, int m_) : l(l_), r(r_), val(val_), m(m_) {}
  bool operator < (const seg& rhs) const {
    return val == rhs.val ? m > rhs.m : val < rhs.val;
  }
}g[MAX_N];

int N, k, x[MAX_N];
int book[MAX_N];
int gl;
int res;

int main () {
  freopen ("C.in", "r", stdin);
  freopen ("C.out", "w", stdout);
  scanf("%d%d", &N, &k);
  ++k;
  for (int i = 1;i <= N; ++i) scanf("%d", x + i);
  for (int i = 1;i <= N; ++i) {
    int sum = 0;
    int maxx = 0;
    memset(book, 0, sizeof(book));
    for (int j = i;j <= N; ++j) {
      if (!book[x[j]]) sum++;
      book[x[j]]++;
      if (book[x[j]] > maxx) maxx = book[x[j]];
      g[++gl] = seg(i, j, sum, maxx);
    }
  }

  sort(g + 1, g + gl + 1);
  //for_i_in_range (1, gl) printf("%d  l:%d r:%d val:%d m:%d\n", i, g[i].l, g[i].r, g[i].val, g[i].m);
  int front = 1;
  bool flag[MAX_N];
  memset(flag, 0, sizeof(flag));
  while (g[front].val <= k && front <= gl) {
    if (flag[g[front].val]) {front++; continue;}
    flag[g[front].val] = true;
    res = max(res, g[front++].m);
  } //printf("\n");
  printf("%d\n", res);
  return 0;
}
