#include <functional>
#include <windows.h>
#include <algorithm>
#include <iostream>
#include <istream>
#include <ostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <conio.h>
#include <string>
#include <cstdio>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

using namespace std;

int n;
long long sum;
long long a[1000001];

int main() {
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++) {
		scanf("%d",&a[i]);
		sum += a[i];
	}
	sum /= n;
	int t = 0;
	int res = n;
	for(int i = 1; i <= n; i++) {
		t = t + a[i] - sum;
		if(!t) res--;
	}
	printf("%d\n", res);
	return 0;
}
