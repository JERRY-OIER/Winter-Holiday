#include <functional>
#include <windows.h>
#include <algorithm>
#include <iostream>
#include <istream>
#include <ostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <conio.h>
#include <string>
#include <cstdio>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

using namespace std;

const int N = 1000000;

int n;
int a[N + 1];
int b[N + 1];

int main() {
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++) a[i] = i;
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= n; j++)
			if(j % i == 1)
				if(((j + i - 1) / i) * i <= n) b[(j - 1 + i) / i * i] = a[j];
				else b[n] = a[j];
			else b[j - 1] = a[j];
		for(int j = 1; j <= n; j++) a[j] = b[j];
	}
	for(int i = 1; i <= n; i++) printf("%d ", a[i]);
	printf("\n");
	return 0;
}
