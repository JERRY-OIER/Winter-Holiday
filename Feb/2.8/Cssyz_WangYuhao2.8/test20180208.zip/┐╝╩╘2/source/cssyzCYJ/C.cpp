#include <functional>
#include <windows.h>
#include <algorithm>
#include <iostream>
#include <istream>
#include <ostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <conio.h>
#include <string>
#include <cstdio>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

using namespace std;

const int N = 100000;

int n, k;
int dp[N + 1];
int a[N + 1];
int pd[N + 1];


int main() {
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
	int res = 0;
	for(int i = 1; i <= n; i++) {
		if(a[i] == a[i - 1]) dp[i] = dp[i - 1] + 1;
		else{
			int q = k;
			for(int j = i; j && q >= 0; j--) {
				if(a[i] != a[j] && pd[a[j]] != i) {
					q--;
					pd[a[j]] = i;
				}
				if(a[i] == a[j]) dp[i]++;
			}
		}
		res = max(res, dp[i]);
	}
	printf("%d\n", res);
	return 0;
}
