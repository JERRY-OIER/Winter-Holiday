#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,i,j,x,book[100002],ans,max1;
int main(){
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&x);
		book[x]++;
	}
	for(i=1;i<=n;i++)
		if(book[i]>ans)
			ans=book[i];
	cout<<ans<<endl;
	return 0;
}
