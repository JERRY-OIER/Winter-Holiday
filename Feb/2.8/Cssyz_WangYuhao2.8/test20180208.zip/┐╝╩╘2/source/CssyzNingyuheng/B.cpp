#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,i,j,k,l,o,p,q,a[1000200],book[100020],ans,sum,flag,vis[100002],d[100002],top;
int main(){
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		a[i]=i;
	for(i=2;i<=n;i++){
		for(j=1;j<=n;j++){
			if(j%i==1)
				sum=a[j];
			if(j%i==0||j==n)
				a[j]=sum;
			else
				a[j]=a[j+1];
		}
	}
	for(j=1;j<=n;j++)
		cout<<a[j]<<" ";
	cout<<endl;
	return 0;
}
