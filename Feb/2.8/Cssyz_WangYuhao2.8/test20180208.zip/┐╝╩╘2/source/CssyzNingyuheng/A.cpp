#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
long long n,i,a[100020],ans,sum;
int main(){
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%lld",&n);
	for(i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		sum+=a[i];
	}
	sum/=n;
	for(i=1;i<=n;i++)
		if(a[i]!=sum){
			ans++;
			a[i+1]+=a[i]-sum;
		}
	printf("%lld\n",ans);
	return 0;
}
