#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;
int a[100001];
int col[100001];
int main(){
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		col[a[i]]++;
	}
	int maxx=0;
	for(int i=1;i<=n;i++)
		maxx=max(col[i],maxx);
	printf("%d\n",maxx);
	return 0;
}
