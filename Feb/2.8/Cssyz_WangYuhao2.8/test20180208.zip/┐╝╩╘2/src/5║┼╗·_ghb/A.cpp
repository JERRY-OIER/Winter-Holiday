#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int a[1000001];
int sum;
int ans;
int main(){
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		sum+=a[i];
	}
	int ne=sum/n;
	for(int i=1;i<=n;i++){
		if(a[i]==ne)
			continue;
		a[i+1]+=(a[i]-ne);
		ans++;
	}
	printf("%d\n",ans);
	return 0;
}