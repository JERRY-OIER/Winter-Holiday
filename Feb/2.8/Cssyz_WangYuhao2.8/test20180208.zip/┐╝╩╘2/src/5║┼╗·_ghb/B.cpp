#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int arr[1001];
//int tep1[1001],tep2[1001];
int b[2001][2001];
int n;
int main(){
    freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		b[1][i]=i;
	for(int i=2;i<=n;i++){
		int j;
		for(j=1;j<=(n/i);j++){
			b[i][j*(i)]=b[i-1][(j-1)*(i)+1];
		}
		int temp=n-(j-1)*(i);
		if(temp)
			b[i][n]=b[i-1][n-temp+1];
		for(int j=1;j<=n;j++)
			if(!b[i][j])
				b[i][j]=b[i-1][j+1];
	}
	for(int i=1;i<n;i++){
		// for(int j=1;j<=n;j++){
		// 	printf("%d ",b[i][j]);
		// }
		// puts("");
		printf("%d ",b[n][i]);
	}
	printf("%d\n",b[n][n]);
	return 0;
}