#include<cstdio>
#include<cstdlib>
#include<iomanip>
#include<iostream>
#include<cstring>
#include<string>
#include<ctime>
#include<cmath>
#include<algorithm>
using namespace std;
long long n;
long long v[1000001];
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%I64d",&n);
	long long sum=0;
	for(int i=1;i<=n;i++) 
	{
		scanf("%I64d",&v[i]);
		sum+=v[i];
	}
	long long goal=sum/n;
	for(int i=1;i<=n;i++) v[i]-=goal;
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		if(v[i]!=0) ans++;v[i+1]+=v[i];
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
