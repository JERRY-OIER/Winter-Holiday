#include<cstdio>
#include<cstdlib>
#include<iomanip>
#include<iostream>
#include<cstring>
#include<string>
#include<ctime>
#include<cmath>
#include<algorithm>
using namespace std;
int a[1000001];
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) a[i]=i;
    	int t=2;
		while(t<=n)
		{
			int k=t;
			while(k<n)
			{
				for(int i=k-t+1;i<=k-1;i++) 
				{
					int t=a[i];
					a[i]=a[i+1];
					a[i+1]=t;
				}
				k+=t;
			}
			k-=t;
			for(int i=k+1;i<=n-1;i++)
			{
				 //swap(a[i],a[i+1]);
				 int t=a[i];
				 a[i]=a[i+1];
				 a[i+1]=t;
			}
			t++;
		}
		for(int i=1;i<=n;i++) 
		{
			printf("%d ",a[i]);
		}
		fclose(stdin);
		fclose(stdout);
		return 0;
		
}
