#include<cstdio>
#include<cstdlib>
#include<iomanip>
#include<iostream>
#include<cstring>
#include<string>
#include<ctime>
#include<cmath>
#include<algorithm>
using namespace std;
int n;
int k;
int b[1000001];
int a[1000001];
int ans=0;
void dfs(int num)
{
	if(num==k)
	{
		int fre=0;
		int sum=0;
		int sum1=0;
		for(int i=1;i<=n;i++)
		{
			if(b[a[i]]) continue;
			if(!fre) fre=a[i];
			if(a[i]==fre) sum1++;
			if(a[i]!=fre)
			{
				fre=a[i];
				if(sum1>sum) sum=sum1;
				sum1=1;
			}
		}
		if(sum>ans) ans=sum;
	}
	for(int i=1;i<=n;i++)
	{
		if(!b[a[i]])
		{
			b[a[i]]=true;
			dfs(num+1);
			b[a[i]]=false;
		}
	}
}
int main()
{
	 freopen("C.in","r",stdin);
	 freopen("C.out","w",stdout);
	 scanf("%d%d",&n,&k);
	 for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	 dfs(0);
	 cout<<ans;
	 fclose(stdin);
	 fclose(stdout);
	 return 0; 
}
