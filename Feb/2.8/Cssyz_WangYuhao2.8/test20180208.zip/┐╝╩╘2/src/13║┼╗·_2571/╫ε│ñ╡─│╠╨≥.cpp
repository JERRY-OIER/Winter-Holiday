#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<iomanip>
#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
#include<ctime>
using namespace std;
int n,m,value[100010],dep[100010],pos[100010],seq[100010],top[100010],size[100010],fa[100010],head[10010],son[10010];
string  s;
struct  by//�ڽӱ� 
{
   int next;int to;int from;int value;
}table[100010];
struct byy//�߶��� 
{
	int sum;int m;int s;int l;int r;int lazy;
}point[100010];
void updata(int b)//����  ˢ������ 
{
        point[b].sum=point[2*b].sum+point[2*b+1].sum;
        point[b].m=max(point[2*b].m,point[2*b+1].m);   
        point[b].s=min(point[2*b].s,point[2*b+1].s); 
}
void build(int b,int l,int r)
{
    // lazy[b]=0;
     c[b].lazy=0; c[b].l=l;c[b].r=r;
     if(l==r){c[b].sum=c[b].mmax=c[b].mmin=a[r];}
     else
     {
        int mid=(l+r)/2;
        build(2*b,l,mid);
        build(2*b+1,mid+1,r);
        updata(b);
     }
}
void pushDown(int b)//lazy �´� 
{
                   point[2*b].lazy+=point[b].lazy;
                   point[2*b+1].lazy+=point[b].lazy;
                   
                   point[2*b].sum=point[2*b].sum+(point[2*b].r-point[2*b].l+1)*point[b].lazy;
                   point[2*b].m=point[2*b].m+point[b].lazy;
                   point[2*b].s=point[2*b].s+point[b].lazy;                   
                   point[2*b+1].sum=point[2*b+1].sum+(point[2*b+1].r-point[2*b+1].l+1)*point[b].lazy;
                   point[2*b+1].m=point[2*b+1].m+point[b].lazy;
                   point[2*b+1].s=point[2*b+1].s+point[b].lazy;                    
                   point[b].lazy=0; 
}
int  query(int x,int y)//��ѯ  
{
	int re=0;
	while(top[x]!=top[y])
	{
		if(dpt[top[x]]<dpt[top[y]])  swap(x,y);
		re+=tree->query(1,n,pos[top[x]],pos[x]);
		x=fa[top[x]];
	}
	if(dpt[x]<dpt[y])  swap(x,y);
	return re+tree->query(1,n,pos[y],pos[x]);
}
void dfs1(int x)//����1 
{
	int i;
	dep[x]=dep[fa[x]]+1;
	size[x]=1;
	for(i=head[x];i;i=table[i].next)
	  if(table[i].to!=fa[x])
	  {
	  	fa[table[i].to]=x;
	  	dfs1(table[i].to);
	  	size[x]+=size[table[i].to];
	  	if(size[table[i].to]>size[son[x]])
	  	  son[x]=table[i].to;
      }
}
void dfs2(int x)//����2  ��ȱ��һ�����ƹ��̣� 
{
	static int t;
	int i;
	seq[pos[x]=++t]=x;
	if(son[fa[x]]==x)  top[x]=top[fa[x]];
	else               top[x]=x;
	if(son[x])         dfs2(son[x]);
	for(i=head[x];i;i=table[i].next)
	{
	   if(table[i].to!=fa[x] && table[i].to!=son[x])
	      dfs2(table[i].to);
	   //value[table[i].to]=table[i].value;
    }
}
void modify(int b,int l,int r,int v)//�޸�����ֵ��������������޸ĵ����䣬�������������ֵ 
{
     if(l<=point[b].l && point[b].r<=r)
     {
        //lazy[b]=lazy[b]+v;
        point[b].lazy+=v;
        point[b].sum=point[b].sum+(point[b].r-point[b].l+1)*v;
        point[b].m=point[b].m+v;
        point[b].s=point[b].s+v;
     }
     else
     {  
         if(c[b].lazy!=0) pushDown(b); //�޸�ʱҪ�´����,����ݹ����ϸ��¾Ͳ���ȷ�� ,������һ��ı�Ǵ����� 
          int mid=(point[b].l+point[b].r)/2; 
          if(l<=mid) modify(2*b,l,r,v);
          if(r>mid)  modify(2*b+1,l,r,v);
		  updata(b);
     }
}
byy query(int b,int x,int y)//��ѯ  ���������Сֵ 
{
      if(x<=point[b].l && point[b].r<=y) return point[b];
      else
      {
           pushDown(b);         
           int mid=(point[b].l+point[b].r)/2;
           if(y<=mid) return query(2*b,x,y); 
           if(x>mid)  return query(2*b+1,x,y);
           
           node tl,tr,t;
           tl=query(2*b,x,y); 
           tr=query(2*b+1,x,y);
           
           t.sum=tl.sum+tr.sum;
           t.m=max(tl.m,tr.m);
           t.s=min(tl.s,tr.s);
           return t;
      } 
}
int main()
{
    cin>>n;
    for(int i=1;i<=n-1;i++)
    {
    	int w,v,u;
    	scanf("%d%d%d",&u,&v,&w);
    	u++;v++; 
		table[i].from=u;
		table[i].to=v;
		table[i].value=v;
		table[i+n-1].from=table[i].to;
		table[i+n-1].to=table[i].from;
		table[i+n-1].value=table[i].value;
		table[i].next=head[table[i].from];
		head[table[i].from]=i;
		table[i+n-1].next=head[table[i+n-1].from];
		head[table[i+n-1].from]=i+n-1;
    }
    dfs1(1);
    dfs2(1);
    for(int i=0;i<=4;i++)
      cout<<son[i]<<" ";
    /*cin>>m;
    for(int i=1;i<=m;i++)
    {
      int a,b;
      scanf("%s%d%d",&ch,&a,&b);
      if(ch=='C')
      {
      	 table[a].val=b;
      	 value[table[a].to]=table[a].val;
      }
      else if(ch=='N')
	  {
	  	
	  } 
	  else if(ch=='SUM')
	  {
	  	
	  }
	  else if(ch=='MAX')
	  {
	  	
	  }
	  else if(ch=='MIN')
	  {
	  	
	  }
    }*/`
	return 0;
}
