#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<iomanip>
#include<string>
#include<cstring>
#include<ctime>
#include<algorithm>
using namespace std;
int n,m,x,y;
int a[200050];
struct by
{
	int l;int r;int lm;int rm;int m;int mm;
}p[1000050];
void cjz(int i,int l,int r)
{
	p[i].l=l;  p[i].r=r;
	if(l==r)   p[i].lm=p[i].rm=p[i].mm=p[i].m=a[l];
	else 
	{
		int mid=(l+r)/2;
		cjz(2*i,l,mid);
		cjz(2*i+1,mid+1,r);
		p[i].m=p[2*i].m+p[2*i+1].m;
		p[i].lm=max(p[2*i].lm,p[2*i].m+p[2*i+1].lm);
		p[i].rm=max(p[2*i+1].rm,p[2*i+1].m+p[2*i].rm);
		p[i].mm=max(p[2*i].mm,(max(p[2*i+1].mm,p[2*i].rm+p[2*i+1].lm)));
	}
}
by dfs(int i)
{	
     
     
	if(p[i].l>=x && p[i].r<=y)  {return p[i];}
	
	else
	{
	     int mid=(p[i].r+p[i].l)/2;
	    if(y<=mid)   return dfs(2*i);
	    if(x>mid)   return dfs(2*i+1);
		by p1=dfs(2*i);
		by p2=dfs(2*i+1);
		by pp;
		pp.m=p1.m+p2.m;
		pp.lm=max(p1.lm,p1.m+p2.lm);
	    pp.rm=max(p2.rm,p2.m+p1.rm);
		pp.mm=max(p1.mm,max(p2.mm,p1.rm+p2.lm));
		return pp;		
	}                        
}
int main()
{
     freopen("sum.in","r",stdin);
     freopen("sum.out","w",stdout);
	 cin>>n;
	 for(int i=1;i<=n;i++)    scanf("%d",&a[i]);
	 cjz(1,1,n);
	 cin>>m;
	 for(int i=1;i<=m;i++)
	 {
	 	scanf("%d%d",&x,&y);
	    by pp=dfs(1);
		cout<<pp.mm<<endl;	
      }
	return 0;
}
