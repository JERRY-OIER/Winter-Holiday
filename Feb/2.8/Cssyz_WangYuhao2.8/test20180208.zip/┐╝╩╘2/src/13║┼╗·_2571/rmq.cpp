#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<iomanip>
#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
#include<ctime>
using namespace std;
int a[200010];
int n,m,x,y;
struct by
{
    int m;int l;int r;	
}p[800002];
void cjz(int b,int l,int r)
{
       p[b].r=r; p[b].l=l;    
       
       if(l==r)  p[b].m=a[l];
       else
       { 
               int mid=l+(r-l)/2;       
               cjz(2*b,l,mid);
               cjz(2*b+1,mid+1,r);
               p[b].m=max(p[2*b].m,p[2*b+1].m);
       }
}
int dfs(int i)
{
     if(x<=p[i].l && y>=p[i].r){  return p[i].m;}
   else
   {
   
       int mid=(p[i].l+p[i].r)/2;     
       int ans=-2147483647;
      
       if(x<=mid) ans=max(ans,dfs(i*2));
       if(mid<y)  ans=max(ans,dfs(i*2+1));
       
       
       return ans;
   }    
}
int main()
{
     freopen("rmq.in","r",stdin);
     freopen("rmq.out","w",stdout);
	 cin>>n;
	 for(int i=1;i<=n;i++)
	  scanf("%d",&a[i]);
	  cjz(1,1,n);
	 cin>>m;
	 for(int i=1;i<=m;i++)
	 {
	 	scanf("%d%d",&x,&y);
		cout<<dfs(1)<<endl;	
	 }	
	return 0;
}
