#include<iostream>
#include<cmath>
using namespace std;
int n,m;
int a[50010];
int l,r,l1,r1;
struct node
{
  int b,l,r;
  int sum,mmax,mmin;  
  int lazy;//�����     
};
node c[1000000];


void updata(int b)
{
        c[b].sum=c[2*b].sum+c[2*b+1].sum;
        c[b].mmax=max(c[2*b].mmax,c[2*b+1].mmax);   
        c[b].mmin=min(c[2*b].mmin,c[2*b+1].mmin); 
}

void build(int b,int l,int r)
{
    // lazy[b]=0;
     c[b].lazy=0; c[b].l=l;c[b].r=r;
     if(l==r){c[b].sum=c[b].mmax=c[b].mmin=a[r];}
     else
     {
        int mid=(l+r)/2;
        build(2*b,l,mid);
        build(2*b+1,mid+1,r);
        updata(b);
     }
}

void pushDown(int b)//lazy �´� 
{
                  // lazy[2*b]=lazy[2*b]+lazy[b];   
                  // lazy[2*b+1]=lazy[2*b+1]+lazy[b];  
                   c[2*b].lazy+=c[b].lazy;
                   c[2*b+1].lazy+=c[b].lazy;

                   c[2*b].sum=c[2*b].sum+(c[2*b].r-c[2*b].l+1)*c[b].lazy;
                   c[2*b].mmax=c[2*b].mmax+c[b].lazy;
                   c[2*b].mmin=c[2*b].mmin+c[b].lazy;                   
                   c[2*b+1].sum=c[2*b+1].sum+(c[2*b+1].r-c[2*b+1].l+1)*c[b].lazy;
                   c[2*b+1].mmax=c[2*b+1].mmax+c[b].lazy;
                   c[2*b+1].mmin=c[2*b+1].mmin+c[b].lazy;                    
                   //lazy[b]=0;  
                   c[b].lazy=0; 
} 
void modify(int b,int l,int r,int v)//�޸�����ֵ��������������޸ĵ����䣬�������������ֵ 
{
     if(l<=c[b].l && c[b].r<=r)
     {
        //lazy[b]=lazy[b]+v;
        c[b].lazy+=v;
        c[b].sum=c[b].sum+(c[b].r-c[b].l+1)*v;
        c[b].mmax=c[b].mmax+v;
        c[b].mmin=c[b].mmin+v;
     }
     else
     {  
         if(c[b].lazy!=0) pushDown(b); //�޸�ʱҪ�´����,����ݹ����ϸ��¾Ͳ���ȷ�� ,������һ��ı�Ǵ����� 

          int mid=(c[b].l+c[b].r)/2; 
          if(l<=mid) modify(2*b,l,r,v);
          if(r>mid)  modify(2*b+1,l,r,v);
          
		  updata(b);
       
       /*
        c[b].sum=c[2*b].sum+c[2*b+1].sum+(c[b].r-c[b].l+1)*c[b].lazy;
        c[b].mmax=max(c[2*b].mmax,c[2*b+1].mmax)+c[b].lazy;   
        c[b].mmin=min(c[2*b].mmin,c[2*b+1].mmin)+c[b].lazy; */
  
     }

}

node query(int b,int x,int y)
{
      if(x<=c[b].l && c[b].r<=y) return c[b];
      else
      {
           pushDown(b);         
           int mid=(c[b].l+c[b].r)/2;
           if(y<=mid) return query(2*b,x,y); 
           if(x>mid)  return query(2*b+1,x,y);
           
           node tl,tr,t;
           tl=query(2*b,x,y); 
           tr=query(2*b+1,x,y);
           
           t.sum=tl.sum+tr.sum;
           t.mmax=max(tl.mmax,tr.mmax);
           t.mmin=min(tl.mmin,tr.mmin);
           
           return t;

           
      }
     
}


int main()
{
    
    freopen("madd.in","r",stdin);
    freopen("madd.out","w",stdout);
 
    scanf("%d",&n);
    for(int i=1;i<=n;i++) scanf("%d",&a[i]);
    build(1,1,n);
    
   // printf("%d",c[2].sum);
    scanf("%d",&m);
       
   for(int i=1;i<=m;i++)
   {
        int t,x,y;
        scanf("%d%d%d",&t,&x,&y);
        if(t)//��ѯ 
        {   
            node p;
            p=query(1,x,y);
            printf("%d %d %d\n",p.sum,p.mmin,p.mmax);          
        }
        else
        {
           int v;
           scanf("%d",&v); 
           modify(1,x,y,v);
           
           //printf("%d %d %d",c[17].sum,c[17].l,c[17].r);
            
        }
        
   }
   
          
   fclose(stdin);fclose(stdout);       
    
 //system("pause");   
 return 0;    
}
