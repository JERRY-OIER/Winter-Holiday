#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<iomanip>
#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
#include<ctime>
using namespace std;
int  a[100010];
long long c[100010],n,ping;
long long ans=0;
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
	  scanf("%d",&a[i]);
      c[i]=c[i-1]+a[i];
	}
	ping=c[n]/n;
	ans=n;
	long long top=0,sum=0;
    for(int i=1;i<=n;i++)
    {
    	++top;
    	sum+=a[i];
    	if(sum%ping==0 && sum/ping==top)   
		{
		 ans--;
		 sum=0;
		 top=0;
		 }
    }
	cout<<ans;
	return 0;
}
