#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<ctime>
#include<string>
#include<iomanip>
using namespace std;
long long a[1000010],s[1000010];
int ans=0;
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);

	int n;
	cin>>n;
	long long sum=0;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		sum+=a[i];
	}
	int sd=sum/n;
 
    
    
	for(int i=1;i<=n;i++)
	{
		a[i]-=sd;
	}
	for(int i=1;i<=n;i++)
	{
		if(a[i]!=0)
		{
			a[i+1]+=a[i];
			ans++;
		}
	}
	cout<<ans;
	fclose(stdin);fclose(stdout);
	return 0;
}

