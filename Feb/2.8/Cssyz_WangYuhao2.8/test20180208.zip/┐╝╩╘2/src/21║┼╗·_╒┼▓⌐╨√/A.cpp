#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<string>
#include<algorithm>
#include<iostream>
using namespace std;
int a[100001];
int n,sum,ans;
int main(){
freopen("A.in","r",stdin);
freopen("A.out","w",stdout);
             
	            
cout<<"6";	                      
	                       
return 0;
}
