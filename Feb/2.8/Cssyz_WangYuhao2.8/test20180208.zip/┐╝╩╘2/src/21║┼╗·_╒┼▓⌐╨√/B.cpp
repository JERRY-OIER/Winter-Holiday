#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<string>
#include<algorithm>
#include<iostream>
using namespace std;
int a[20001],ans[20001]={0,1},mark[20001];
int n;
int main(){
freopen("B.in","r",stdin);
freopen("B.out","w",stdout);
scanf("%d",&n);
for(int i=1;i<=n;i++) a[i]=i;

for(int i=1;i<=n;i++){
	
	int k=n%i,m=n-k;
	for(int j=1;j<=m;j++) 
	{ mark[j]=j-1;
	  if((j-1)%i==0)mark[j]+=i;
	}
	
	for(int j=m+1;j<=n;j++)
	{ mark[j]=j-1;
	  if(mark[j]<=m) mark[j]=n;		
		
	}
	
	for(int j=1;j<=n;j++) ans[mark[j]]=a[j]; 
	for(int j=1;j<=n;j++) a[j]=ans[j];
	
	
//for(int j=1;j<=n;j++)printf("%d ",ans[j]); cout<<endl;	
}
	
for(int i=1;i<=n;i++)printf("%d ",ans[i]);	
	
return 0;
}
