#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<vector>
#define   maxn    100005
using namespace std;
struct d{int x,to;}a[maxn];
int n,k,ai[maxn],f[maxn/10][maxn/10],ttt=-1;
void del(int tt){
	for(int i=1;i<n;i++)
	 {
	 	if(a[i].x==tt)
	 	a[i-1].to=a[i+1].x;
	 }
}
   int find()
{   int l=0,r=1;
	int num=0,maxnn=-1;

	 while(l<r)
	{
		num=r-l;
		if(a[l].to==a[r].to)
		 {
		 	r++;
		 	num++;
		    if(num>maxnn)   
		    maxnn=num;
	     }
		else
		{
			num=0;
			l=r;
			r++;
		}		
        if(a[l].to==-1)  break;
	}
	return  maxnn;
}
int main ()
{
	freopen("C.in","w",stdin);
	freopen("C.out","r",stdout);
   cin>>n>>k;int maxnxn=-1;
   for(int i=1;i<=n;i++)
    {  int y;
    	cin>>y;
    	ai[y]++;
    	a[i].x=y;
    	a[i-1].to=a[i].x;
    	if(y>maxnxn)  maxnxn=y;
    }
  /* a[n].to=-1;
   cout<<find();
   */
   f[0][0]=0;
   f[0][k]=find();
for(int i=1;i<=k;i++)   
 for(int j=1;j<=maxnxn;j++)
    {  if(ai[j]!=0)
        del(j);
      int ans=find();
       if(ans>ttt)  ttt=ans;
    }
   cout<<ttt;
  
  return 0;
	 }
	 
