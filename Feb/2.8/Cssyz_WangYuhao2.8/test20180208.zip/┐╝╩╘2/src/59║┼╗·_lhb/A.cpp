#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<vector>
#define   maxn    1000005
using namespace std;
int n,k,a[maxn],ans;
long long numx;
bool check()
{  
    int num=0;
	for(int i=1;i<=n;i++)
	  if(a[i]==k) num++;
	 if(num==n)  return true;
	 else        return false;
  }

int main ()
{
	freopen("A.in","w",stdin);
	freopen("A.out","r",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	 	{
	 	scanf("%d",&a[i]);
        numx+=a[i]; 
		}
	k=numx/n;
	int ans=0,x=1;
	while(!check())
	{
		if(x-1!=0 && a[x-1]!=0 && a[x]<k)  
		 { 
		     a[x-1]-=k-a[x];
		     a[x]=k;
		     x++;
		     ans++;
		 }

		if(x+1!=0 && a[x+1]!=0 && a[x]<k)  
		 { 
		     a[x+1]-=k-a[x];
		     a[x]=k;
		     x++;
		     ans++;
		 }		
}
cout<<ans;	
	
	return 0;
}
