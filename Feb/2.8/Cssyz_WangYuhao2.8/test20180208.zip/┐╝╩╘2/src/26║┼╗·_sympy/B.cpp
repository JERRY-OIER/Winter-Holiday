#include<cstdlib>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<iomanip>
#include<string>
#include<cmath> 
#include<ctime>
using namespace std;
int n,a[1000005];
void B(int x)
{
	    int i=1;
		while(i%x==1 && i<=n-n%x-x+1)  
		{   int t=a[i],v=i;
			for(int j=i;j<=i+x-2;j++)
			 a[j]=a[j+1];
			a[i+x-1]=t; 
			i+=x; 
		}
		if(n-n%x+1<=n)
		{
			int t=a[n-n%x+1];//cout<<t<<" ";
			for(int j=n-n%x+1;j<=n;j++)
			 a[j]=a[j+1];
			 a[n]=t;
	    }
	   
	return ;
}
int main()
{
	freopen("B.in","r",stdin);
 	freopen("B.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
       a[i]=i;
    for(int i=2;i<=n;i++)
    	B(i);
    for(int i=1;i<=n;i++)
    	printf("%d ",a[i]);
	return 0;
}
