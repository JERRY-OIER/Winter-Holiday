#include<cstdlib>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<iomanip>
#include<string>
#include<cmath> 
#include<ctime>
using namespace std;
struct QAQ{
	int le;int re;int sum;
};
QAQ s[2000005];
int N,a[1000005],ans=0;
long long summ=0;
int ender;
void pushdl_down(int x,int sign)
{ 
	s[x].sum-=sign;
	if(s[x].le==s[x].re)  return ;
	pushdl_down(x*2,sign);
	return ;
}
void pushcr_down(int x,int sign)
{
	s[x].sum+=sign;
	if(s[x].le==s[x].re)  return ;
	pushcr_down(x*2+1,sign);
	return ;
}
void pushdr_down(int x,int sign)
{
	s[x].sum-=sign;
	if(s[x].le==s[x].re)  return ;
	pushdr_down(x*2+1,sign);
	return ;
}
void pushcl_down(int x,int sign)
{
	s[x].sum+=sign;
	if(s[x].le==s[x].re)  return ;
	pushcl_down(x*2,sign);
	return ;
}
void A(int l,int r,int x)
{
	s[x].le=l; s[x].re=r;
	if(l==r)  s[x].sum=a[l]-ender;
	else
	{
		int t=(l+r)/2;
		A(l,t,x*2);  A(t+1,r,x*2+1);
		s[x].sum=s[x*2].sum+s[x*2+1].sum;
	}
	return ;
}
void B(int x,int y)
{
	int t1=s[x].sum,t2=s[y].sum;
	if(t1<t2)
	{
	  a[s[y].le]-=s[y].sum; pushdl_down(x,s[y].sum);
	  a[s[x].re]+=s[y].sum; pushcr_down(y,s[y].sum);
	/*cout<<ans<<"-";
	for(int i=1;i<=N;i++)  cout<<a[i]<<" ";
	cout<<endl;*/
	ans++;
	}
	else if(t1>t2)
	{
	  a[s[y].le]+=s[x].sum;  pushcl_down(x,s[x].sum);
	  a[s[x].re]-=s[x].sum;  pushdr_down(y,s[x].sum);
	  ans++;
	}
	if(s[x].le!=s[x].re)	B(x*2,x*2+1);
    if(s[y].le!=s[y].re)  B(y*2,y*2+1);
	return ;
}
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
	   scanf("%d",&a[i]);	
	   summ+=a[i];
	}
	ender=summ/N;
	A(1,N,1);
	B(2,3);
	printf("%d",ans);
	return 0;
}
