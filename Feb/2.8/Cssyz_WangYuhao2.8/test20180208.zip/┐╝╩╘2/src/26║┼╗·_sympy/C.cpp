#include<cstdlib>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<iomanip>
#include<string>
#include<cmath> 
#include<ctime>
using namespace std;
int n,k,a[100005],num=0;
int main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	  scanf("%d",&a[i]);
    cout<<rand()%n-k;
	return 0;
}
