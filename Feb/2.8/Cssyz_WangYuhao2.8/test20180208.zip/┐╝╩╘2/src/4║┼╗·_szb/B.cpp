#include <iostream>
#include <cstdio>
using namespace std;
const int N=1000001;
int n; int a[N];
int readin()
{
	int x=0,f=1; char ch=getchar();
	while(ch>'9'||ch<'0') {if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void solve(int head,int tail)
{
	int i,tmp=a[head];
	for (i=head;i<tail;i++)
		a[i]=a[i+1];
	a[tail]=tmp;
	return;
}
void work()
{
	int i,head,tail;
	for (i=2;i<=n;i++)
	{
		head=1; tail=0;
		while(1)
		{
			tail+=i;
			if (tail>=n)
			{
				solve(head,n);
				break;
			}
			solve(head,tail);
			head=tail+1;
		}
	}
	for (i=1;i<n;i++)
		printf("%d ",a[i]);
	printf("%d\n",a[n]);
	return;
}
void read()
{
	int i;
	n=readin();
	for (i=1;i<=n;i++)
		a[i]=i;
	return;
}
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	read();
	work();
	return 0;
}
