#include <iostream>
#include <cstdio>
using namespace std;
const int N=1000001;
int n,need,ans;  int a[N];  long long sum;
int readin()
{
	int x=0,f=1; char ch=getchar();
	while(ch>'9'||ch<'0') {if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void read()
{
	int i;
	n=readin();
	for (i=1;i<=n;i++)
	{
		a[i]=readin();
		sum+=a[i];
	}
	need=sum/n;
	return;
}
void work()
{
	int i,con,tot=0; long long now=0;
	for (i=1;i<=n;i++)
	{
		con=a[i]-need;
		now+=con;
		if (now==0)
		{
		    ans+=tot;
		    tot=0;
		}
		else
			tot++;
	}
	printf("%d\n",ans);
	return;
}
int main()
{
    freopen("A.in","r",stdin);
    freopen("A.out","w",stdout);
	read();
	work();
	return 0;
}
