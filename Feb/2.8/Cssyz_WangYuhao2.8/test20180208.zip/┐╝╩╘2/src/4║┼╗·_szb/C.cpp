#include <iostream>
#include <cstdio>
using namespace std;
const int N=100001;
int n,k,ans; int a[N],l[N],app[N],to[N],last[N];
int readin()
{
	int x=0,f=1; char ch=getchar();
	while(ch>'9'||ch<'0') {if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void read()
{
	int i;
	n=readin(); k=readin();
	for (i=1;i<=n;i++)
	{
		a[i]=readin();
		to[last[a[i]]]=i-1;
		app[a[i]]=i; to[i]=n;
		last[a[i]]=i;
	}
	return;
}
void meng()
{
	int i;
	for (i=1;i<=n;i++)
		if (to[i]<k)
			l[i]++;
	for (i=1;i<=n;i++)
		ans=max(ans,l[i]);
	printf("%d\n",ans);
	return;
}
int main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	read();
	meng();
	return 0;
}
