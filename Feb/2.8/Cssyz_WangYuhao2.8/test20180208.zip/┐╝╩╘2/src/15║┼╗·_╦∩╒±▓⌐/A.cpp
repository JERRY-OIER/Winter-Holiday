#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<iomanip>
#include<ctime>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
#include<sstream>
#include<set>
#include<vector>
#include<queue>
using namespace std;
int a[110000];
int c[110000];
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	int n,s=0;
	cin>>n;
	for(int i=1;i<=n;i++)
		{
			cin>>a[i];
			s+=a[i];
		}
	s=s/n;
	c[0]=0;
	for(int i=1;i<=n-1;i++)
		c[i]=a[i]-s+c[i-1];
	int ans=0;
	for(int i=1;i<=n-1;i++)
		if(c[i]!=0)	ans++;
	cout<<ans;
	return 0;
}

