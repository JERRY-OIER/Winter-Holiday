#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<iomanip>
#include<ctime>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
#include<sstream>
#include<set>
#include<vector>
#include<queue>
using namespace std;
int  f[1100000];
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		f[i]=i;
	int mid,u;
	for(int i=2;i<=n;i++)
		{
			for(int j=1;j<=n;j+=i)
				{
					if(j+i>n)	u=n;
					else		u=j+i-1;
					mid=f[j];
					for(int k=j;k<u;k++)
						f[k]=f[k+1];
					f[u]=mid;
				}
		}
	for(int i=1;i<=n;i++)
		printf("%d ",f[i]);
	
	//cout<<"\n"<<clock()/CLOCKS_PER_SEC;
	
	return 0;
}

