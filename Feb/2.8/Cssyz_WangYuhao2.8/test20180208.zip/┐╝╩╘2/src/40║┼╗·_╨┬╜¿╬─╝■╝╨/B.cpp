#include<cstdio>
#include<cstring>
#define gm 1000001
using namespace std;
int n,x,y;
int pos[gm],who[gm*3];
int c[gm*3],big=0;
int ans[gm];
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
	if(n==1) {putchar('1');return 0;}
	big=n;
	for(int i=1;i<=n;i++)
	pos[i]=who[i]=c[i]=i;
	for(int i=2;i<=n;i++)
	{
		for(int j=0;j<n;j+=i)
		{
			x=who[j+i-1];
			pos[x]+=n-j>=i?i:n-j;
			c[pos[x]]=x;
			if(pos[x]>big) big=pos[x];
		}
		memcpy(who,c,big*4+4);
	}
	for(int i=1;i<=n;i++)
	ans[pos[i]-n+1]=i;
	for(int i=1;i<=n;i++)
	printf("%d ",ans[i]);
	return 0;
}
