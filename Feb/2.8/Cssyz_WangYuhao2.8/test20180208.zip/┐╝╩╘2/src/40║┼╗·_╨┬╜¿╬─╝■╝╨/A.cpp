#include<cstdio>
using namespace std;
int n,ans=0,x,m;
int a[1000001];
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
	    scanf("%d",&a[i]);
	    m+=a[i];
	}
	m/=n;
	for(int i=1;i<n;i++)
	{
		x=a[i]-m;
		if(!x) continue;
		a[i+1]+=x;
		ans++;
	}
	printf("%d",ans);
	return 0;
}
