#include<iostream>
#include<cstdio>
using namespace std;
const int MAXN=1000000+5;
int a[MAXN],mark[MAXN],kind=0;
int main()
{
	int n,k;
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	cin>>n>>k;
	for(int i=0;i<n;i++)
	   {
	   	cin>>a[i];
	   	if(!mark[a[i]])
	   	  {
	   	  	kind++;
	   	  	mark[a[i]]=1;
	   	  }
	   }
	if(kind==k)
	   cout<<0;
	else if(kind==1) cout<<n;
	else if(n>7 && kind!=1) cout<<7;
	else cout<<6;
	return 0;
}
