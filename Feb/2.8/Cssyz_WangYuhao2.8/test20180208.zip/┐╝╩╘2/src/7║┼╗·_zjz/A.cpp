#include<iostream>
#include<cstdio>
using namespace std;
int num[1000005];
int main()
{
	int N,std,ans=0;
	long long int sum=0;
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	cin>>N;
	for(int i=1;i<=N;i++)
	    {
	    	cin>>num[i];
	    	sum+=num[i];
	    }
	std=sum/N;
	for(int i=1;i<N;i++)
	   {
	   	if(num[i]!=std) 
	   	  {
	   	  	int temp=std-num[i];
	   	  	num[i+1]-=temp;
	   	  	ans++;
	   	  }
	   }
	cout<<ans;
	return 0;
}
