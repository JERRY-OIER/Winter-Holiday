#include<iostream>
//#include<ctime>
#include<cstdio>
#include<cstdlib>
using namespace std;
int q[1000005];
int main()
{
	int n,j,temp,k;
	//int t=clock();
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	   q[i]=i;
	for(int i=2;i<n;i++)
	   {
	   	for(j=1;j<=n-i+1;j+=i)
	   	   {
	   	   	temp=q[j];
	   	   	  for(k=j+1;k<=j+i-1;k++)
	   	   	     q[k-1]=q[k];
	   	   	q[j+i-1]=temp;
	   	   //	m=j;
	   	   }
	   	if(j-1<n)
	   	  {
	   	  	temp=q[j];
	   	  	for(k=j+1;k<=n;k++)
	   	   	     q[k-1]=q[k];
	   	   	q[n]=temp;
	   	  }
	   }
	for(int i=2;i<=n;i++)
	   cout<<q[i]<<' ';
	cout<<q[1];
//	cout<<'\n'<<clock()-t;
	return 0;
}
