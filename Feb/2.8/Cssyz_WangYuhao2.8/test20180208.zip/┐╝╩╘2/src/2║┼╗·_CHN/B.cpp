#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
#include<iostream>
#include<ctime>
using namespace std;
int minn(int a,int b) {if(a<b) return a; return b;}
int n;
int a[1000005];
void turn(int pos,int k)
{
	int h=a[pos];
	int tail=minn(n,pos+k-1);
	memcpy(a+pos,a+pos+1,sizeof(a[0])*(tail-pos+1));
	a[tail]=h;
}
void print()
{
	for(int i=1;i<=n;i++) cout<<a[i]<<" ";
	cout<<endl;
}
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) a[i]=i;
	for(int i=2;i<=n;i++)
	{
		int pos=1;
		while(pos<n) {turn(pos,i); pos+=i;}
	}
	print();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
