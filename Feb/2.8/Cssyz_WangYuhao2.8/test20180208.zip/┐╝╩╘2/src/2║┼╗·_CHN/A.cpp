#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
#include<iostream>
using namespace std;
int maxx(int a,int b) {if(a>b) return a; return b;}
int n;
int a[1000005];
long long fs[1000005];
long long sum=0;
long long int ratio;
int f1[1000005];
int f2[1000005];
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {scanf("%d",&a[i]); sum+=a[i]; fs[i]=fs[i-1]+a[i];}
	ratio=sum/n;
	int last=0;
	for(int i=1;i<=n;i++)
	{
		f1[i]=f1[i-1];
		if(fs[i]-fs[last]==ratio*(i-last)) {last=i; f1[i]++;}
	}
	last=n;
	for(int i=n-1;i>=1;i--)
	{
		f2[i]=f2[i+1];
		if(fs[last]-fs[i]==ratio*(last-i)) {last=i; f2[i]++;}
	}
	int lop=0;
	for(int i=1;i<=n;i++) lop=maxx(lop,f1[i]+f2[i]);
	printf("%d",n-lop);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
