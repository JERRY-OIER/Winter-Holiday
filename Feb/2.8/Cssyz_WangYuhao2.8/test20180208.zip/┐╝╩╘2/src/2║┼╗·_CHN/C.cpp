#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
#include<iostream>
using namespace std;
int maxx(int a,int b) {if(a>b) return a; return b;}
int n,m;
int a[5005];
int f[5005];
int first[5005];
int last[5005];
void update(int k)
{
	int start=first[k];
	int end=last[k];
	static bool used[5005];
	for(int pos=first[k];pos<=last[k]-1;pos++)
	{
		memset(used,0,sizeof(used));
		int num=0;
		int ass=0;
		for(int i=pos;i<=last[k];i++)
		{
			if(a[i]==k) num++;
			else
			{
				if(!used[a[i]]) {used[a[i]]=true; ass++;}
			}
			f[ass]=maxx(f[ass],num);
		}
	}
}
int main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		if(first[a[i]]==0) first[a[i]]=i;
		last[a[i]]=i;
	}
	if(n<=5000)
	{
		for(int k=1;k<=n;k++) if(first[k]) update(k);
	}
	printf("%d",f[m]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
