#include <iostream>
#include <cstdio>
using namespace std;
int n, arr[1000001];
int main(){
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);
	scanf("%d", &n);
	int p;
	for(int i=0;i<n;i++){
		p=i;
		for(int j=2;j<=n;j++){
			if(n-p/j*j-1>=j)
				p=p/j*j+(p%j+j-1)%j;
			else{
				int k=n-p/j*j;
				p=p/j*j+(p%j+k-1)%k;
			}
		}
		arr[p]=i+1;
	}
	for(int i=0;i<n-1;i++)
		printf("%d ", arr[i]);
	printf("%d\n", arr[n-1]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}