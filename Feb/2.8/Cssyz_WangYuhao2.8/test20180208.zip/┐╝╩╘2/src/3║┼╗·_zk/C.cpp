#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n, k, arr[100001], cc, couc[100001], q[100001], ans;
bool usedc[100001];
int main(){
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for(int i=1;i<=n;i++){
		scanf("%d", &arr[i]);
		usedc[arr[i]]=1;
	}
	int l=1, r=0;
	for(int j=1;j<=n;j++){
		if(!couc[arr[j]])
			cc++;
		couc[arr[j]]++;
		q[++r]=j;
		while(cc>k+1){
			couc[arr[q[l]]]--;
			if(!couc[arr[q[l]]])
				cc--;
			l++;
		}
		ans=max(ans, couc[arr[j]]);
	}
	printf("%d\n", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}