#include <iostream>
#include <cstdio>
using namespace std;
int n, suf[1000001], avg, ans;
void div(int l, int r){
	if(r-l==1){
		if(suf[r]-suf[l]!=suf[l]-suf[l-1])
			suf[l]=suf[l-1]+avg, suf[r]=suf[l]+avg, ans++;
		return;
	}
	int tot=suf[r]-suf[l-1];
	int m;
	for(m=l;m<=r;m++)
		if(suf[m]-suf[l-1]<=tot/2&&suf[r]-suf[m]<=tot/2)  break;
		
	if(suf[m-1]!=avg*(m-1)){
		if(avg>suf[m-1]-suf[m-2]) suf[m-1]=suf[m-2];
		else suf[m-1]=avg*(m-1);
		ans++;
	}
	if(suf[r]-suf[m]!=avg*(r-m)){
		if(avg>suf[m+1]-suf[m]) suf[m+1]=suf[m];
		else suf[m]=suf[r]-avg*(r-m);
		ans++;
	}
	div(l, m-1); div(m+1, r);
}
int main(){
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);
	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		scanf("%d", &suf[i]);
		suf[i]+=suf[i-1];
	}
	avg=suf[n]/n;
	div(1, n);
	printf("%d\n", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
