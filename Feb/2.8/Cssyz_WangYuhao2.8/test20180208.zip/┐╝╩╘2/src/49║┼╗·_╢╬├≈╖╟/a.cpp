#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
int n;
long long sum=0ll;
int a[1000020];
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
	    scanf("%d",&a[i]);
	    sum+=a[i];
	}
	sum=sum/n;
	for(int i=1;i<=n;i++){
		a[i]=a[i]-sum;
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		if(!a[i])
		   continue;
		a[i+1]+=a[i];
		a[i]=0;
		ans++;
	}
	printf("%d",ans);
	fclose(stdin);fclose(stdout);
return 0;
}
