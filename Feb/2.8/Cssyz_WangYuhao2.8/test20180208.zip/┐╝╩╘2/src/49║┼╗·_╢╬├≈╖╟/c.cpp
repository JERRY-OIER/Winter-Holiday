#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int n,m;
int ans=-2147483647;
int maxn=-2147483647;
int quantity[100020];
struct fuck{
	int num,k;
};
bool b[100020];
int a[100020];
fuck you[100020];
inline bool cmp(fuck myself,fuck herself){
	return myself.k<herself.k;
}
inline void count(){
	int k=0,num=0;;
	for(int i=1;i<=n;i++){
		if(b[a[i]])
		   continue;
		if(a[i]==k){
			num++;
			continue;
		}
		ans=max(ans,num);
		num=1;
		k=a[i];
	}
	ans=max(ans,num);
}
bool check(){
	int maxx=-2147483647;
	for(int i=1;i<=maxn;i++){
		if(b[i])
		   continue;
		maxx=max(maxx,quantity[i]);
	}
	if(maxx<ans)
	  return true;
	return false;
}
void dfs(int num){
	if(num==0){
		count();
		return;
	}
	if(check())
	   return;
	for(int i=maxn;i>=1;i--){
		if(b[i])
		   continue;
		b[i]=true;
		dfs(num-1);
		b[i]=false;
	}
}
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	memset(b,false,sizeof(b));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
	    scanf("%d",&you[i].k);
	    you[i].num=i;
	}
	sort(you+1,you+n+1,cmp);
	int k=0;
	for(int i=1;i<=n;i++){
		if(you[i].k==you[k].k){
			a[you[i].num]=a[you[k].num];
		    quantity[a[you[i].num]]++;
			continue;
		}
		a[you[i].num]=i;
		maxn=max(maxn,a[you[i].num]);
		k=i;
		quantity[a[you[i].num]]++;
	}
	/*for(int i=1;i<=maxn;i++){
		   cout<<quantity[i]<<" ";
	}*/
	for(int i=maxn;i>=1;i--){
		b[i]=true;
		dfs(m-1);
		b[i]=false;
	}
	printf("%d",ans);
	fclose(stdin);fclose(stdout);
return 0;
}
