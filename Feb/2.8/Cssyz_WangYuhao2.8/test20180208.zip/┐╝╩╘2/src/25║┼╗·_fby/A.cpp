#include<cstdio> 
#include<cstdlib> 
#include<cmath> 
#include<ctime> 
#include<algorithm> 
#include<cstring> 
#include<string> 
#include<iostream> 
#include<iomanip> 
#include<vector> 
#include<map> 
#include<set> 
#include<functional> 
#include<sstream> 
#include<iterator>  
#include<queue> 
using namespace std;
int n,ans;
long long a[1231234];
long long s;
int main() 
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%I64d",&a[i]);
		s+=a[i];
	}
	s/=n;
	for(int i=1;i<=n;i++) a[i]=a[i]-s;
	for(int i=1;i<=n;i++)
	{
		if(a[i]) 
		{
			a[i+1]+=a[i];
			ans++;
		}
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
    return 0; 
}

