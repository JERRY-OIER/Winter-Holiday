  #include<cstdio> 
#include<cstdlib> 
#include<cmath> 
#include<ctime> 
#include<algorithm> 
#include<cstring> 
#include<string> 
#include<iostream> 
#include<iomanip> 
#include<vector> 
#include<map> 
#include<set> 
#include<functional> 
#include<sstream> 
#include<iterator>  
#include<queue> 
using namespace std;
int n;
int a[1231234];
int main() 
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
if(n<=15000)
{
	for(int i=1;i<=n;i++)
	{
    	int k=i;
		for(int j=2;j<=n;j++)
		{
			if(k%j==1)	k=min(k+j-1,n);
			else k--;
		}
		a[k]=i;
	}
	for(int i=1;i<=n;i++) printf("%d ",a[i]);
}
else
{
	for(int i=1;i<=n;i++)
	{
    	int k=i;
		for(int j=2;j<=n;j++)
		{
			if(k%j==1)	k=min(k+j-1,n);
			else 
			{
				if(k<=j)
				{
					if(n-j+1>=k)
					{   
				    	j=j+k-2;
						k=1;
					}
					else
					{
						k-=n-j+1;
						break;
					}
				}
				else
				{
					k--;
				}
			}
		}
		a[k]=i;
	}
	for(int i=1;i<=n;i++) printf("%d ",a[i]);
}
	fclose(stdin);
	fclose(stdout);
    return 0; 
}

