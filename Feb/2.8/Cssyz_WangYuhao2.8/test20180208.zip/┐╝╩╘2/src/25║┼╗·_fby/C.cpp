#include<cstdio> 
#include<cstdlib> 
#include<cmath> 
#include<ctime> 
#include<algorithm> 
#include<cstring> 
#include<string> 
#include<iostream> 
#include<iomanip> 
#include<vector> 
#include<map> 
#include<set> 
#include<functional> 
#include<sstream> 
#include<iterator>  
#include<queue> 
using namespace std;
int n,k;
int a[121234];
int main() 
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	srand(unsigned(time(0)));
	scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++) 
	{
	   scanf("%d",&a[i]);
    }
    int t=rand()%n+1;
    cout<<t;
	fclose(stdin);
	fclose(stdout);
    return 0; 
}

