#include<cstdio>
#define MAX 1000010
using namespace std;
int n;
struct Alice
{
	int fa,son;
}a[MAX];
int find(int j,int i)
{
	if(i-1==0 || j==0) return j;
	return find(a[j].son,i-1);
}
int search(int n,int k)
{
	if(k==0) return n;
	return search(a[n].fa,k-1);
}
void Print()
{
	for(int i=a[0].son;i!=n+1;i=a[i].son) printf("%d ",i);
}
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		a[i].fa=i-1;
		a[i].son=i+1;
	}
	a[0].son=1;
	a[n+1].fa=n;
	for(int i=2;i<=n;i++)
	{
		int mark=0;
		for(int j=a[0].son;j!=n+1;j=a[j].son)
		{
			int fa=find(j,i);
			int son=a[fa].son;
			if(fa==n+1 || fa==0) 
			{
				mark=j;
				break;
			}
			a[a[j].son].fa=a[j].fa;
			if(a[j].fa==0) a[0].son=a[j].son;
			else a[a[j].fa].son=a[j].son;
			a[j].fa=fa;
			a[son].fa=j;
			a[fa].son=j;
			a[j].son=son;
			if(son==n+1) a[n+1].fa=j;
		}
		if(mark!=0 && n%i>1)
		{
			a[a[mark].fa].son=a[mark].son;
			a[a[mark].son].fa=a[mark].fa;
			a[mark].fa=a[n+1].fa;
			a[a[n+1].fa].son=mark;
			a[mark].son=n+1;
			a[n+1].fa=mark;
		}
	}
	Print();
	return 0;
}
