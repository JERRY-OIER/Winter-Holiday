#include<cstdio>
#define MAX 1000100
using namespace std;
long long n,a[MAX],average,num;
long long mx;
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) 
	{
		scanf("%lld",&a[i]);
		mx=mx+a[i];
	}
	average=mx/n;
	for(int i=1;i<=n;i++)
		if(a[i]!=average)
		{
			if(i+1<=n) a[i+1]=a[i+1]+a[i]-average;
			a[i]=average;
			num++;
		}
	printf("%lld",num);
	return 0;
}
