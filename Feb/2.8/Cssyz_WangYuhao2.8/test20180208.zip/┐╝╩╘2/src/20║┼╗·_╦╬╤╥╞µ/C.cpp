#include<cstdio>
#define INF 100010
using namespace std;
int n,k,a[INF],b[INF],mx;
int main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	scanf("%d%d",&n,&k);
	int m=n;
	for(int i=1;i<=n;i++) b[i]=1;
	for(int i=1;i<=n;i++) 
	{
	    scanf("%d",&a[i]);
	    if(a[i]==a[i-1]) 
		{
			b[a[i-1]]++;
		}
	    i--;
	    n--;
	    if(b[i]>mx) mx=b[i];
	}
	if(k==n) printf("0"); 
	else if(k==n-1) printf("%d",mx);
	else printf("����");
	return 0;
}
