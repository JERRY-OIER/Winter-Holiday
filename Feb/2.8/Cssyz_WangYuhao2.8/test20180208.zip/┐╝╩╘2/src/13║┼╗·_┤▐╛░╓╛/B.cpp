#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<iomanip>
#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
#include<ctime>
using namespace std;
int lowbit(int x)
{
	return x&(-x);
}
int a[1000100];
int c[1000100];
int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	int n;
	cin>>n;
	
    if(n==1)  {cout<<1;return 0;}
    else if(n==2)  {cout<<2<<" "<<1;  return 0;}
    else if(n==3)   {cout<<1<<" "<<3<<" "<<2;  return 0;}
    for(int i=1;i<=n;i++)   a[i]=i;
	for(int i=2;i<=n;i++)
    {
    	int top=0;
    	int p=n/i,pp=n%i;
       for(int j=1;j<=p*i;j++)
        {
           top++;
           if(top==1)  c[j+i-1]=a[j];
           else        c[j-1]=a[j];
           if(top==i)  top=0;  
        }
        for(int j=1;j<=pp;j++)
        {
        	if(j==1)  c[n]=a[p*i+1];
        	else      c[j+p*i-1]=a[j+p*i];
        }
        for(int j=1;j<=n;j++)
        {
        	a[j]=c[j];
        }
    }
    for(int i=1;i<=n;i++)
       printf("%d ",a[i]);
	return 0;
	}
	
	
