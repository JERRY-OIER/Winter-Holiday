#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<iomanip>
#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
#include<ctime>
using namespace std;
int n,k,num;
int a[1000010];
int b[1000101];
int d[1000101];
int ans=0;
 void dfs(int x,int p)
{
 	if(p==k)   
 	{
 		int sum=0;
 		for(int i=1;i<=n;i++)
 		{
 			if(a[i]==a[i-1] && d[a[i]]==0&&d[a[i-1]]==0)  sum++;
			 else  sum=0;   
			 if(sum>ans)  ans=sum;
 		}
 		return;
 	}
 	else
 	{
 	  for(int i=1;i<=n;i++)
 	  {
 	    if(a[i]==0)  d[a[i]]=1;
 	    dfs(a[i],p+1); d[a[i]]=0;
 	   }
     }
 }
int main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)   
	{
	  scanf("%d",&a[i]);
	  if(b[a[i]]==0)   num++;
	  b[a[i]]++;  
    }
    if(num==n)  {cout<<1;return 0;}
    else if(num==1)   {cout<<0;return 0;}
    else if(num==2&&k==1)   { int maxx=-1;
	                            for(int i=1;i<=n;i++)
                                  if(b[a[i]]>maxx)   
    	                             maxx=b[a[i]];  cout<<maxx;return 0;}
    for(int i=1;i<=n;i++)
    {
    d[a[i]]=1;
	dfs(a[i],0);
	d[a[i]]=0;
	}
    cout<<ans;
	return 0;
}
