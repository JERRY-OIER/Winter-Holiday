#include <cstdio>
#include <cstring>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#define rand() (rand()*rand()+rand())
using namespace std;
const int mod =1000000;
int main()
{
	srand((unsigned)time(NULL));
	char s[100];
	for(int i=1;i<=2;i++)
	{
		sprintf(s,"data%d.in",i);
		freopen(s,"w",stdout);
		
		int n=10;long long all=n*i*1000,sum=0;
		cout<<n<<endl;
		for(int k=1;k<=n-1;k++){
			long long x=rand()%(i*1000)+1;
			if(rand()%3==0)	printf("%d ",1000*i*k-sum),sum+=1000*i*k-sum;
			else printf("%d ",x),sum+=x;
		}
		printf("%d\n",all-sum);
		fclose(stdout);
		sprintf(s,"std.exe <data%d.in >data%d.out",i,i);
		system(s);
	}
	for(int i=3;i<=5;i++)
	{
		sprintf(s,"data%d.in",i);
		freopen(s,"w",stdout);
		
		int n=5000;long long all=n*i*1000,sum=0;
		cout<<n<<endl;
		for(int k=1;k<=n-1;k++){
			long long x=rand()%(i*1000)+1;
			if(rand()%3==0)	printf("%d ",1000*i*k-sum),sum+=1000*i*k-sum;
			else printf("%d ",x),sum+=x;
		}
		printf("%d\n",all-sum);
		fclose(stdout);
		sprintf(s,"std.exe <data%d.in >data%d.out",i,i);
		system(s);
	}
	for(int i=6;i<=10;i++)
	{
		sprintf(s,"data%d.in",i);
		freopen(s,"w",stdout);
		
		int n=1000000;long long all=(long long)n*i*100,sum=0;
		cout<<n<<endl;
		for(int k=1;k<=n-1;k++){
			long long x=rand()%(i*100)+1;
			if(rand()%3==0)	printf("%d ",100*i*k-sum),sum+=100*i*k-sum;
			else printf("%d ",x),sum+=x;
		}
		cout<<all-sum<<endl;
		printf("%d\n",all-sum);
		fclose(stdout);
		sprintf(s,"std.exe <data%d.in >data%d.out",i,i);
		system(s);
		fclose(stdout);
		sprintf(s,"std.exe <data%d.in >data%d.out",i,i);
		system(s);
	}
}
