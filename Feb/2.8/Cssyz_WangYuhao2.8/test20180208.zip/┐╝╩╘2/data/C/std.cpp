#include <map>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int N = 100000;
map <int, int> hash;
int a[N];

int main()
{
	ios::sync_with_stdio(false);

	int n,k;cin >> n >> k;
	for(int i = 1 ; i <= n ; i ++)
		cin >> a[i];
	fclose(stdin);
	int num_col = 0, ans = -1, j = 0;
	for(int i = 1 ; i <= n ; i ++)
	{
		if(hash[a[i]] ++ == 0)  num_col ++;
		for(;num_col >k + 1; j ++)
			if(-- hash[a[j]] == 0)
				num_col --;
		ans = max(ans, hash[a[i]]);
	}
	cout << ans << endl;
	return 0;
}
