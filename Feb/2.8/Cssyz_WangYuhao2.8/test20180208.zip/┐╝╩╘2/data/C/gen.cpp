#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define rand() (rand()*rand()+rand())
using namespace std;
int main()
{
	srand((unsigned)time(0x0));
	char s[100];
	for(int i=1;i<=3;i++)
	{
		sprintf(s,"data%d.in",i);
		freopen(s,"w",stdout);
		
		int n=1000,c=10,k=rand()%c+1;

		cout<<n<<' '<<k<<endl;
		for(int i=1;i<=n;i++)
			printf("%d%c",rand()%c+1,i==n?'\n':' ');

		fclose(stdout);
		sprintf(s,"std.exe <data%d.in >data%d.out",i,i);
		system(s);
	}
	for(int i=4;i<=7;i++)
	{
		sprintf(s,"data%d.in",i);
		freopen(s,"w",stdout);
		
		int n=100000,c=rand()%91+10,k=rand()%c+1;

		cout<<n<<' '<<k<<endl;
		for(int i=1;i<=n;i++)
			printf("%d%c",rand()%c+1,i==n?'\n':' ');

		fclose(stdout);
		sprintf(s,"std.exe <data%d.in >data%d.out",i,i);
		system(s);
	}
	for(int i=8;i<=10;i++)
	{
		sprintf(s,"data%d.in",i);
		freopen(s,"w",stdout);
		
		int n=100000,c=5-(i-6),k=c-1;

		cout<<n<<' '<<k<<endl;
		for(int i=1;i<=n;i++)
			printf("%d%c",rand()%c+1,i==n?'\n':' ');

		fclose(stdout);
		sprintf(s,"std.exe <data%d.in >data%d.out",i,i);
		system(s);
	}
}
