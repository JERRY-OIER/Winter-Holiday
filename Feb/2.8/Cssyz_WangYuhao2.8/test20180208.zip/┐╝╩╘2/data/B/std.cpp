#include <cstdio>
#include <cstring>
#include <algorithm>
#define N 1001000
using namespace std;
int f[N<<1],n;
int main()
{
	int i,j,k;
	int x,y;
	scanf("%d",&n);
	for(i=1;i<=n;i++)f[i]=i;
	for(i=2;i<=n;i++)
	{
		y=n+i-1;
		x=(n-1)/i*i+i-1;
		while(x>0)f[y]=f[x],y=x,x-=i;
	}
	for(i=n;i<2*n;i++)printf("%d ",f[i]);
	return 0;
}
