#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int main()
{
	int a[]={0,1,5,20,100,999,1000,495883,903458,923849,1000000};
	char s[100];
	for(int i=1;i<=10;i++)
	{
		sprintf(s,"data%d.in",i);
		freopen(s,"w",stdout);
		printf("%d\n",a[i]);
		fclose(stdout);
		sprintf(s,"std.exe <data%d.in >data%d.out",i,i);
		system(s);
	}
	return 0;
}
