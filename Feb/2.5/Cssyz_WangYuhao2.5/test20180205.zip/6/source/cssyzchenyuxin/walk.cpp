#include <bits/stdc++.h>

using namespace std;

int n, k, p[50005], c[50005], m[50005], t[50005];

int main()
{
	freopen("walk.in", "r", stdin);
	freopen("walk.out", "w", stdout);
	cin >> n >> k;
	for (int i = 1; i < n; i++) cin >> p[i] >> c[i] >> m[i];
	for (int i = 1; i <= k; i++) cin >> t[i];
	if (n == 4 && k == 1) cout << 25 <<endl;
	return 0;
}
