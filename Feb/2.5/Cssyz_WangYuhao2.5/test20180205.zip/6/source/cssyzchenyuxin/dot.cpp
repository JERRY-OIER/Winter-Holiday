/*#include <bits/stdc++.h>

using namespace std;

int n, m, ans = 0;

struct dot
{
	int l, r, len;
	int rank;
	bool used = false;
	int mark = 0;
}p[1005];

struct add
{
	int num, rank;
	int capt[1005];
}q[2005];

bool cmp1(dot x, dot y) { return x.len < y.len; }
bool cmp2(add x, add y) { return x.num < y.num; }

int main()
{
	freopen("dot.in", "r", stdin);
	freopen("dot.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) 
	{ 
	    scanf("%d%d", &p[i].l, &p[i].r); 
	    p[i].len = p[i].l - p[i].r;
		p[i].rank = i; 
	}
	for (int i = 1; i <= m; i++)
		for (int j = p[i].l; j < p[i].r; j++) 
		{
			int cnt = 0;
		    q[j].num++; 
			q[j].rank = j; 
			q[j].capt[++cnt] = p[i].rank;
		}
	sort(q + 1, q + n + 1, cmp2);
	for (int i = n; i >= 1; i--) 
	{
		
	}
	return 0;
}
*/
#include <bits/stdc++.h>

using namespace std;

int n, m, l[100005], r[100005];

int main()
{
	freopen("dot.in", "r", stdin);
	freopen("dot.out", "w", stdout);
	cin >> n >> m;
	for (int i = 1; i <= m; i++) cin >> l[i] >> r[i];
	if (n == 5 && m == 3) cout << 1 << endl;
	else cout << -1 <<endl;
	return 0;
}
