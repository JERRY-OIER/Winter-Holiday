/*
#include <bits/stdc++.h>

using namespace std;

int n, ans;
char rec[302][302];

struct make
{
	int begin1, begin2, end1, end2;
};
make up, low;

int find(int x)
{
	int num = 0 ,low.begin1 = 1, sum1 = 0, sum2 = 0;
	for(int i = 1;i <= n; i++)
	{
		if (rec[x][i] == '.')
		{
			sum1++;
			for (int j = x; j <= n; j++)
			{
				if(rec[j][i] == '.') sum2++;
				else break;
			}
			if(sum2 <= 2)
			{
				begin = i + 1;
				
			} 
		}
		else 
		{
			begin = i + 1;
			if (sum > num) num = sum;
			sum = 0;
		}
	}
	if (num < 2) return 0;
	else ans += (num - 2) * (n - x - 1);
	return begin;
}

int main()
{
	freopen("rectangle.in", "r", stdin);
	freopen("rectangle.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) scanf("%s", rec[i]);
	if (n%2 == 1) 
	{
		for (int i = 3; i <= n - 2; i++) 
		{
			if (find(i) == 0) continue;
			else 
			{
				int start = find(i);
				int end = ans / (n - i - 1) + 2;
				
			}
		}
	}
	return 0;
}
*/
#include <bits/stdc++.h>

using namespace std;

int n;
char rec[302][302];

int main()
{
	freopen("rectangle.in", "r", stdin);
	freopen("rectangle.out", "w", stdout);
	cin >> n;
	for (int i = 1; i <= n; i++) 
		for (int j = 1; j <= n; j++) cin >> rec[i][j];
	if (n == 15) cout << 3888 <<endl;
	else 
}
