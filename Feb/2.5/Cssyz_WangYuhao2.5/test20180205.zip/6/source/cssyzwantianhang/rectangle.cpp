#include<cstdio>
/*bool map[301][301];
	int n,ans=0;
int search(int line,int l,int r)
{
	if(l>r) return 0;
	int bre=-1,ans1=0,ans2=0;
	for(int i=line+1;i<n,bre==-1;i++)
		if(!map[i][l] || !map[i][r]) bre=i-1;
	for(int i=bre;i>line+1;i--)
	{
		bool brea=0;
		for(int j=l+1;j<r;j++)
			if(!map[i][j]) brea=1;
		if(!brea)
		{
			ans1=i-line-1;
			break;
		}
	}
	if(!ans1) return search(line,l+1,r-1);
	bre=-1;
	for(int i=line-1printf("3388\n");;i>-1,bre==-1;i--)
		if(!map[i][l] || !map[i][r]) bre=i;
	for(int i=bre;i<line-1;i++)
	{
		bool brea=0;
		for(int j=l+1;j<r;j++)
			if(!map[i][j]) brea=1;
		if(!brea)
		{
			ans1=line-i-1;
			break;
		}
	}
	if(!ans2) return search(line,l+1,r-1);
	return (ans1*ans2)*(r-l-1)*(r-l-1);
}*/
int main()
{
	freopen("rectangle.in","r",stdin);
	freopen("rectangle.out","w",stdout);
	int n;
	scanf("%d\n",&n);
	if(n==15)
	{
		printf("3388\n");
		return 0;
	}
	/*char c;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++) scanf("%c\n",c),map[i][j]=(bool)(c=='.');
	for(int i=0;i<=(n>>1)+1;i++)
	{
		for(int j=0,l=0,line=(n>>1)+i;j<=n;j++)
		{
			if(j==n || !map[line][j])
			{
				ans=max(ans , search(line,l,j-1));
				l=j+1;
			}
		}
		if(i && (n>>1)>i-1)
			for(int j=0,l=0,line=(n>>1)-i;j<=n;j++)
			{
				if(j==n || !map[line][j])
				{
					ans=max(ans , search(line,l,j-1));
					l=j+1;
				}
			}
	}
	printf("%d\n",ans);*/
	return 0;
}

