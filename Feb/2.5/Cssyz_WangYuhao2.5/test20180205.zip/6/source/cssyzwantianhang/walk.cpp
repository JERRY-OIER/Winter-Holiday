#include<cstdio>
//#include<queue>
//#include<vector>
#include<algorithm>
const int MOD=50001;
struct ask
{
	int time;
	int m;
	long long ans;
	ask():ans(0) {}
}ak[MOD];
struct dot
{
	long long cow;
	int cap;
}dt[MOD];
int nt[MOD],to[MOD],bian[MOD],p;
bool bl,cut[MOD];
//std::priority_queue<int , std::vector<int> ,std::greater<int> > q;
bool cmp(ask x,ask y)
{
	return bl?x.m<y.m:x.time<y.time;
}
void add(int x,int y)
{
	nt[++p]=bian[x];
	to[p]=y;
	bian[x]=p;
}
long long dfs(int x)
{
	dot &now=dt[x];
	for(int i=bian[x];i;i=nt[i])
	{
		if(!cut[to[i]]) now.cow+=dfs(to[i]);
	}
	if(!now.cow)
	{
		cut[x]=1;
		return 0;
	}
	int cha=now.cap<now.cow ? now.cap : now.cow;
	now.cow-=cha;
	return cha;
}
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	int n,qus;
	scanf("%d %d\n",&n,&qus);
	for(int i=2,t;i<=n;i++) scanf("%d %lld %d\n",&t,&dt[i].cow,&dt[i].cap),add(t,i);
	dt[1].cap=1000000000;
	for(int i=1;i<=qus;i++)
	{
		scanf("%d",&ak[i].time);
		ak[i].m=i;
	}
	bl=0;
	std::sort(ak+1,ak+qus+1,cmp);
	for(int i=1,j=1;i<=ak[qus].time;i++)
	{
		if(cut[1])
		{
			for(j++;j<=qus;j++) ak[j].ans+=ak[j-1].ans;
			break;
		}
		ak[j].ans+=dfs(1);
		if(i==ak[j].time) ak[++j].ans+=ak[j-1].ans;
	}
	bl=1;
	std::sort(ak+1,ak+qus+1,cmp);
	for(int i=1;i<=qus;i++) printf("%lld\n",ak[i].ans);
	return 0;
}
