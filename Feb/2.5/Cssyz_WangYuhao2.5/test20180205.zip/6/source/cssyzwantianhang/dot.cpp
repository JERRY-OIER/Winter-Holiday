#include<cstdio>
#include<algorithm>
struct area
{
	int l;
	int r;
	int cl;
	int cr;
};
area a[100010];
bool operator < (area x,area y)
{
	return x.l==y.l?x.r>y.r:x.l<y.l;
}
int main()
{	
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	int n,m;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d %d",&a[i].l,&a[i].r);
		a[i].cl=a[i].l;
		a[i].cr=a[i].r;
	}
	std::sort(a+1,a+m+1);
	for(int i=2;i<=m;i++)
	{
		int j=i-1;
		while(a[i].r<=a[j].r && j)
		{
			a[i-j].cl=a[i].l;
			a[i-j].cr=a[i].r;
			j--;
		}
	}
	int ans=0;
	for(int i=1,line=0;i<=m;i++)
	{
		if(a[i].cr>line)
		{
			ans++;
			line=a[i].r;
		}
	}
	printf("%d\n",ans);
	return 0;
}
