#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m;
int ed,mr,cnt,ans;
struct data{
    int l,r,cnt,bl,br;
}xd[100100],b[100100],nb[100100];
bool cmp(data a,data b)
{
    if(a.r-a.l==b.r-b.l)return a.l<b.l;
    return a.r-a.l<b.r-b.l;
}
bool cmp2(data a,data b)
{return a.l<b.l;}
int main()
{
    freopen("dot.in","r",stdin);
    freopen("dot.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;++i)
        scanf("%d%d",&xd[i].l,&xd[i].r),b[i].cnt=0;
    sort(xd+1,xd+m+1,cmp);
    for(int i=1;i<=m;++i)
    {
        //cout<<xd[i].l<<" "<<xd[i].r<<endl;
        if(b[i].cnt)continue;
        //cout<<xd[i].l<<" "<<xd[i].r<<endl;
        xd[i].bl=xd[i].l;xd[i].br=xd[i].r;
        for(int j=i+1;j<=m;++j)
        {
            if(xd[i].l==xd[j].l&&xd[i].r==xd[j].r)
            {b[j].cnt=1;continue;}
            if((xd[i].l<xd[j].l&&xd[i].r<xd[j].r)
            ||(xd[i].l>xd[j].l&&xd[i].r>xd[j].r))continue;
            xd[i].bl=min(xd[i].bl,xd[j].l);
            xd[i].br=max(xd[i].br,xd[j].r);
            if(!b[j].cnt)
            {
                b[j].cnt=1;
                b[j].l=xd[i].l;
                b[j].r=xd[i].r;
                continue;
            }
            if(xd[i].l<=b[j].r)b[j].r=xd[i].r;
            else
            {
                printf("-1\n");return 0;
            }
        }
        nb[++cnt].l=xd[i].l;nb[cnt].r=xd[i].r;
        nb[cnt].bl=xd[i].bl;nb[cnt].br=xd[i].br;
    }
    if(cnt==1)
    {
        printf("1\n");
        return 0;
    }
    sort(nb+1,nb+cnt+1,cmp2);
    //for(int i=1;i<=cnt;++i)cout<<nb[i].l<<" "<<nb[i].r<<" "<<nb[i].bl<<" "<<nb[i].br<<endl;
    ed=max(nb[1].br+1,nb[2].l);mr=nb[2].br+1;ans=2;
    for(int i=2;i<=cnt;++i)
    {
        if(nb[i].l>ed)
        {
          if(nb[i].r>=mr)
          {
            if(nb[i].bl>ed)
            {
                ans++;
                ed=max(mr,nb[i].l);
                mr=nb[i].br+1;
            }
            else
            {
                ed=max(mr,nb[i].l);
                mr=nb[i].br+1;
            }
          }
          else
          {
            ed=nb[i].l;
            mr=nb[i].br+1;
          }
        }
        else
        {
            mr=nb[i].br+1;
        }
    }
    printf("%d\n",ans);
    return 0;
}
