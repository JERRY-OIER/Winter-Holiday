#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("rectangle.in","r",stdin);
    freopen("rectangle.out","w",stdout);
    cout<<3888<<endl;
    return 0;
}
