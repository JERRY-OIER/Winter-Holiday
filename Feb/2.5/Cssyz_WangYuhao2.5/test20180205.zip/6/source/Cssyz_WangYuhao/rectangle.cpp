#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("rectangle.in","r",stdin);
	freopen("rectangle.out","w",stdout);
	int N;
	cin>>N;
	string s;
	for(int i = 1;i <= N;i ++) cin>>s;
	cout<<3888;
	return 0;
}
