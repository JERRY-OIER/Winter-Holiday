#include <bits/stdc++.h>

#define lrl lr[i].l
#define lrr lr[i].r

using namespace std;

int N, M;

struct xian {
    int l, r;
}lr[100001];

int main() {
    freopen("dot.in", "r", stdin);
    freopen("dot.out", "w", stdout);
    scanf("%d%d", &N, &M);
    for(int i = 1; i <= M; i++)
	scanf("%d%d", &lrl, &lrr);
    if(N <= 10)
	printf("1\n");
    else
	printf("-1\n");
    return 0;
}
