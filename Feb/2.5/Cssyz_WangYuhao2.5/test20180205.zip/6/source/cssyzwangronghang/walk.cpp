#include <bits/stdc++.h>

using namespace std;

int n, k;

int p[50005], c[50005], m[50005];

int t[50005];

int main() {
    freopen("walk.in", "r", stdin);
    freopen("walk.out", "w", stdout);
    scanf("%d%d", &n, &k);
    for(int i = 1; i <= n; i++) {
	scanf("%d%d%d", &p[i], &c[i], &m[i]);
    }
    for(int i = 1; i <= k; i++) {
	scanf("%d", &t[i]);
    }
    for(int i = 1; i <= k ; i++)
	printf("%d\n", (n + k) * t[i]);
    return 0;
}
