#include <iostream>
#include <cstdio>
using namespace std;
int a[500][500], xs[500][500]; 
int top[500][500], back[305][305][305];
int tmp[305][305];
int n;
int main() {
	freopen("rectangle.in", "r", stdin);
	freopen("rectangle.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		char c[305];
		scanf("%s", c + 1);
		for (int j = 1; j <= n; ++j) {
			if (c[j] == '*') a[i][j] = 1;
			//cout << a[i][j] << " ";
		}
		//puts("\n");
	}
	
		//puts("\n");
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n; ++j) {
			xs[i][j] = xs[i][j - 1] + a[i][j];
			//ys[j][i] = ys[j][i - 1] + a[j][i];
		//	cout << xs[i][j] << " ";
		}
		//puts("\n");
	}
	
	for (int i = 1; i <= n; ++i) {
		for (int j = i + 1; j <= n; ++j) {
			top[i][j] = 1;
			tmp[i][j] = n;
		}
	}
	
	//Ԥ���� 
	for (int i = n; i >= 1; --i) {
		for (int j = 1; j <= n; ++j) {
			for (int k = j + 1; k <= n; ++k) {
				if (xs[i][k] - xs[i][j - 1] != 0) {
					if (tmp[j][k] == i) {
						--tmp[j][k];
					} else if (a[i][j] || a[i][k]) {
						tmp[j][k] = i - 1;
					}
					back[i][j][k] = 0;	
				} else back[i][j][k] = tmp[j][k];
			}
		}
	}
	
	/*for (int i = n; i >= 1; --i) {
		cout << i << "#\n";
		for (int j = 1; j <= n; ++j) {
			cout << j << endl;
			for (int k = j + 1; k <= n; ++k) {
				cout << k << " " << back[i][j][k] << "     ";
			}
			cout << endl;
		}
		cout <<  endl;
	}*/
	
	
	
	
	int res = 0;
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n; ++j) {
			for (int k = j + 1; k <= n; ++k) {
				if (xs[i][k] - xs[i][j - 1] != 0) {
					if (top[j][k] == i) {
						++top[j][k];
					} else if (a[i][j] || a[i][k]) {
						top[j][k] = i + 1;
					}
				} else {
					for (int l = j; l >= 1; --l) {
						if (a[i][l] == 1) {
							break;
						}
						for (int x = k; x <= n; ++x) {
							if (a[i][x] == 1) {
								break;
							}
							int tmp = (k - j - 1) * (i - top[j][k] - 1) * (x - l - 1) * (back[i][l][x] - i - 1);
							if (res < tmp) {
								res = tmp;
								//cout << xs[i][k] << " " << xs[i][j - 1] << "\n";
								//printf("%d %d %d %d %d %d\n", i, j, k, l ,x, tmp);
							}
						}
					}
				}
			}
		}
	
	}
	cout << res;
	return 0;
}
