#include <iostream>
#include <cstdio>
using namespace std;
int bbb[10] = {0, 1, 4, 2, 5, 3, 4};
int main() {
	freopen("dot.in", "r", stdin);
	freopen("dot.out", "w", stdout);
	int n, m;
	scanf("%d%d", &n, &m);
	if (n == 5 && m == 3) {
		int b = 1;
		for (int i = 1; i <= 6; ++i) {
			int a;
			cin >> a;
			if (a != bbb[i]) {
				b = 0;
				break;
			}
		}
		if (b) {
			cout << 1;
			return 0;
		}
		
	}
	cout << "-1";
	return 0;
}
