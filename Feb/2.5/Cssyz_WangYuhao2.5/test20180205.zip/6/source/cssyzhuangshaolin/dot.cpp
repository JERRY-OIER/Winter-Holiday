#include<iostream>
#include<cstdio>
using namespace std;
int n,m,add[400001],num[200001],ans,a[100001],b[100001];
bool mark,up;
void update(int x,int l,int r,int nl,int nr)
{
	if(l>=nl&&r<=nr)
	{
		add[x]++;
		return;
	}
	int mid=(l+r)>>1;
	if(nl<=mid)
		update(x*2,l,mid,nl,nr);
	if(nr>mid)
		update(x*2+1,mid+1,r,nl,nr);
}
void ad(int x,int l,int r)
{
	if(l==r)
	{
		num[l]=add[x];
		return;
	}	
	int mid=(l+r)>>1;
	add[x*2]+=add[x];
	add[x*2+1]+=add[x];
	add[x]=0;
	ad(x*2,l,mid);
	ad(x*2+1,mid+1,r);
}
int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&a[i],&b[i]);
		update(1,1,n,a[i],b[i]);
	}
	ad(1,1,n);
	for(int i=1;i<=n;i++)
	{
		if(num[i]==num[i-1])
			continue;
		if(!num[i])
		{
			ans++;
			mark=false;
		}	
		else
		{
			if(!mark)
			{
				mark=true;
				up=true;
				ans++;	
			}
			if(num[i]>num[i-1])
			{
				if(!up)
				{
					printf("-1\n");
					return 0;	
				}
			}	
			else
				up=false;
		}
	}
	printf("%d\n",ans);
	return 0;
}
