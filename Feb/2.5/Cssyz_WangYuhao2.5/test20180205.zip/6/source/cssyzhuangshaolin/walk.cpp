#include<iostream>
#include<cstdio>
#define INF 0x7fffffff
using namespace std;
int n,k,to[10001],ind[10001],st[10001],jsq,end=INF;
long long num[10001],cnt[10001],lim[10001],t,tot;
int main()
{
	int t,x;
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	cin>>n>>k;
	for(int i=2;i<=n;i++)
	{
		scanf("%d%d%d",&to[i],&num[i],&lim[i]);
		ind[to[i]]++;
		tot+=num[i];
	}	
	for(int i=1;i<=n;i++)
		if(!ind[i])
			st[++jsq]=i;
	while(k--)
	{
		scanf("%d",&t);
		if(t>=end)
		{
			printf("%lld\n",tot);
			continue;
		}
		for(int i=1;i<=n;i++)
			cnt[i]=num[i];
		for(int i=1;i<=jsq;i++)
		{
			x=st[i];
			while(x!=1)
			{
				cnt[to[x]]+=min(cnt[x],t*lim[x]);
				x=to[x];
			}
		}
		printf("%lld\n",cnt[1]);
		if(cnt[1]==tot)
			end=min(end,t);
	}
	return 0;
}
