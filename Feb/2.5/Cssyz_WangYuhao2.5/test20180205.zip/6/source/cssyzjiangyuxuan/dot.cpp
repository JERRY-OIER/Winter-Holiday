#include<iostream>
#include<cstdio>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
int R,n,m,q[101001][2],cnt,lastl=INF,lastr=-INF;
struct d
{
	int l,r;
}a[101001];
bool cmp(d u,d v){ return u.l<v.l||u.l==v.l&&u.r>v.r;}
int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&a[i].l,&a[i].r);
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		if(a[i].l>R)
		{
			R=a[i].r;q[++cnt][0]=a[i].l;
			q[cnt][1]=a[i].r;
		}
		else if(a[i].r<=R)
		{
			if(a[i].r<q[cnt][0])
			{
				if(lastr<a[i].l||lastl>a[i].r)
				{
					printf("-1\n");
					return 0;
				}
				else 
				{
					q[--cnt][0]=max(a[i].l,lastl);
					q[cnt][1]=min(a[i].r,lastr);
					lastr=-INF;
					lastl=INF;
				}
			}
			else if(a[i].l<=q[cnt][0])
			{
				lastl=max(a[i].l,lastl);
				lastr=min(a[i].r,lastr);
				if(lastl>lastr)
				{
					lastl=INF;
					lastr=-INF;
				}
				if(a[i].r<q[cnt][1])
					q[cnt][1]=a[i].r;
			}
			else if(a[i].l<=q[cnt][1])
			{
				q[cnt][0]=a[i].l;
				if(q[cnt][1]>a[i].r) q[cnt][1]=a[i].r;
			}
			else if(a[i].l>q[cnt][1])
			{
				printf("-1\n");
				return 0;
			}
		}
		else
		{
			if(a[i].l<=q[cnt][0])
			{
				if(lastl!=-INF&&lastl<a[i].l)
				{
					int u=lastl,v=lastr;
					lastl=q[cnt][0];
					lastr=q[cnt][1];
					q[cnt-1][0]=u;
					q[cnt-1][1]=min(v,a[i].r);
					q[cnt][0]=lastr+1;
					q[cnt][1]=a[i].r;
				}	
			 	R=a[i].r;
			 }
			else if(a[i].l>q[cnt][1])
			{
				q[++cnt][0]=R;
				q[cnt][1]=R=a[i].r;
			}
			else 
			{
				lastl=a[i].l;
				lastr=q[cnt][1];
				q[cnt][1]=a[i].l-1;
				q[++cnt][0]=R+1;
				q[cnt][1]=a[i].r;
				R=a[i].r;
			}
		}
	}
	printf("%d\n",cnt);
	return 0;
}
