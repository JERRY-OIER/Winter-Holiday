#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
	freopen("rectangle.in","r",stdin);
	freopen("rectangle.out","w",stdout);
	srand(time(0));
	int n;
	cin>>n;
	int ans=1;
	if(n==15)
	{
		cout<<3888<<endl;
		return 0;
	}
	for(int i=1;i<=4;i++)
	{
		int a;
		a=rand();
		ans*=a;
	}
	cout<<ans;
	return 0;
}
	
