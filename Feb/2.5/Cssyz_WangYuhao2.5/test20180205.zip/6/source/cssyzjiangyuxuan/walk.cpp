#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	cout<<25<<endl;
	return 0;
}
