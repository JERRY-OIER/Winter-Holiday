#include <bits/stdc++.h>

using namespace std;

const int N = 50000;

int q, n;
long long res[N + 1];
long long dis[N + 1];
bool book[N + 1];
int tot;
int fi[N + 1];

struct P {
	int to, ne;
	long long v;
}line[N + 1];

struct Q {
	long long t;
	int id;
	
	friend bool operator< (Q a, Q b) {
		return a.t < b.t;
	}
}a[N + 1];

void add(int, int, long long);
long long dfs(int, long long, long long);

int main() {
	freopen("walk.in", "r", stdin);
	freopen("walk.out", "w", stdout);
	scanf("%d%d", &n, &q);
	for(int i = 2; i <= n; i++) {
		int u, v = i, w;
		scanf("%d%lld%d", &u, &dis[i], &w);
		add(u, v, w);
	}
	for(int i = 1; i <= q; i++) {
		scanf("%lld", &a[i].t);
		a[i].id = i;
	}
	sort(a + 1, a + 1 + q);
	long long lt = 0;
	for(int i = 1; i <= q; i++) {
		dfs(1, 0, a[i].t - lt);
		lt = a[i].t;
		res[a[i].id] = dis[1];
	}
	for(int i = 1; i <= q; i++) printf("%lld\n", res[i]);
	return 0;
}

void add(int u, int v, long long w) {
	line[++tot].ne = fi[u];
	fi[u] = tot;
	line[tot].to = v;
	line[tot].v = w;
}

long long dfs(int x, long long maxn, long long t) {
	if(book[x]) return 0;
	for(int i = fi[x]; i; i = line[i].ne) {
		dis[x] += dfs(line[i].to, line[i].v, t);
	}
	long long k = min(dis[x], maxn * t);
	dis[x] -= k;
	if(!dis[x]) book[x] = 1;
	return k;
}
