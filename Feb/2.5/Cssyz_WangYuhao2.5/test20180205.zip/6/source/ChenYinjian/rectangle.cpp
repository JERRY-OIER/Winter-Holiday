 #include <bits/stdc++.h>

using namespace std;

int n;

int main() {
	freopen("rectangle.in", "r", stdin);
	freopen("rectangle.out", "w", stdout);
	srand(time(NULL));
	scanf("%d", &n);
	if(n == 15) {
		printf("3888\n");
		return 0;
	}
	printf("%lld\n", (long long)((long long)(rand() % (n * n) * (rand() % (n * n))) % (long long)(n * n)) * ((long long)(rand() % (n * n) * (rand() % (n * n))) % (long long)(n * n)) / 4);
	return 0;
}
