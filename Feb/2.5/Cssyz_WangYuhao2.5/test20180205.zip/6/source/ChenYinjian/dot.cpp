#include <bits/stdc++.h>

using namespace std;

const int N = 100000;

int n, m;

int main() {
	freopen("dot.in", "r", stdin);
	freopen("dot.out", "w", stdout);
	scanf("%d%d", &n, &m);
	if(n != 5 || m != 3) printf("-1\n");
	else printf("1\n");
	return 0;
}
