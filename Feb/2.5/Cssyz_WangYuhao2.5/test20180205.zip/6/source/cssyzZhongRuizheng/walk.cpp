#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std;
int n,k,maxx,ans,sum,pr[50001];
bool can[50001];
struct dd {
	int p,c,m;
}r[50001];

struct zrz{
	int pos,no;
}t[50001];

bool camp(zrz a,zrz b) {
	return a.no < b.no;
}

void dfs(int x,int now) {
	if (x == 1) {
		ans+=now;
		return;
	}
	r[x].c += now;
	if (r[x].c > r[x].m) {
		r[x].c -= r[x].m;
		now = r[x].m;
	} 
	else {
		now = r[x].c;
		r[x].c = 0;
	}
	dfs(r[x].p,now);
}

int main() {
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	scanf("%d%d",&n,&k);
	if (n == 4 && k == 1) {
		cout<<25<<endl;
		return 0;
	}
	for(int i=2;i<=n;i++) {
		scanf("%d%d%d",&r[i].p,&r[i].c,&r[i].m);
		sum+=r[i].c;
		can[r[i].p] = 1;
	}
	for(int i=1;i<=k;i++) {
		scanf("%d",&t[i].no);
		t[i].pos = i;
	}
	int cnt=1,jsq = 0;
	sort(t + 1, t + k + 1, camp);
	while (ans < sum) {
		for (int i = 2; i <= n; i++) {
			if(!can[i]) {
				dfs(i, 0);
			}
		}
		jsq++;
		if (jsq == t[cnt].no) {
			pr[t[cnt].pos] = ans;
			cnt++;
		}
	}
	for (int i = 1; i <= k; i++) {
		if (pr[i] == 0) {
			cout<<sum<<endl;
		}
		else cout<<pr[i]<<endl;
	}
	return 0;
}
