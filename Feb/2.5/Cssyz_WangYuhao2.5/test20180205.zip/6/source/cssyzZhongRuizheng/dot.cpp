#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std;
int n, m, cf[200001], minn, cnt, ans, pd, now, flag, pos;
bool used[200001];
const int inf = 10000001;
struct dd {
	int st;
	int end;
	int len;
}li[100001];
bool cmp(dd a, dd b) {
	return a.len < b.len;
}
int main() {
	freopen ("dot.in","r", stdin);
	freopen ("dot.out","w", stdout);
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) {
		scanf ("%d%d", &li[i].st, &li[i].end);
		li[i].len = li[i].end - li[i].st + 1;
		cf[li[i].st]++;
		cf[li[i].end + 1]--;
	}
	for (int i = 1; i <= n; i++) {
		cf[i] += cf[i - 1];
		if (cf[i] == 0) ans++;
	}
	sort(li + 1, li + m + 1, cmp);
	while(cnt != m) {
		for (int i = 1; i <= n; i++) {
			if (!used[i]) {
				now = i;
				break;
			}
		}
		minn = inf, flag = 0, pos = 0;
		for (int i = li[now].st; i <= li[now].end; i++) {
			if (cf[i] < minn) {
				for (int j = 1; j <= m; j++) {
					if (j != now) {
						if (li[j].st <= i && li[j].end >= i) {
							if (used[j]) {
								flag = 1;
								break;
							}
						}
					}
				}
				if (flag) continue;
				minn = cf[i];
				pos = i;
			}
		}
		if (minn != inf) {
			ans++;
			for (int i = 1; i <= m; i++) {
				if (li[i].st <= pos && li[i].end >= pos) {
					used[i] = 1;
					cnt++;
				}
			}
		}
		else {
			cout<<"-1\n";
			pd = 1;
			break;
		}
	}
	if (!pd) cout<<ans<<endl;
	return 0;
}
