#include <bits/stdc++.h>
using namespace std;


int N, K;

int main () {
  freopen ("walk.in", "r", stdin);
  freopen ("walk.out", "w", stdout);
  scanf("%d%d", &N, &K);
  int a, b, c, sum = 0;
  for (int i = 1;i < N; ++i) {
    scanf("%d%d%d", &a, &b, &c);
    sum += b;
  }
  printf("%d\n", sum);
  return 0;
}
