#include <bits/stdc++.h>
using namespace std;

int main () {
  freopen ("rectangle.in", "r", stdin);
  freopen ("rectangle.out", "w", stdout);
  printf("3888\n");
  return 0;
}
