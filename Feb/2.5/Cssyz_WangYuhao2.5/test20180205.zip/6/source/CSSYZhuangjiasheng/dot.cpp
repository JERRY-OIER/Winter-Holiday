#include <bits/stdc++.h>
#define MAX_N 100010
using namespace std;
struct node {
  int val, id;
  node() {}
  node (int val_, int id_) : val(val_), id(id_) {}
}q[MAX_N];
struct query {
  int l, r;
  int id;
}qr[MAX_N];

int N, M;
int x[MAX_N][2];  //x[i][0]L, x[i][1]R
int front = 1, rear;

void refresh (int x, int op, int id) {
  while (front < rear && q[front + 1].val < x) {
    q[++front].val = x;
    if (!op) q[front].id = id;
  }
}

void solve () {
  int res = 0;
  for (int i = 1;i <= N; ++i) {
    if (x[i][0]) q[++rear] = node(i, x[i][0]);
    if (!x[i][1]) continue;
    if (q[front].id == x[i][1]) {
      res++;
      refresh(i, q[front].val == qr[x[i][1]].l, x[i][1]);
      continue;
    }
    while (front < rear) {
      if (q[front + 1].id == x[i][1]) {res++; q[++front] = node(i, x[i][1]);break;}
      front++;
    }
    //printf("%d %d %d\n", i, front, rear);
  }
  printf("%d\n", res == 0 ? -1 : res);
}

bool cmp (const query a, const query b) {return a.l == b.l ? a.r > b.r : a.l < b.l;}
int main () {
  freopen ("dot.in", "r", stdin);
  freopen ("dot.out", "w", stdout);
  scanf("%d%d", &N, &M);
  for (int i = 1;i <= M; ++i) 
    scanf("%d%d", &qr[i].l, &qr[i].r);
  sort(qr + 1, qr + M + 1, cmp);
  for (int i = 1;i <= M; ++i) qr[i].id = i;
  for (int i = 1;i <= M; ++i) {
    x[qr[i].l][0] = qr[i].id;
    x[qr[i].r][1] = qr[i].id;
  }
  /*
  for (int i = 1;i <= M; ++i) printf("%d %d %d\n", qr[i].l, qr[i].r, qr[i].id);
  for (int i = 1;i <= N; ++i)
    printf("pos %d lid %d rid %d\n", i, x[i][0], x[i][1]);
  */
  for (int i = 1;i <= N; ++i) {
    if (x[qr[i].l][0] == qr[i].id || x[qr[i].r][1] == qr[i].id) continue;
    if (x[qr[i].l][0] != x[qr[i].r][1]) {printf("-1\n"); return 0;}
  }
  solve();
  return 0;
}
