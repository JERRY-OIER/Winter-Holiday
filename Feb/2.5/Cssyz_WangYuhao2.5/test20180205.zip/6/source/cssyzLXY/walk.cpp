#include <bits/stdc++.h>

using namespace std;

int main() {
	freopen("walk.in", "r", stdin);
	freopen("walk.out", "w", stdout);
	int N;
	int K;
	int ans = 0;
	scanf("%d%d", &N, &K);
	for (int i = 2; i <= N; i++) {
		int P;
		int C;
		int M;
		scanf("%d%d%d", &P, &C, &M);
		ans += C;
	}
	printf("%d\n", ans);
	return 0;
}
