#include <bits/stdc++.h>

using namespace std;
const int MAXM = 100000;

struct Line {
	int l;
	int r;
};

int N;
int M;
int maxPut = 0;
bool book[MAXN + 1];
Line line[MAXM + 1];

bool camp(Line, Line);
void DFS(int);

int main() {
	freopen("dot.in", "r", stdin);
	freopen("dot.out", "w", stdout);
	scanf("%d%d", &N, &M);
	for (int i = 1; i <= M; i++) scanf("%d%d", &line[i].l, &line[i].r);
	sort(line + 1, line + M + 1, camp);
	DFS(1);
	if (maxPut)	printf("%d\n", maxPut);
	else printf("-1\n");
	return 0;
}

bool camp(Line a, Line b) {
	if (a.l == b.l) return a.r < b.r;
	return a.l < b.l;
}

void DFS(int t) {
	//for (int i = 1; i <= N; i++) printf("%d ", book[i]);
	//printf("\n");
	if (t == N + 1) {
		for (int i = 1; i <= M; i++) {
			int have = 0;
			for (int j = line[i].l; j <= line[i].r; j++) {
				if (book[j]) have++;
				if (have >= 2) return;
			}
			if (!have) return ;
		}
		int sumPut = 0;
		for (int i = 1; i <= N; i++) {
			if (book[i]) sumPut++;
		}
		maxPut = max(maxPut, sumPut);
		return ;
	}
	DFS(t + 1);
	book[t] = true;
	DFS(t + 1);
	book[t] = false;
}
