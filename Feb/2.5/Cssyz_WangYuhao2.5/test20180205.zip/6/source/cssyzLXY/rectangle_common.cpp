#include <bits/stdc++.h>

using namespace std;
const int MAXN = 300;

int book[MAXN + 1][MAXN + 1];

int main() {
	freopen("rectangle.in", "r", stdin);
	freopen("rectangle.out", "w", stdout);
	int N;
	scanf("%d", &N);
	for (int i = 1; i <= N; i++) {
		char buff[MAXN + 1];
		scanf("%s", buff);
		for (int j = 0; j < strlen(buff); j++) {
			if (buff[j] == '*') book[i][j + 1] = 1;
		}
	}
	for (int i = N; i >= 1; i--) {
		for (int j = N; j >= 1; j--) 
			book[i][j] += book[i + 1][j] + book[i][j + 1] - book[i + 1][j + 1];
	}
	//for (int i = 1; i <= N; i++) {
		//for (int j = 1; j <= N; j++) printf("%d ", book[i][j]);
		//printf("\n");
	//}
	int ans = 0;
	for (int dx = 1; dx <= N; dx++) { //ö�������Ͻ�dx
		for (int dy = 1; dy <= N; dy++) {//ö�������Ͻ�dy
			for (int dw = 1; dw <= N; dw++) {//ö���¿�
				int dy1 = dy + dw + 1;
				if (dy1 > N || book[dx][dy] - book[dx][dy1 + 1] - book[dx + 1][dy] + book[dx + 1][dy1 + 1]) break;
				for (int dh = 1; dh <= N; dh++) {//ö���¸�
					int dx1 = dx + dh + 1;
					if (dx1 > N || book[dx][dy] - book[dx1 + 1][dy] - book[dx][dy + 1] + book[dx1 + 1][dy + 1]) break;
					if (book[dx][dy1] - book[dx1 + 1][dy1] - book[dx][dy1 + 1] + book[dx1 + 1][dy1 + 1]) continue;
					if (book[dx1][dy] - book[dx1][dy1 + 1] - book[dx1 + 1][dy] + book[dx1 + 1][dy1 + 1]) continue;
					for (int uy = dy; uy <= dy + dw + 1; uy++) {//ö�������½�uy
						for (int uw = 1; uw <= N; uw++) {//ö���Ͽ�
							int uy1 = uy + uw + 1;
							if (uy1 > dy1) break;
							for (int uh = 1; uh <= N; uh++) {//ö���ϸ�
								int ux = dx;
								int ux1 = ux - uh - 1;
								if (ux1 < 1) break;
								if (book[ux1][uy] - book[ux + 1][uy] - book[ux1][uy + 1] + book[ux + 1][uy + 1]) break;
								if (book[ux1][uy] - book[ux1][uy1 + 1] - book[ux1 + 1][uy] + book[ux1 + 1][uy1 + 1]) continue;
								if (book[ux1][uy1] - book[ux + 1][uy1] - book[ux1][uy1 + 1] + book[ux + 1][uy1 + 1]) continue;
								//if (dw * dh * uw * uh > ans) printf("Down:\nx1:%d y1:%d x2:%d y2:%d\nUp:\nx1:%d y1:%d x2:%d y2:%d\n\n", dx, dy, dx1, dy1, ux1, uy, ux, uy1);
								ans = max(ans, dw * dh * uw * uh);
							}
						}
					}
				}
			}
		}
	}
	printf("%d\n", ans);
	return 0;
}
