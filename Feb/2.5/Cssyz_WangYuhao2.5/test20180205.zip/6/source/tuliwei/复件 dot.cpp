#include<bits/stdc++.h>
using namespace std;
struct Lr
{
	int l,r,size;
};
struct Lrr
{
	int l,r,num;
};
bool cmp(Lr o,Lr p)
{
	return o.size < p.size;
}
bool cmp2(Lrr o,Lrr p)
{
	return o.l < p.l;
}
int n,m,l,r,i,j,a,b,l1,r1,t[100005],to[100005],sum,tt,t2[100005],rr;
Lr lr[100005];
Lrr lrr[100005];
int main()
{
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i = 1; i <= m; i++)
	{
		scanf("%d%d",&lr[i].l,&lr[i].r);
		lr[i].size = lr[i].r - lr[i].l + 1;
	}
	sort(lr+1,lr+m+1,cmp);
	for(i = 1; i <= m; i++)
	{
		lrr[i].l = lr[i].l;
		lrr[i].r = lr[i].r;
		lrr[i].num = i;
	}
	sort(lrr+1,lrr+m+1,cmp2);
	for(i = 1; i <= m; i++)
	{
		to[lrr[i].num] = i;
	}
	for(i = 1; i <= m; i++)
	{
		if(t[i] == 1) continue;
		l1 = lr[i].l;
		r1 = lr[i].r;
		tt = 0;
		for(j = l1; j <= r1; j++)
		{
			if(t2[j] == 0 ) tt = 1;
			if(t2[j] == 2 && tt != 1) tt = 2;
		}
		if(tt == 0)
		{
			cout<<-1;
			return 0;
		}
		if(tt == 1)
		{
			for(j = to[i]; j >= 1; j--)
			{
				if(lrr[j].r >= lr[i].r)
				{
					t[lrr[j].num] = 1;
					l1 = min(l1 , lrr[j].l);
					r1 = max(r1 , lrr[j].r);
				}
			}
			for(j = lr[i].l; j<= lr[i].r; j++)
				if(t2[j] == 0)
					t2[j] = 2;
			for(j = l1; j <= r1; j++)
				if(t2[j] == 0)
					t2[j] = 1;
			sum++;
		}
	}
	cout<<sum;
	return 0;
}
