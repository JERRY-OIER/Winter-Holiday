#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<algorithm>
#include<set>
#define maxn 100010
using namespace std;
struct P{
	int l,r,matchl,matchr;
}a[maxn];
bool cmpx(P a,P b)
{
	if(a.l<b.l)  return true;
	else if(a.l>b.l)  return false;
	else{
		if(a.r<b.r)  return true;
		else         return	false;
	}
}
vector<P> g;
vector<P>::iterator it;
int book[maxn];
int n,m;
int ans;
int main()
{	
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	scanf("%d%d",&n,&m);
	ans=m;
	for(int i=1;i<=m;i++)   scanf("%d%d",&a[i].l,&a[i].r);
	sort(a+1,a+m+1,cmpx);
	
	for(int i=m;i>=1;i--)
	{
		for(int j=1;j<=i-1;j++)
		{
			if(a[i].r<=a[j].r)
			{
				if(book[j]==1)
				{
					int p1=a[j].matchl;
					int p2=a[j].matchr;
					if(p1>a[i].r||p2<a[i].l)
					{
						cout<<"-1"<<endl;
						return 0;
					}
					else{
						ans--;
						a[j].matchl=max(a[j].matchl,a[i].l);
						a[j].matchr=min(a[j].matchr,a[i].r);
					}
				}
				else{	
					ans--;
					book[j]=1;
					a[j].matchl=a[i].l;
					a[j].matchr=a[i].r;
				}
			}
		}
	}

	for(int i=1;i<=m;i++)
	{
		for(int j=i+1;j<=m;j++)
		{
			if(a[i].r<=a[j].r&&a[i].l>=a[j].l)
			{
				if(book[j]==1)
				{
					int p1=a[j].matchl;
					int p2=a[j].matchr;
					if(p1>a[i].r||p2<a[i].l)
					{
						cout<<"-1"<<endl;
						return 0;
					}
					else{
						ans--;
						a[j].matchl=max(a[j].matchl,a[i].l);
						a[j].matchr=min(a[j].matchr,a[i].r);
					}
				}
				else{	
					ans--;
					book[j]=1;
					a[j].matchl=a[i].l;
					a[j].matchr=a[i].r;
				}
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
/*
5 3
1 4
2 5
3 4
*/
