#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#define maxn 50010
using namespace std;
struct P{
	int num,time;
}ask[maxn];
int n,k;
int fa[maxn];
int c[maxn],m[maxn];
int ans[maxn];
int cnt[maxn];
int leaf[maxn];
int book[maxn];
int tot,max_time;
queue<int> q;
bool cmp(P a,P b)
{
	return a.time<b.time;
}
bool check()
{
	if(q.size()==1&&q.front()==0)  return true;
	else                           return false;
}
bool judge()
{
	for(int i=2;i<=n;i++)
	{
		if(c[i]>0)  return false;
	}
	return true;
}
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=2;i<=n;i++)
	{
		scanf("%d%d%d",&fa[i],&c[i],&m[i]);
		cnt[fa[i]]++;
	}
	for(int i=1;i<=n;i++)
	{
		if(cnt[i]==0)
		{
			tot++;
			leaf[tot]=i;
		}
	}
	for(int i=1;i<=k;i++)
	{
		scanf("%d",&ask[i].time);
		ask[i].num=i;
		max_time=max(max_time,ask[i].time);
	}
	sort(ask+1,ask+k+1,cmp);
	int poi=1;
	for(int i=1;i<=max_time;i++)
	{
		while(q.size()!=0)   q.pop();
		for(int j=1;j<=tot;j++)  
		{
			q.push(leaf[j]);
			book[leaf[j]]=1;
		}
		memset(book,0,sizeof(book));
		while(check()==false)
		{
			int now=q.front();
			q.pop();
			int x=min(c[now],m[now]);
			c[now]-=x;
			c[fa[now]]+=x;
			if(book[fa[now]]==0)
			{
				book[fa[now]]=1;
				q.push(fa[now]);
			}
			
		}
		if(i==ask[poi].time)
		{
			ans[ask[poi].num]=c[1];
			poi++;
		}
		if(judge()==true)
		{
			for(int j=poi;j<=k;j++)  ans[ask[j].num]=ans[ask[poi-1].num];
			break;
		}
	}
	for(int i=1;i<=k;i++)  printf("%d\n",ans[i]);
	return 0;
}
/*
4 1
1 1 5
2 12 7
3 12 3
5
*/
