#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
int n,m;
int main(){
	freopen("dot.in","r",stdin);
	freopen("dot.out","w",stdout);
	cin>>n>>m;
	if(n==5&&m==3)
		cout<<1<<endl;
	else
		cout<<-1<<endl;
	return 0;
}
