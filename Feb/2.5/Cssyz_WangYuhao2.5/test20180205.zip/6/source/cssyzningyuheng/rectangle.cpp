#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
int n,i,j,k,l,xs[310][310],xd[310][310],zs[310][310],
    xa[310][310],xw[310][310],zw[310][310];
long long ans,a,b;
bool pd[310][310][310];
short yd[310][310][310],yyd[310][310][310];
char s[310][310];
int o(int x,int y,int z){
	int p=min(xs[x][y],xs[x][z])-1,q;
	q=yd[x+p][y][z-y+1];
	if(q>x+1) zs[y][z]=(q-x-1)*(z-y-1);	
}
int p(int x,int y,int z){
	int o=min(xw[x][y],xw[x][z])-1,q;
	q=yyd[x-o][y][z-y+1];
	if(q<x-1) zw[y][z]=(x-q-1)*(z-y-1);
}
int main(){
	freopen("rectangle.in","r",stdin);
	freopen("rectangle.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		scanf("%s",s[i]+1);
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			for(k=j;k<=n;k++)
				if(pd[i][j][k]=='*') pd[i][j][k]=1;
				else pd[i][j][k]=pd[i][j][k-1];
	for(i=0;i<=n+1;i++)
		for(j=0;j<=n+1;j++)
			if(i==0||j==0||i==n+1||j==n+1)
				s[i][j]='*';
	for(i=n;i>=1;i--)
		for(j=1;j<=n;j++)
			if(s[i][j]=='*') xs[i][j]=0;
			else xs[i][j]=xs[i+1][j]+1;
	for(i=1;i<=n;i++)
		for(j=n;j>=1;j--)
			if(s[i][j]=='*') xd[i][j]=0;
			else xd[i][j]=xd[i][j+1]+1;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			if(s[i][j]=='*') xw[i][j]=0;
			else xw[i][j]=xw[i-1][j]+1;
	for(k=1;k<=n;k++)
		for(i=1;i<=n;i++)
			for(j=1;j+k-1<=n;j++)		
				if(xd[i][j]>=k) yd[i][j][k]=i;
				else yd[i][j][k]=yd[i-1][j][k];
	for(j=1;j<=n;j++)
		for(k=1;j+k-1<=n;k++)
			yyd[n+1][j][k]=n+1;
	for(k=1;k<=n;k++)
		for(i=n;i>=1;i--)
			for(j=1;j+k-1<=n;j++)		
				if(xd[i][j]>=k) yyd[i][j][k]=i;
				else yyd[i][j][k]=yyd[i+1][j][k];
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++)
			for(k=j+2;k<=n;k++)
				if(pd[i][j][k]==0)
					o(i,j,k);
		for(j=1;j<=n;j++)
			for(k=j+2;k<=n;k++)
				if(pd[i][j][k]==0)
					p(i,j,k);
		for(k=0;k<=n;k++)
			for(j=1;j+k<=n;j++)		
				zw[j][j+k]=max(max(zw[j+1][j+k],zw[j][j+k-1]),zw[j][j+k]);
		for(j=1;j<=n;j++)
			for(k=j;k<=n;k++){
				a=zw[j][k];
				b=zs[j][k];
				ans=max(ans,a*b);
			}
		for(j=1;j<=n;j++)
			for(k=j;k<=n;k++)
				zw[j][k]=zs[j][k]=0;
	}
	cout<<ans<<endl;
	return 0;
}
