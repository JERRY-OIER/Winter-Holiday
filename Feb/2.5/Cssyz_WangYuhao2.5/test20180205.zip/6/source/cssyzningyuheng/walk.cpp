#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
long long n,k,x,i,j,y,l,c[50002],b[50002],t[50002],top,nex[50002],fir[50002],to[50002],qu[50002];
int lj(long long u,long long v,long long w){
	top++;
	qu[top]=w;
	to[top]=v;
	nex[top]=fir[u];
	fir[u]=top;
}
int ss(int v){
	int top1=fir[v];
	while(top1!=0){
		ss(to[top1]);
		b[v]+=min(qu[top1]*x,b[to[top1]]);
		top1=nex[top1];
	}
}
int main(){
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(i=2;i<=n;i++){
		scanf("%lld%lld%lld",&x,&c[i],&y);
		lj(x,i,y);
	}
	for(i=1;i<=k;i++){
		scanf("%lld",&x);
		for(j=1;j<=n;j++)
			b[j]=c[j];
		ss(1);
		printf("%lld\n",b[1]);
	}
	return 0;
}
