#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
  srand(time(0));
  freopen("bottleneck.10.in", "w", stdout);
  int N = 50000, K = 50000;
  printf("%d %d\n", N, K);
  for (int i = 2; i <= N; ++i) 
    printf("%d %d %d\n", rand() % (i - 1) + 1, rand() % 1000000000, rand() % 100);
  for (int i = 1; i <= K; ++i)
    printf("%d\n", rand() % 100000000 + 1);
  return 0;
}
