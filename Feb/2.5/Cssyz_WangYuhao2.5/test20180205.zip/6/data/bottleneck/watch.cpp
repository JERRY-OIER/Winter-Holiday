#include <cstdio>
#include <string>
using namespace std;

int main() {
  int num;
  scanf("%d", &num);
  for (int i = 1; i <= num; ++i) {
    string S = "bottleneck." + to_string(i) + ".in";
    FILE *f = fopen(S.c_str(), "r");
    int N, K;
    fscanf(f, "%d%d", &N, &K);
    printf("%d %d %d\n", i, N, K);
    fclose(f);
  }
  return 0;
}
