#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
struct P{
	double x1,y1,x2,y2;
}node[100010];
int n;
double k[100010];
double b[100010];
int ans=1;
int main()
{
	freopen("climb.in","r",stdin);
	freopen("climb.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lf%lf%lf%lf",&node[i].x1,&node[i].y1,&node[i].x2,&node[i].y2);
		k[i]=(node[i].x1-node[i].x2)/(node[i].y1-node[i].y2);
		b[i]=node[i].y1-node[i].x1*k[i];		
	}
	int now=1;
	while(true)
	{
		int x=node[now].x2;
		double comp=0;
		int demp;
		int flag=0;
		for(int i=1;i<=n;i++)
		{
			if(i!=now)
			{
				if(k[i]*x+b[i]<node[now].y2&&x>=node[i].x1&&x<=node[i].x2)
				{
					flag=1;
					if(k[i]*x+b[i]>comp)
					{
						ans++;
						demp=i;
						comp=k[i]*x+b[i];
					}
				}
			}
		}
		if(flag==0)  break;
		now=demp;
	}
	cout<<ans<<endl;
	return 0;
}
/*
4
0 0 5 6
1 0 2 1
7 2 8 5
3 0 7 7
*/
