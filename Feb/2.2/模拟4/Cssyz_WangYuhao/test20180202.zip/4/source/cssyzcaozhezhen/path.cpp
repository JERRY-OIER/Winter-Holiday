#include<iostream>
#include<cstdio>
using namespace std;
int n;
int main()
{
	freopen("path.in","r",stdin);
	freopen("path.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
	}
	printf("%d",n+1);
	return 0;
}
