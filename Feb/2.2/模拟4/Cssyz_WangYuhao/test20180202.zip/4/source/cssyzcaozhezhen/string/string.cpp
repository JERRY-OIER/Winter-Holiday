#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n;
char s[2010];
int sum;
char ans[2010];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n;i++)   
	{
		char c[10];
		scanf("%s",c);
		s[i]=c[0];
	}
	int l=0;
	int r=n-1;
	int book=0;
	while(l<=r)
	{
		int x=l;
		int y=r;
		while(s[x]==s[y])
		{
			x++;
			y--;
		}
		if(s[x]<s[y])    book=0;
		else                  	book=1;
		if(s[l]==s[r])
		{
			if(book==0)
			{
				sum++;
				ans[sum]=s[l];
				l++;	
			}
			else{
				sum++;
				ans[sum]=s[r];
				r--;
			}
		}
		else if(s[l]>s[r])
		{
			sum++;
			ans[sum]=s[r];
			r--;
		}
		else{
			sum++;
			ans[sum]=s[l];
			l++;
		}
	}
	for(int i=1;i<=sum;i++)  printf("%c",ans[i]);
	printf("\n");
	return 0;
}
