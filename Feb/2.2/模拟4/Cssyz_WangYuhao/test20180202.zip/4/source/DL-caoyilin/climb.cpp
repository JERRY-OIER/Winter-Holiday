#include<cstdio>
#include<algorithm>
using namespace std;
const int N=1e5+5;
struct point 
{
	int x,y;
	point (){x=0,y=0;}
	inline void read()
	{
		scanf("%d%d",&x,&y);
	}
}now;
struct line
{
	point a,b;
	inline void read()
	{
		a.read(),b.read();
	}
}l[N];
double geth(line a,int x)
{
//	if(a.a.x==a.b.x) return max(a.a.y,a.b.y);
	int X1=a.a.x,Y1=a.a.y,X2=a.b.x,Y2=a.b.y;
	return 1.0*(Y2-Y1)/(X2-X1)*(x-X1)+Y1;
}
int ans=1,n; 
int main()
{
	freopen("climb.in","r",stdin);freopen("climb.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) l[i].read();
	now=l[1].b;
	int nw=1;
	while(1)
	{
	int pos=-1;
	double t=-1;
	for(int i=1;i<=n;i++)
	{
		if(i==nw) continue;
		if(!(l[i].a.x<=now.x&&l[i].b.x>=now.x)) continue;
		double h=geth(l[i],now.x);
		if(h>=(double)now.y) continue;
//		printf("%d:%d-%lf?\n",i,now.x,h,t);
		if(h>t) t=h,pos=i;
	}
	if(pos==-1) break;
	ans++;
	nw=pos;
	now=l[pos].b;
//	printf("->%d",nw);
}
	printf("%d\n",ans);
	return 0;
}
/*
4 
0 0 5 6
1 0 2 1
7 2 8 5
3 0 7 7
4
0 0 4 5
3 3 7 5
3 1 8 5
3 0 7 3
*/ 

