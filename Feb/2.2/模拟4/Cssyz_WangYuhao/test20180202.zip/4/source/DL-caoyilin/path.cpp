#include<cstdio>
#include<algorithm>
using namespace std;
const int N=1e5+5;
const int inf =0x3f3f3f3f;
int n,head[N],ecnt,deg[N];
bool vis[N];
struct edge
{
	int to,next;
}e[N];
inline void add(int u,int v)
{
	e[++ecnt].to=v;e[ecnt].next=head[u];head[u]=ecnt;
}
int dfs(int u,int len,int &sum)
{
//	printf("%d %d %d\n",u,len,sum);
	vis[u]=1;
	if(deg[u]==1) 
	{
	if(len!=-1)return len;
	else return dfs(e[head[u]].to,1,sum);
}
	int l1=len,l2=inf,qcnt=0;
	if(deg[u]==2)
	{
		for(int i=head[u],v;i;i=e[i].next)
		{
			if(vis[v=e[i].to]) continue;
			return dfs(v,len+1,sum);
		}
	}
	else 
	{
		for(int i=head[u],v;i;i=e[i].next)
		{
			if(vis[v=e[i].to]) continue;
			int t=dfs(v,1,sum);
//			if(u==2)	printf("lalala%d %d %d %d\n",v,t,l1,l2);
			if(t==len) qcnt++;
			if(t<l1) 
			{
				if(l2!=inf) sum+=l2*l2;
				l2=l1,l1=t;
			}
			else if(t<l2) 
			{
				if(l2!=inf) sum+=l2*l2;
				l2=t;
			}
			else sum+=t*t;
		}
//		printf("%c%d:%d %d %d\n",1,u,l1,l2,len);
		if((l1==len&&qcnt<2)||(l2==len&&qcnt<1)) return l1+l2;
		sum+=(l1+l2)*(l1+l2);
		sum-=len*len;
		return len;
	}
}
int ans=0;
int main()
{
	freopen("path.in","r",stdin);freopen("path.out","w",stdout);
	scanf("%d",&n);
	for(int i=1,u,v;i<n;i++) 
	{
		scanf("%d %d",&u,&v);
		add(u,v);add(v,u);
		deg[u]++,deg[v]++;
	}
	int q;
	for(int i=1;i<=n;i++)
		if(deg[i]==1)
		{
			q=dfs(i,-1,ans);
			break;
		}
//	printf("%d %d\n",ans,q);
	printf("%d\n",ans+q*q);
	return 0;
}
/*
6
1 2
1 3
1 4
1 5
1 6
9
1 2
1 3
2 4
2 5
5 6
5 7
6 8
6 9
*/
