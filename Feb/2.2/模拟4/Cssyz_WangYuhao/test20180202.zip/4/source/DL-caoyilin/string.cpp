#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<string>
using namespace std;
const int N=3005;
int n,cnt;
char c[N];
void write(int pos)
{
	putchar(c[pos]);
	if((++cnt)%80==0) putchar('\n'),cnt=0;
}
int main()
{
	freopen("string.in","r",stdin);freopen("string.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("\n%c",&c[i]);
	for(int l=1,r=n,ll,rr;;)
	{
		if(l==r) 
		{
		write(l);
		break;
		}
		if(c[l]==c[r])
		{
			ll=l,rr=r;
			while(ll<rr&&c[ll]==c[rr]) ll++,rr--;
			if(c[ll]<c[rr]) write(l++);
			else write(r--);
		}
		else if(c[l]<c[r]) write(l++);
		else write(r--);
	}
	return 0;
}
/*
6
A
C
D
B
C
B
*/
