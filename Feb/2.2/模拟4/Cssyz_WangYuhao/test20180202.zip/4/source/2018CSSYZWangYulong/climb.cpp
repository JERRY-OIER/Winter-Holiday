#include <iostream>
#include <cstdio>
using namespace std;
struct pos {
	double x1,
	   	   y1;
	double x2,
	   	   y2;
	double k, b;
} p[100005];
int n;
int main() {
	freopen("climb.in", "r", stdin);
	freopen("climb.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		scanf("%lf%lf", &p[i].x1, &p[i].y1);
		scanf("%lf%lf", &p[i].x2, &p[i].y2);
		p[i].k = (p[i].y2 - p[i].y1) / (p[i].x2 - p[i].x1);
		p[i].b = p[i].y2 - p[i].k * p[i].x2;
		printf("%lf %lf\n", p[i].k, p[i].b);
 	}
	int ans = 0;
	double nowx = p[1].x2, nowy = p[1].y2;
	while (1) {
		double maxy = 0;
		int maxi = 0;
		for (int i = 1; i <= n; ++i) {
			if (p[i].x1 >  nowx || p[i].x2 <= nowx) continue;
			double tmpy = nowx * p[i].k + p[i].b;
			printf("%lf\n", tmpy);
			if (tmpy > nowy) continue;
			if (maxy < tmpy) {
				maxy = tmpy;
				maxi = i;
			} 
		}
		nowx = p[maxi].x2;
		nowy = p[maxi].y2;
		ans++;
		if (!maxi) break;
	}
	printf("%d", ans);
	
	return 0;
}
