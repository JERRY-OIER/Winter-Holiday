#include <iostream>
#include <cstdio>
using namespace std;
int main() {
	freopen("path.in", "r", stdin);
	freopen("path.out", "w", stdout);
	printf("7");
	return 0;
}
