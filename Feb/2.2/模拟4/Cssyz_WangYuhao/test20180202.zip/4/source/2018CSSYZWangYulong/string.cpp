#include <iostream>
#include <cstdio>
using namespace std;
int len;
char s[4003];
char t[4003]; 
int cnt;
int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &len);
	//scanf("%s", s + 1);
	for (int i = 1; i <= len; ++i) {
		cin >> s[i];
	}
	
	/*for (int i = 1; i <= len; ++i) {
		cout << s[i];
		printf("%c", s[i]);
	}*/
	
	
	int l = 1, r = len, front, back;
	while (l < r) {
		if (s[l] < s[r]) {
			t[++cnt] = s[l++];
			//cout << l - 1 << " \n";
		} else if (s[r] < s[l]) {
			t[++cnt] = s[r--];
			//cout << r + 1<< " \n";//������ȷ 
		} else {
			front = l, back = r;
			while (l < r && s[l + 1] > s[l] && s[l + 1] == s[r - 1]) {
				l++;
				r--;
			}
			for ( ; front <= l - 1; ++front, --back) {
				t[++cnt] = s[front];
				t[++cnt] = s[front];
				//cout << front  << " " << back << " d\n";
			}
			front = l, back = r;
			if (s[l] != s[r]) continue;
			while (l < r && s[l + 1] < s[front] && s[l + 1] == s[r - 1]) {
				l++;
				r--;
			}
			
			
			//������ bug
			if (s[l + 1] == s[r - 1]) {
				int tmpl = l + 1, tmpr = r + 1;
				
				while (tmpl <= r && s[tmpl] == s[tmpr]) {
					tmpl++;
					tmpr--;
				}
				if (tmpl == r || s[tmpl + 1] < s[tmpr - 1]) {
					for ( ; front <= l; ++front) {
						t[++cnt] = s[front];
				//cout << front << " l\n";
					}
					r = back;
					l++;
				} else {
					for ( ; back >= r; --back) {
						t[++cnt] = s[back];
				//cout << back << " r\n";
					}
					l = front;
					r--;
				}
			} else {
				if (s[l + 1] < s[r - 1]) {
					for ( ; front <= l; ++front) {
						t[++cnt] = s[front];
				//cout << front << " l\n";
					}
					r = back;
					l++;
				} else {
					for ( ; back >= r; --back) {
						t[++cnt] = s[back];
				//cout << back << " r\n";
					}
					l = front;
					r--;
				}
			
			}
		}
		if (l == r) {
			t[++cnt] = s[l];
		}
	}
	for (int i = 1; i <= len; ++i) {
		
		printf("%c", t[i]);
		if (i % 80 == 0) printf("\n");
	}
	
	return 0;
} 
