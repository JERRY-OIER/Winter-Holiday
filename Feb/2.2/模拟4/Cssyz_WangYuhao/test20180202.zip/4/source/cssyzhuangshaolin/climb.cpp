#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
struct str{
	int x1,y1,x2,y2;
}rd[100001];
int n,jsq,ans,MAX,adx,ady,nx,ny;
bool mark;
bool cmp(str a,str b)
{return	a.x1<b.x1;}
int main()
{
	freopen("climb.in","r",stdin);
	freopen("climb.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		scanf("%d%d%d%d",&rd[i].x1,&rd[i].y1,&rd[i].x2,&rd[i].y2);	
	sort(rd+1,rd+n+1,cmp);
	nx=rd[1].x2;
	ny=rd[1].y2;
	do
	{
		adx=nx;
		ady=ny;
		ans++;
		mark=false;
		MAX=0;
		for(int i=jsq+1;rd[i].x1<=adx;i++)
		{
			if(rd[i].x2<=adx||rd[i].y1>ady)
			{
				jsq=i;
				continue;
			}	
			if((rd[i].y1+(rd[i].y2-rd[i].y1)*(double)(adx-rd[i].x1)/(rd[i].x2-rd[i].x1))>MAX)
			{
				nx=rd[i].x2;
				ny=rd[i].y2;
				MAX=(rd[i].y2-rd[i].y1)*(double)(adx-rd[i].x1)/(rd[i].x2-rd[i].x1);
				mark=true;
			}
		}
	}while(mark);
	cout<<ans<<endl;
	return 0;
}
