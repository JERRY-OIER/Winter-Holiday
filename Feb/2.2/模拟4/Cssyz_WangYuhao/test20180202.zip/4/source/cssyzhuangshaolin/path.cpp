#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,fir[50001],jsq,tree[50001],sum,ans=0x7fffffff;
struct {
	int to,last;
}line[100001];
bool vis[50001];
void con(int a,int b)
{
	line[++jsq].to=b;
	line[jsq].last=fir[a];
	fir[a]=jsq;
}
int DFS(int x,int from)
{
	int s;
	for(int f=fir[x];f;f=line[f].last)
	{
		if(line[f].to==from)
			continue;
		s=DFS(line[f].to,x);
		if(vis[x])
		{
			if(s+1<tree[x])
			{
				sum+=tree[x]*tree[x];
				tree[x]=s+1;
			}
			else
				sum+=(s+1)*(s+1);
		}	
		else
		{
			vis[x]=true;
			tree[x]=s+1;
		}	
	}	
	return tree[x];
}
int main()
{
	int u,v,sv;
	freopen("path.in","r",stdin);
	freopen("path.out","w",stdout);
	cin>>n;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&u,&v);
		con(u,v);
		con(v,u);
	}
	for(int i=1;i<=n;i++)
	{
		if(!line[fir[i]].last)
		{
			sum=0;
			memset(vis,0,sizeof(vis));
			sv=DFS(i,0);
			sum+=sv*sv;
			ans=min(ans,sum);
		}
	}
	cout<<ans<<endl;
	return 0;
}
