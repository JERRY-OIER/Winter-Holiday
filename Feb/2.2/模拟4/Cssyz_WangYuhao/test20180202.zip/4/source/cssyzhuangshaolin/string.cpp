#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,x,y,mem[2001][2001];
char s[2001];
int search(int a,int b)
{
	if(mem[a][b])
		return mem[a][b];
	if(a>=b||(s[a]>s[x]&&s[b]>s[x])||s[a]<s[b])
			return mem[a][b]=1;
		else
			if(s[a]>s[b])
				return mem[a][b]=2;
			else
				return mem[a][b]=search(a+1,b-1);
}
int main()
{
	int sv;
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	cin>>n;
	y=n-1;
	for(int i=0;i<n;i++)
	{
		do
			scanf("%c",&s[i]);
		while(s[i]<'A'||s[i]>'Z');
	}
	for(int i=1;i<=n;i++)
	{
		if(s[x]<s[y])
			printf("%c",s[x++]);
		else
			if(s[x]>s[y])
				printf("%c",s[y--]);
			else
			{
				sv=search(x+1,y-1);
				if(sv==1)
					printf("%c",s[x++]);
				else
					if(sv==2)
						printf("%c",s[y--]);
			}	
		if(!(i%80))
			printf("\n");
	}
	return 0;
}
