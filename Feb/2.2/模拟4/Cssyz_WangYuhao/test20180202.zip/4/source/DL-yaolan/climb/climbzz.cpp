#include<cstdio>
#include<set>
#include<algorithm>
#define N 100010
using namespace std;
int read();
int n,ans=1,a[N],b[N];
struct hhh
{
	int x1,x2,y1,y2,num;
	hhh() : x1(0),x2(0),y1(0),y2(0),num(0) {}
	hhh(int a,int b,int c,int d) : x1(a),x2(c),y1(b),y2(d),num(0) {}
	bool operator < (const hhh &b) const
	{
		if (b.x1==x1) return y1<=b.y1;
		if (b.x1>x1) return 1.0*(y2-y1)/(x2-x1)<1.0*(b.y1-y1)/(b.x1-x1);
		return 1.0*(b.y2-b.y1)/(b.x2-b.x1)>1.0*(y1-b.y1)/(x1-b.x1);
	}
	void getin()
	{
		x1=read();y1=read();
		x2=read();y2=read();
	}
}x[N];
set <hhh> st;
set <hhh> :: iterator it;

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

double get(hhh x,int i)
{
	return 1.0*(i-x.x1)/(x.x2-x.x1)*(x.y2-x.y1)+x.y1;
}

void solve1()
{
	hhh now=x[1];
	double mx;
	int pos;
	while (1)
	{
		printf("%d\n",now.num);
		mx=-1;
		for (int i=1;i<=n;i++)
			if (x[i].x1<=now.x2 && x[i].x2>now.x2)
			{
				double g=get(x[i],now.x2);
				if (g<=now.y2 && g>mx) mx=g,pos=i;
			}
		if (mx==-1) break;
		ans++;
		now=x[pos];
	}
}

bool cmp1(int i,int j)
{
	if (x[i].x1==x[j].x1) return x[i].y1<x[j].y1;
	return x[i].x1<x[j].x1;
}

bool cmp2(int i,int j)
{
	if (x[i].x2==x[j].x2) return x[i].y2<x[j].y2;
	return x[i].x2<x[j].x2;
}

void solve2()
{
	for (int i=1;i<=n;i++) b[i]=a[i]=i;
	sort(a+1,a+n+1,cmp1);
	sort(b+1,b+n+1,cmp2);
	hhh now=x[a[1]];
	int la=1,lb=1;
	int cnt=1;
	while (1)
	{
		if (++cnt>10) break;
		printf("now: %d\n",now.num);
		//printf("yxd is zz\n");
		printf("%d %d\n",la,lb);
		while (x[a[la]].x1<=now.x2 && la<=n) printf("yjygood %d\n",la),st.insert(x[a[la++]]);
		if (st.empty()) break;
		while (x[b[lb]].x2<=now.x2 && lb<=n) printf("yjysb %d\n",lb),st.erase(x[b[lb++]]);
		if (st.empty()) break;
		printf("sz: %d\n",st.size());
		it=st.lower_bound(hhh(now.x2,now.y2,now.x2,now.y2));
		if (it==st.end()) break;
		//
		printf("%d\n",(*it).num);
		//--it;
		now=*it;
		ans++;
	}
	
}

int main()
{
	//freopen("climb.in","r",stdin);
	//freopen("climb.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++)
		x[i].getin(),x[i].num=i;
	/*
	if (n<=7000)
		solve1();
	else
	*/
		solve2();
	printf("%d\n",ans);
	return 0;
}
/*
4
0 0 5 6
1 0 2 1
7 2 8 5
3 0 7 7
*/
