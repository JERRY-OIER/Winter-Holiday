#include<cstdio>
#include<ctime>
#include<cstdlib>
using namespace std;
int n,a,b;

int main()
{
	freopen("climb.in","w",stdout);
	srand((int)time(0));
	n=5;
	printf("%d\n",n);
	///*
	printf("0 0 ");
	a=rand()%100+1;
	b=rand()%100+1;
	printf("%d %d\n",a,b);
	for (int i=2;i<=n;i++)
	{
		a=rand()%100+1;
		b=rand()%100+1;
		printf("%d %d ",a,b);
		a=rand()%100+a;
		b=rand()%100+b;
		printf("%d %d\n",a,b);
	}
	/*
	for (int i=1;i<=n;i++)
		printf("%d 0 %d %d\n",i-1,i,i);*/
	return 0;
}
