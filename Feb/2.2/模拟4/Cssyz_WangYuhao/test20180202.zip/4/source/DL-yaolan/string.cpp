#include<cstdio>
#define N 2010
using namespace std;
int n,l=1,r;
char a[N],t[N];

int check(int i,int j)
{
	int x=i,y=j;
	while (x<y)
	{
		if (a[x]<a[y]) return i;
		if (a[x]>a[y]) return j;
		x++,y--;
	}
	return i;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	r=n;
	for (int i=1;i<=n;i++) getchar(),a[i]=getchar();
	for (int i=1;i<=n;i++)
	{
		if (a[l]<a[r]) t[i]=a[l++];
		else if (a[l]>a[r]) t[i]=a[r--];
		else 
		{ 
			int now=check(l,r); 
			t[i]=a[now];
			if (now==l) l++;else r--;
		}
	}
	for (int i=1;i<=n;i++) putchar(t[i]);
	return 0;
}
/*
6
A
C
D
B
C
B

6
A
C
D
B
C
A
*/
