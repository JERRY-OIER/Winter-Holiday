#include <vector>
#include <set>
#include <iostream>
#include <cstdio>
#define endl '\n'
using namespace std;

struct poss {
	long long depth;
	long long cost;
	long long takeover;
	bool tcheck;
};

bool operator<(poss a, poss b) {
	if (a.tcheck || b.tcheck) return (a.takeover < b.takeover);
	if (a.depth > b.depth) return true;
	if (a.depth < b.depth) return false;
	return (a.cost < b.cost);
}

int N;
vector<int> edges[50000];
bool visited[50000];
long long depth[50000];
long long offset[50000];
set<poss>* best[50000];

void recurse(int node) {
	visited[node] = true;
	long long bestPair = -1;
	long long allSoFar = 0;
	for (int i = 0; i < edges[node].size(); i++) {
		if (visited[edges[node][i]]) continue;
		depth[edges[node][i]] = depth[node]+1;
		recurse(edges[node][i]);
		
		long long tadd;
		{
			poss when = { 0, 0, -depth[node], true };
			set<poss>::iterator which = best[edges[node][i]]->upper_bound(when);
			which--;
			tadd =
(depth[node]-which->depth)*(depth[node]-which->depth)+which->cost+offset[edges[node][i]];
		}
		if (bestPair != -1) bestPair += tadd;
		
		if (best[node] == NULL) {
			best[node] = best[edges[node][i]];
			offset[node] = offset[edges[node][i]];
		}
		else {
			set<poss>* s = best[node], * t = best[edges[node][i]];
			long long os = offset[node]+tadd, ot = offset[edges[node][i]]+allSoFar;
			if (s->size() < t->size()) {
				set<poss>* tem = s;
				s = t;
				t = tem;
				int to = os;
				os = ot;
				ot = to;
			}
			
			for (set<poss>::iterator it = t->begin(); it != t->end(); it++) {
				poss when = { 0, 0, it->depth-2*depth[node], true };
				set<poss>::iterator which = s->upper_bound(when);
				which--;
				long long thisPair =
(it->depth+which->depth-2*depth[node])*(it->depth+which->depth-2*depth[node])+it->cost+which->cost+offset[node]+offset[edges[node][i]];
				if (bestPair == -1 || thisPair < bestPair) bestPair = thisPair;
			}
			
			for (set<poss>::iterator it = t->begin(); it != t->end(); it++) {
				poss p = *it;
				p.cost += ot-os;
				set<poss>::iterator where = s->insert(p).first;
				bool killed = false;
				while (where != s->begin()) {
					set<poss>::iterator prev = where;
					prev--;
					if (prev->depth == where->depth) {
						s->erase(where);
						killed = true;
						break;
					}
					p.takeover =
(where->cost-prev->cost+where->depth*where->depth-prev->depth*prev->depth)/(2*prev->depth-2*where->depth);
					while ((2*prev->depth-2*where->depth)*p.takeover <
where->cost-prev->cost+where->depth*where->depth-prev->depth*prev->depth)
p.takeover++;
					s->erase(where);
					where = s->insert(p).first;
					
					if (where->takeover <= prev->takeover) s->erase(prev);
					else break;
				}
				if (killed) continue;
				if (where == s->begin()) {
					p.takeover = -1000000000;
					s->erase(where);
					where = s->insert(p).first;
				}
				set<poss>::iterator next = where;
				next++;
				while (next != s->end()) {
					if (next->depth == where->depth) {
						s->erase(next);
						next = where;
						next++;
						continue;
					}
					poss n = *next;
					n.takeover =
(next->cost-where->cost+next->depth*next->depth-where->depth*where->depth)/(2*where->depth-2*next->depth);
					while ((2*where->depth-2*next->depth)*n.takeover <
next->cost-where->cost+next->depth*next->depth-where->depth*where->depth)
n.takeover++;
					if (n.takeover <= where->takeover) {
						s->erase(where);
						break;
					}
					s->erase(next);
					next = s->insert(n).first;
					set<poss>::iterator nnext = next;
					nnext++;
					if (nnext != s->end() && nnext->takeover <=
next->takeover) {
						s->erase(next);
						next = nnext;
					}
					else break;
				}
			}
			
			best[node] = s;
			offset[node] = os;
			delete t;
		}
		allSoFar += tadd;
	}
	
	if (best[node] == NULL) {
		best[node] = new set<poss>();
		poss p = { depth[node], 0, -1000000000, false };
		best[node]->insert(p);
	}
	else if (bestPair != -1) {
		poss p = { depth[node], bestPair-offset[node], 0, false };
		while (!best[node]->empty()) {
			p.takeover =
(p.cost-best[node]->rbegin()->cost+p.depth*p.depth-best[node]->rbegin()->depth*best[node]->rbegin()->depth)/(2*best[node]->rbegin()->depth-2*p.depth);
			while ((2*best[node]->rbegin()->depth-2*p.depth)*p.takeover <
p.cost-best[node]->rbegin()->cost+p.depth*p.depth-best[node]->rbegin()->depth*best[node]->rbegin()->depth)
p.takeover++;
			if (p.takeover > best[node]->rbegin()->takeover) break;
			best[node]->erase(*(best[node]->rbegin()));
		}
		if (best[node]->empty()) p.takeover = -1000000000;
		best[node]->insert(p);
	}
}

int main()
{
  freopen("path.in", "r", stdin);
  freopen("path.out", "w", stdout);
	
	cin >> N;
	for (int i = 0; i < N-1; i++) {
		int a, b;
		cin >> a >> b;
		a--, b--;
		edges[a].push_back(b);
		edges[b].push_back(a);
	}
	
	recurse(0);
	if (edges[0].size() == 1) {
		poss when = { 0, 0, 0, true };
		set<poss>::iterator which = best[0]->upper_bound(when);
		which--;
		cout << which->depth*which->depth+which->cost+offset[0]
<< endl;
	}
	else {
		poss p = *(best[0]->rbegin());
		cout << p.cost+offset[0] << endl;
	}
	return 0;
}
