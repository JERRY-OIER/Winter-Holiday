#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
//#define ivorysi
using namespace std;
typedef long long ll;
int n;
char op[5];
int num[2005],ql,qr,line[2005],tot;
int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
	freopen("f1.out","w",stdout);
#else
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
#endif
	scanf("%d",&n);
	for(int i = 1 ; i <= n ; ++i) {
		scanf("%s",op + 1);
		num[i] = op[1] - 'A' + 1;
	}
	ql = 1,qr = n;

	while(ql < qr) {
		if(num[ql] != num[qr]) {
			if(num[ql] < num[qr]) line[++tot] = num[ql++];
			else line[++tot] = num[qr--];
		}
		else {
			bool flag = 0;
			for(int i = 1 ; i <= n ; ++i) {
				if(ql + i < qr - i && num[ql + i] != num[qr - i]) {
					if(num[ql + i] < num[qr - i]) line[++tot] = num[ql++];
					else line[++tot] = num[qr--];
					flag = 1;
					break;
				}
			}
			if(!flag) {
				line[++tot] = num[ql++];
			}
		}
	}
	line[++tot] = num[ql];
	for(int i = 1 ; i <= tot ; ++i) {
		printf("%c",'A' + line[i] - 1);
		if(i % 80 == 0) puts("");
	}
	if(tot % 80) puts("");
	return 0;
}
