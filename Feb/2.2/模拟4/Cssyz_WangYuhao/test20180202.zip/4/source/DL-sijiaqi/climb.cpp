#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
//#define ivorysi
#define MAXN 100005
using namespace std;
typedef long long ll;
struct Point {
	ll x,y;
	Point() {}
	Point(ll _x,ll _y) {
		x = _x;y = _y;
	}
	friend Point operator + (const Point &a,const Point &b) {
		return Point(a.x + b.x,a.y + b.y);
	}
	friend Point operator - (const Point &a,const Point &b) {
		return Point(a.x - b.x,a.y - b.y);
	}
	friend ll operator * (const Point &a,const Point &b) {
		return a.x * b.y - a.y * b.x;
	}
}now;
struct Seg {
	Point a,b;
	Seg(){}
	Seg(Point _a,Point _b) {
		a = _a;b = _b;
	}
	friend bool operator < (const Seg &lhs,const Seg &rhs) {
		if(lhs.a.x == rhs.a.x) return lhs.a.y > rhs.a.y;
		if(lhs.a.x < rhs.a.x) {
			if((lhs.b - lhs.a) * (rhs.a - lhs.a) <= 0) return 1;
			else return 0;
		}
		else {
			if((rhs.b - rhs.a) * (lhs.a - rhs.a) <= 0) return 0;
			else return 1;
		}
	}
}seg[MAXN];
int n,tot;
int main() {
#ifdef ivorysi
	freopen("f1.in","r",stdin);
#else
	freopen("climb.in","r",stdin);
	freopen("climb.out","w",stdout);
#endif
	ll x[3],y[3];
	scanf("%d",&n);
	for(int i = 1 ; i <= n ; ++i) {
		scanf("%lld%lld%lld%lld",&x[1],&y[1],&x[2],&y[2]);
		seg[i] = Seg(Point(x[1],y[1]),Point(x[2],y[2]));
	}
	sort(seg + 2,seg + n + 1);
	now = seg[1].b;
	int cnt = 1;
	for(int i = 2 ; i <= n ; ++i) {
		if(now.x >= seg[i].a.x && now.x < seg[i].b.x) {
			++cnt;
			now = seg[i].b;
		}
	}
	printf("%d\n",cnt);
	return 0;
}
