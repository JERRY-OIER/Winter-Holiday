#include <bits/stdc++.h>
#define MAX_N 2010
using namespace std;

char s[MAX_N], c;
int N;
char res[MAX_N];
int rsl;

int main () {
  freopen ("string.in", "r", stdin);
  freopen ("string.out", "w", stdout);
  scanf("%d", &N);
  for (int i = 0;i < N; ++i) scanf("%c", &c), scanf("%c", &s[i]);
  int front = 0,rear = N - 1, d = 0;
  while (front <= rear) {
    int l = front, r = rear;
    while (s[l] == s[r] && l <= r) {
      l++, r-- ;
    }
    if (s[l] < s[r]) d = 0;
    else d = 1;
    
    if (s[front] == s[rear]) {
      if (d == 0) res[rsl++] = s[front++];
      else res[rsl++] = s[rear--];
    }
    else if (s[front] > s[rear]) res[rsl++] = s[rear--];
    else res[rsl++] = s[front++];
  }

  for (int i = 0;i < rsl; ++i) printf("%c", res[i]); printf("\n");
  return 0;
}
