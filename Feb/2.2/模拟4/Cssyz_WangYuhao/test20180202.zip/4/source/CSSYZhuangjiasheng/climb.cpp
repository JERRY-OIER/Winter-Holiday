#include <bits/stdc++.h>
#define MAX_N 100010
#define INF 2147483647
using namespace std;
struct point {
  double x, y;
};
struct seg {
  double x1, y1, x2, y2;
  double k, b;
  int id;
  seg() {}
  seg(double xo, double yo, double xt, double yt, int idx) :  x1(xo), y1(yo), x2(xt), y2(yt), id(idx) {
    k = (y1 - y2) / (x1 - x2);
    b = y1 - k * x1;
  }
  bool operator == (const seg& rhs) const {
    return (x1 == rhs.x1 && y1 == rhs.y1 && x2 == rhs.x2 && y2 == rhs.y2);
  }
}x[MAX_N], a[MAX_N];

multiset<seg> stat;
multiset<seg>::iterator it;
int N;
int que[MAX_N], front = 1, rear = 0;
int res = 1;

int find (int u) {
  while (a[que[front]].x2 < x[u].x2 && front <= rear) {  //删除没用的终点，顺便更新一下最小起点
    stat.erase(a[que[front]]);
    ++front;
  }
  if (front == rear) return -INF;  //没有终点比他大的了，肯定会掉下去。
  it = stat.begin();
  if (it -> x1 > x[u].x2) return -INF; //终点比他的的点起点都比他大，肯定会掉下去。
  int ans = -INF;
  double maxx = 0;
  for (it = stat.begin();it != stat.end(); ++it) {  //此时其他点终点都比他大，只需找起点小并且直线交点在终点下面的就行。
    seg now = *it;
    if (now.x1 > x[u].x2) break;
    point jd = (point){x[u].x2, now.k * x[u].x2 + now.b};  //这是终点所在直线与选定直线的交点.
    if (jd.y >= x[u].y2) continue;
    if (jd.x == now.x2 && jd.y == now.y2) continue;
    ans = jd.y > maxx ? now.id : ans;
    maxx = max(maxx, jd.y);
  }
  return ans;
}

void solve () {
  int u = 1;
  while ((u = find(u)) != -INF) 
    res++;
}

bool cmp (const seg a, const seg b) {return a.x2 == b.x2 ? a.y2 < b.y2 : a.x2 < b.x2;} //weihu终点
bool operator < (const seg& a, const seg& b) {return a.x1 == b.x1 ? a.y1 < b.y1 : a.x1 < b.x1;}  //weihu 起点
int main () {
  freopen ("climb.in", "r", stdin);
  freopen ("climb.out", "w", stdout);
  double a_, b, c, d;
  scanf("%d", &N);
  for (int i = 1;i <= N; ++i) {
    scanf("%lf%lf%lf%lf", &a_, &b, &c, &d);
    x[i] = seg(a_, b, c, d, i);
    a[i] = x[i];
  }
  
  for (int i = 1;i <= N; ++i) stat.insert(x[i]);
  sort(a + 1, a + N + 1, cmp);
  for (int i = 1;i <= N; ++i) que[++rear] = i;
  solve();
  printf("%d\n", res);
  return 0;
}
