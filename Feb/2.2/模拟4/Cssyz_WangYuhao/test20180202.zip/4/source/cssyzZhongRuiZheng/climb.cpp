#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std;
int n, book, ans;
struct zrz{
	int x1, y1;
	int x2, y2;
	int pos;
}x[100001];
int aa[100001], bb[100001], cc[100001], dd[100001];

void find() {
	for (int i = 1; i <= n; i++) {
		if (aa[i] == 0 && bb[i] == 0) book = i;
		break;
	}
	return;
}

void solve() {
	while(ans < n) {
		int wz = upper_bound(aa + 1, aa + n + 1, cc[book]) - aa;
		if (wz < 1) break;
		int pd = 0;
		for (int i = 1; i <= wz; i++) {
			if (cc[i] > cc[book]) {
				pd++;
				break;
			}
		}
		if (pd) break;
		int flag = 1;
		for (int i = 2; i <= wz; i++) {
			if (bb[i] < dd[book] && cc[i] > cc[book]) {
				if (bb[i] > bb[flag]) {
					flag = i;
				}
			}
		}
		book = flag;
		ans++;
	}
	return;
}

bool cmp(zrz m, zrz n) {
	return m.x1 < n.x1;
}

void trans() {
	for (int i = 1; i <= n; i++) {
		aa[i] = x[i].x1;
		bb[i] = x[i].y1;
		cc[i] = x[i].x2;
		dd[i] = x[i].y2;
	}
	return;
}

int main() {
	freopen ("climb.in", "r", stdin);
	freopen ("climb.out", "w", stdout);
	cin>>n;
	for (int i = 1; i <= n; i++) {
		scanf ("%d%d%d%d", &x[i].x1, &x[i].y1, &x[i].x2, &x[i].y2);
		x[i].pos = i;
	}
	sort(x + 1, x + n + 1, cmp);
	trans();
	find();
	solve();
	cout<<ans + 1<<endl;
	return 0;
}
