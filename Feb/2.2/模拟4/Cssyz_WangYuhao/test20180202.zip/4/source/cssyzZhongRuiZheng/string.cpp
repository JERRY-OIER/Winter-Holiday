#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
char c[2001];
char ans[2001];
int n, a, b, cnt;

void solve() {
	while (cnt < n) {
		if (c[a] == c[b]) {
			if (c[a + 1] < c[b - 1]) {
				ans[++cnt] = c[a];
				a++;
			}
			else {
				ans[++cnt] = c[b];
				b--;
			}
		}
		else {
			if (c[a] < c[b]) {
				ans[++cnt] = c[a];
				a++;
			}
			else {
				ans[++cnt] = c[b];
				b--;
			}
		}
	}
	return;
}

void print(){
	for (int i = 1; i <= n; i++) {
		printf("%c", ans[i]);
		if (i % 80 == 0) {
			printf("\n");
		}
	}
}

int main() {
	freopen ("string.in", "r", stdin);
	freopen ("string.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf ("\n%c", &c[i]);
	}
	b = n;
	a = 1;
	solve();
	print();
	return 0;
}
