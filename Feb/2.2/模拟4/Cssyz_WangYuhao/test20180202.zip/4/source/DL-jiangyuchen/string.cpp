#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;

int n, l, r;
char a[5010], b[5010];

bool check(int l, int r, char c)
{
	if(l >= r)
	    return 1;
	if(a[l] < a[r])
	    return 1;
	if(a[r] < a[l])
	    return 0;
	if(a[l] == a[r])
	    return check(l + 1, r - 1, c);
}

int main()
{
    freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	char c;
	scanf("%d", &n);
	getchar();
	for(int i = 1; i <= n; i++)
	{
		c = getchar();
		a[i] = c;
		c = getchar();
	}
	l = 1, r = n;
	for(int i = 1; i <= n; i++)
	{
		if(l == r)
		{
			b[i] = a[l];
			break;
		}
		if(a[l] != a[r])
		{
			if(a[l] < a[r])
			{
				b[i] = a[l];
				l++;
			}
			else
			{
				b[i] = a[r];
				r--;
			}
		}
		else
		{
			int get = check(l, r, a[l]);
			if(get == 1)
			{
				b[i] = a[l];
				l++;
			}
			else
			{
				b[i] = a[r];
				r--;
			}
		}
	}
	for(int i = 1; i <= n; i++)
	{
		printf("%c", b[i]);
		if(i % 80 == 0)
		    printf("\n");
	}
	return 0;
}
