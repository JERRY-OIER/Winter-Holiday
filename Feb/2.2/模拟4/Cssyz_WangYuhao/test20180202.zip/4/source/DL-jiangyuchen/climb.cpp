#include <cstdio>
#include <algorithm>
#include <cstring>
#define eps 1e-6
using namespace std;

struct Line{
	long long x1, y1, x2, y2;
}line[100010], yjj[100010];

struct JJ{
	long long k1, k2, b1, b2;
}jj[100010];

long long n, m;

bool cmp(Line x, Line y)
{
	if(x.x1 == y.x1)
	    return x.x2 < y.x2;
	return x.x1 < y.x1;
}

double ffabs(double x)
{
	if(x < 0.0)
	    return -x;
	return x;
}

void calc(long long i)
{
	jj[i].k1 = yjj[i].y2 - yjj[i].y1;
	jj[i].k2 = yjj[i].x2 - yjj[i].x1;
	jj[i].b1 = yjj[i].y2 * jj[i].k2 - jj[i].k1 * yjj[i].x2;
	jj[i].b2 = yjj[i].x2 - yjj[i].x1;
	return;
}

void init()
{
	for(long long i = 1; i <= m; i++)
	    calc(i);
	return;
}

void solve()
{
	long long ans = 1, nowx, nowy, now = 1, l = 1;
	while(now < m)
	{
		nowx = yjj[now].x2;
		nowy = yjj[now].y2;
		while(yjj[l].x2 <= nowx)
		    l++;
		if(yjj[l].x1 > nowx)
		    break;
		ans++;
		long long hy = 1e18, p, ll = l;
		double ny;
		while(yjj[ll].x1 <= nowx && ll <= m)
		{
			ny = 1.0 * jj[ll].k1 * nowx / jj[ll].k2 + 1.0 * jj[ll].b1 / jj[ll].b2;
			if(ny > nowy)
			    continue;
			if(ffabs(ny - (double)nowy) < (double)hy)
		    {
		    	hy = ffabs(ny - (double)nowy);
		    	p = ll;
		    }
		    ll++;
		}
		now = p;
	}
	printf("%lld\n", ans);
	return;
}

int main()
{
	freopen("climb.in", "r", stdin);
	freopen("climb.out", "w", stdout);
	long long x1, y1, x2, y2;
	scanf("%lld", &n);
	for(long long i = 1; i <= n; i++)
	    scanf("%lld %lld %lld %lld", &line[i].x1, &line[i].y1, &line[i].x2, &line[i].y2);
	sort(line + 1, line + 1 + n, cmp);
	for(long long i = 1; i <= n; i++)
	{
		if(line[i].x2 <= yjj[m].x2 && line[i].y2 < yjj[m].y2)
			continue;
		yjj[++m].x1 = line[i].x1;
		yjj[m].y1 = line[i].y1;
		yjj[m].x2 = line[i].x2;
		yjj[m].y2 = line[i].y2;
	}
	init();
	solve();
	return 0;
}
