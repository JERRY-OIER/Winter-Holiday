#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n, cnt, ans = 2147483647;
int head[50010], nxt[100010], edge[100010], sons[50010], dp[50010], fa[50010];

void add(int u, int v)
{
	nxt[++cnt] = head[u];
	head[u] = cnt;
	edge[cnt] = v;
	return;
}

void dfs1(int u)
{
	for(int i = head[u]; i; i = nxt[i])
	{
		int v = edge[i];
		if(v == fa[u])
		    continue;
		sons[u]++;
		fa[v] = u;
		dfs1(v);
	}
	return;
}

void dfs2(int u)
{
	if(!sons[u])
	{
		dp[u] = 0;
		return;
	}
	for(int i = head[u]; i; i = nxt[i])
	{
		int v = edge[i];
		if(v == fa[u])
		   continue;
		dfs2(v);
		dp[u] += dp[v];
	}
	if(sons[u] > 1)
	{
		dp[u] += 4;
		sons[u] -= 2;
	}
	dp[u] += sons[u];
	return;
}

int main()
{
	freopen("path.in", "r", stdin);
	freopen("path.out", "w", stdout);
	int u, v;
	scanf("%d", &n);
	for(int i = 1; i <= n - 1; i++)
	{
		scanf("%d %d", &u, &v);
		add(u, v);
		add(v, u);
	}
	for(int i = 1; i <= n; i++)
	{
		memset(dp, 0, sizeof(dp));
		memset(sons, 0, sizeof(sons));
		memset(fa, 0, sizeof(fa));
		dfs1(i);
		dfs2(i);
		ans = min(ans, dp[i]);
	}
	printf("%d\n", ans);
	return 0;
}
