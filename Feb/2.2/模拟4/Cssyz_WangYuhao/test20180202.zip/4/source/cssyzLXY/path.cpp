#include <bits/stdc++.h>

using namespace std;
const int MAXN = 50000;

int top;
int fi[MAXN + 1];
int ne[MAXN + 1];
int to[MAXN + 1];
int line[MAXN + 1];
bool arrive[MAXN + 1];

void add(int, int);

int main() {
	freopen("path.in", "r", stdin);
	freopen("path.out", "w", stdout);
	int N;
	scanf("%d", &N);
	for (int i = 1; i < N; i++) {
		int u;
		int v;
		scanf("%d%d", &u, &v);
		add(u, v);
		add(v, u);
	}
	int ans = 0;
	for (int i = 1; i <= N; i++) {
		if (line[i] == 1 && !arrive[i]) {
			arrive[i] = true;
			int f = i;
			int useLine = 1;
			for (int j = 1; j <= 3; j++) {
				if (j != 1 && j != 4) line[f] = 1;
				for (int k = fi[f]; k; k = ne[k]) {
					if (!arrive[to[k]]) {
						useLine++;
						arrive[to[k]] = true;
						f = to[k];
						break;
					}
				}
			}
			ans += useLine * useLine;
		}
	}
	printf("%d\n", ans);
	return 0;
}

void add(int u, int v) {
	top++;
	ne[top] = fi[u];
	fi[u] = top;
	line[u]++;
	to[top] = v;
}
