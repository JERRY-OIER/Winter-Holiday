#include <bits/stdc++.h>

using namespace std;
const int MAXN = 2000;

char S[MAXN + 1];

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	int N;
	scanf("%d", &N);
	for (int i = 1; i <= N; i++) {
		char buff[10];
		memset(buff, 0, sizeof(buff));
		scanf("%s", buff);
		S[i] = buff[0];
	}
	int left = 1;
	int right = N;
	int outPut = 0;
	while (left != right) {
		if (S[left] < S[right]) {
			printf("%c", S[left]);
			outPut++;
			left++;
		} else if (S[left] > S[right]) {
			printf("%c", S[right]);
			outPut++;
			right--;
		} else {
			int i = left;
			int j = right;
			while (S[i] == S[j] && i <= j) {
				i++;
				j--;
			}
			if (S[i] < S[j]) {
				printf("%c", S[left]);
				outPut++;
				left++;
			} else {
				printf("%c", S[right]);
				outPut++;
				right--;
			}
		}
		if (outPut == 80) {
			printf("\n");
			outPut = 0;
		}
	}
	printf("%c\n", S[left]);
	return 0;
}
