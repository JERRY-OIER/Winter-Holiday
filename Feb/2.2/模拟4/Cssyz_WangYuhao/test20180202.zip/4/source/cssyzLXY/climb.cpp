#include <bits/stdc++.h>

using namespace std;
const int MAXN = 100000;

struct Node {
	int x;
	int y;
	void input();
};

struct Line {
	Node begin;
	Node end;
	void input();
	double getK();
	double getB();
};

Line line[MAXN + 1];

bool camp(Line, Line);

int main() {
	freopen("climb.in", "r", stdin);
	freopen("climb.out", "w", stdout);
	int N;
	scanf("%d", &N);
	for (int i = 1; i <= N; i++) line[i].input();
	sort(line + 1, line + N + 1, camp);
	Line tl = line[1];
	int ans = 0;
	while (1) {
		ans++;
		double minDiff = -1;
		int minL = 0;
		for (int i = 1; line[i].begin.x <= tl.end.x; i++) {
			if (line[i].end.x <= tl.end.x) continue;
			double k = tl.getK();
			double b = tl.getB();
			double tDiff = tl.end.y - (tl.end.x * k + b);
			if (minDiff == -1 || tDiff < minDiff) {
				minDiff = tDiff;
				minL = i;
			}
		}
		if (minL == 0) break;
		tl = line[minL];
	}
	printf("%d\n", ans);
	return 0;
}

void Node::input() {
	scanf("%d%d", &this->x, &this->y);
}

void Line::input() {
	this->begin.input();
	this->end.input();
}

double Line::getK() {
	int x1 = this->begin.x;int x2 = this->end.x;
	int y1 = this->begin.y;int y2 = this->end.y;
	return (double)(y1 - y2) / (double)(x1 - x2);
}

double Line::getB() {
	double k = this->getK();
	return (double)this->begin.y - this->begin.x * k;
}

bool camp(Line a, Line b) {
	if (a.begin.x == b.begin.x) {
		if (a.end.x == b.end.x) return a.getK() > b.getK();
		return a.end.x < b.end.x;
	}
	return a.begin.x < b.begin.x;
}
