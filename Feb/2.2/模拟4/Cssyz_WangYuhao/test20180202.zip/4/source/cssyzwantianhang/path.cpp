#include<bits/stdc++.h>
using namespace std;
int next[100010];
int to[100010];
int bian[50010];
int p;
void add(int x,int y)
{
	next[++p]=bian[x];
	to[p]=y;
	bian[x]=p;
	return ;
}
bool used[50010];
int ans=0;
int dfs(int x)
{
	used[x]=1;
	int min1=0,min2=0;
	for(int i=bian[x];i;i=next[i])
		if(!used[to[i]])
		{
			int deep=dfs(to[i]);
			if(deep<min1 || !min1) ans+=min2*min2,min2=min1,min1=deep;
			else if(deep<min2 || !min2) min2=deep;
			else ans+=deep*deep;
		}
	if(!min2) return min1+1;
	ans+=(min1+min2)*(min1+min2);
	return 1;
}
int main()
{
	freopen("path.in","r",stdin);
	freopen("path.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n-1;i++)
	{
		int a,b;
		scanf("%d %d",&a,&b);
		add(a,b);
		add(b,a);
	}
	int deep=dfs(1)-1;
	printf("%d\n",ans+deep*deep);
	return 0;
}
