#include<bits/stdc++.h>
using namespace std;
int c;
void print(char x)
{
	c=(c+1)%80;
	printf("%c",x);
	if(!c) printf("\n");
	return ;
}
char s[10001];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++) scanf("\n%c",&s[i]);
	int l=0,r=n-1;
	while(l<r)
	{
//		printf("%d %d %c %c\n",l,r,s[l],s[r]);
		if(s[l]<s[r]) print(s[l]),l++;
		if(s[l]>s[r]) print(s[r]),r--;
//		printf("%d %d\n",l,r);
		if(s[l]==s[r])
		{
			print(s[l]);
			int a=l+1,b=r-1;
			while(a<=b && s[a]==s[b])
			{
//				printf("ab:%d %d",a,b);
				print(s[a]);
				a++;
				b--;
			}
			if(s[a]<s[b] || a>b) print(s[a]),l=a+1;
			if(s[a]>s[b]) print(s[b]),r=b-1;
		}
	}
	if(l==r) print(s[l]);
	return 0;
}

