#include<bits/stdc++.h>
using namespace std;
struct road
{
	int x1;
	int y1;
	int x2;
	int y2;
	void add()
	{
		scanf("%d %d %d %d",&x1,&y1,&x2,&y2);
	}
};
road r[100010];
bool operator < (road x,road y)
{
	return x.x1<y.x1;
}
int main()
{	
	freopen("climb.in","r",stdin);
	freopen("climb.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) r[i].add();
	sort(r+1,r+n+1);
	int ans=1;
	for(int last=1,now=2;now<=n;now++)
		if(r[last].x2<r[now].x2 && r[now].x1<=r[last].x2)
			if((r[last].y1-r[now].y1)*(r[last].x1-r[last].x2)<(r[last].y1-r[last].y2)*(r[last].x1-r[now].x1))
				last=now,ans++;
	printf("%d\n",ans);
	return 0;
}
