#include <bits/stdc++.h>

using namespace std;

const int N = 100000;

struct Node {
	int x, y;
	friend bool operator < (Node a, Node b) {
		if(a.x != b.x) return a.x < b.x;
		return a.y < b.y;
	}
};

struct Line {
	Node l, r;
	int id;
	friend bool operator < (Line a, Line b) {
		return a.r < b.r;
	}
}L[N + 1], INF;

int n;

inline bool cmp(Line a, Line b) {
	return a.l < b.l;
}

inline void read(Node &a) {
	scanf("%d%d", &a.x, &a.y);
}

inline long double js(int x, Line a) {
	if(a.r.x == a.l.x || (a.l.x == a.l.y && !a.l.x && a.id != 1)) return 0;
	long double k = (a.r.y - a.l.y) * 1.000000 / (a.r.x - a.l.x) * 1.000000;
	long double b = a.l.y * 1.000000 - (a.l.x * 1.000000 * k);
	return x * 1.000000 * k + b;
}

int main() {
	freopen("climb.in", "r", stdin);
	freopen("climb.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++) {
		read(L[i].l);
		read(L[i].r);
	}
	sort(L + 1, L + 1 + n, cmp);

	for(int i = 1; i <= n; i++) L[i].id = i;
	set<Line>S;
	set<Line>::iterator it;
	int pos = 1;
	int res = 1;
	int fir = 1;
	INF.r.x = 2e9; INF.r.y = 2e9;
	S.insert(INF);
	INF.r.x *= -1; INF.r.y *= -1;
	S.insert(INF);
	for(int i = 1; i <= n; i++) {
		while(L[pos].r.x <= L[i].l.x) {
			if(L[pos].r.x == L[i].l.x) S.insert(L[i]);
			it = S.lower_bound(L[pos]);
			int choose = 0;
			int x = L[pos].r.x;
			while(it != S.end()) {
				if(js(x, L[choose]) * 1.000000 < js(x, (*it)) * 1.000000)
					if(L[pos].r.y * 1.000000 > js(x, (*it)) * 1.000000)
						choose = (*it).id;
				it++;
			}
			pos = choose;
			if(!pos) {
				printf("%d\n", res);
				return 0;
			}
			res++;
		}
		while(L[fir].r.x < L[pos].r.x || js(L[pos].r.x, L[fir]) > L[pos].r.y * 1.000000) {
			S.erase(L[fir]);
			fir++;
		}
		S.insert(L[i]);
	}
	printf("%d\n", res);
	return 0;
}
