#include <bits/stdc++.h>

using namespace std;

const int N = 2000;

int n;
char S[N + 1];
char T[N + 1];

void print();

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++) cin >> S[i];
	int i = 1;
	int j = n;
	int tot = 0;
	while(i < j) {
		if(S[i] < S[j])		 T[++tot] = S[i], i++;
		else if(S[i] > S[j]) T[++tot] = S[j], j--;
		else {
			int l = i;
			int r = j;
			while(l < r && S[l] == S[r]) l++, r--;
			if(S[l] < S[r]) T[++tot] = S[i], i++;
			else			T[++tot] = S[j], j--;
		}
	}
	T[n] = S[i];
	
	print();
	return 0;
}

void print() {
	int i = 0;
	while(2333) {
		for(int j = i * 80 + 1; j <= n && j % 80; j++) printf("%c", T[j]);
		printf("\n");
		if((++i) * 80 >= n) break;
	}
}
