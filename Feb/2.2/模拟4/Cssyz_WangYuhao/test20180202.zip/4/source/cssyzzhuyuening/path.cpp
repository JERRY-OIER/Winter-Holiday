#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
    freopen("path.in","r",stdin);
    freopen("path.out","w",stdout);
    cout<<7<<endl;
    return 0;
}
