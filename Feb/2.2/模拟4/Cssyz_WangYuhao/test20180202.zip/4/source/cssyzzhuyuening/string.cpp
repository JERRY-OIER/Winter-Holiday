#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,l,r,cnt,cl,cr,tl,tr;
char s[2050],t[2050],ts[100];
/*int work(int a,int b)
{
    int ca=0,cb=0,ta=a;
    while(s[a]==s[b]&&a<b)
    {
        a++,b--;
        ca++;cb++;
    }
    while(s[a]==s[a-1]&&a<b)a++,ca++;
    while(s[b]==s[b+1]&&a<b)b--,cb++;
    if(s[a]>s[b])return 2;
    if(s[a]<s[b])return 1;
    else
    {
        
    }
}*/
int main()
{   
    freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;++i)
        scanf("%s",ts),s[i]=ts[0];//?
    l=1,r=n;
    while(233)
    {//cout<<l<<s[l]<<r<<s[r]<<endl;
        if(s[l]<s[r]||s[l]>s[r]||l==r){
        if(s[l]<s[r])t[++cnt]=s[l],l++;
        else if(s[r]<s[l])
            t[++cnt]=s[r],r--;
        if(l==r){t[++cnt]=s[r];break;}
        continue;}
        cl=cr=0;tl=l;tr=r;
        while(s[l]==s[r]&&l<r)
        {
        r--,l++;
        cr++,cl++;
        }
        while(s[r]==s[r+1]&&r>=l)r--,cr++;
        while(s[l]==s[l-1]&&l<=r)l++,cl++;
        if(l>=r)
        {
            for(int i=tl;i<=tr;++i)t[++cnt]=s[i];
            break;
        }
        if(s[l]==s[r])
        {
            if(s[l]<s[tl])
            {
                if(cl<=cr){
                    for(int i=tl;i<l;++i)t[++cnt]=s[i];r=tr;}
                else if(cl>cr){
                    for(int i=r+1;i<=tr;++i)t[++cnt]=s[i];l=tl;}
            }
            else
            {
                for(int i=tl;i<l;++i)
                    t[++cnt]=s[i];
                for(int i=r+1;i<=tr;++i)
                    t[++cnt]=s[i];
            }
        }
        else if(s[l]<s[r])
        {
            if(s[l]>s[tl])
            {
                for(int i=tl;i<l;++i)
                    t[++cnt]=s[i];
                for(int i=r+1;i<=tr;++i)
                    t[++cnt]=s[i];
            }
            else
            {
                for(int i=tl;i<l;++i)
                    t[++cnt]=s[i];
                r=tr;
            }
        }
        else
        {
            if(s[r]>s[tr])
            {
                for(int i=tl;i<l;++i)
                    t[++cnt]=s[i];
                for(int i=r+1;i<=tr;++i)
                    t[++cnt]=s[i];
            }
            else
            {
                for(int i=r+1;i<=tr;++i)
                t[++cnt]=s[i];
                l=tl;
            }
        }
    }
    //cout<<cnt<<endl;
    for(int i=1;i<=n;++i)
    {   
        printf("%c",t[i]);
        //cout<<t[i];
        if(i%80==0)printf("\n");
    }
    cout<<endl;
    return 0;
}
//cuo wu de tan xin
