#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<set>
using namespace std;
int n,in[100100],hx1=1,hx2=1,ini,ans;
int INF=2e9;
double height;
struct data{
    int x1,y1,x2,y2,id;
    bool operator < (const data& rhs) const{
	    return y1<rhs.y1;}
}p[100100],px2[100100],px1[100100],t1;
bool cmpx1(data a,data b)
{return a.x1<b.x1;}
bool cmpx2(data a,data b)
{return a.x2<b.x2;}
multiset<data> s;
multiset<data>:: iterator it;
void work(data sta)
{
    if(in[sta.id])s.erase(s.find(sta)),ini--;
    ans++;
    //int ns;
    data nxt;
    while(px1[hx1].x1<=sta.x2&&hx1<=n)
    {//cout<<ini<<endl;
        if(px1[hx1].id==sta.id){hx1++;continue;}
        if(!in[px1[hx1].id])
        {
            
            t1=px1[hx1];
            height=(double)t1.y1+(double)(t1.y2-t1.y1)/(double)(t1.x2-t1.x1)
            *(double)(sta.x2-t1.x1);
            //cout<<sta.id<<" "<<" "<<t1.id<<" "<<height<<endl;//
            if(height>=sta.y2){hx1++;continue;}
            s.insert(px1[hx1]);
            ini++;
            in[px1[hx1].id]=1;
        }
        hx1++;
    }
    while(px2[hx2].x2<=sta.x2&&hx2<=n)
    {//cout<<ini<<endl;
        if(px2[hx2].id==sta.id){hx2++;continue;}
        if(in[px2[hx2].id])
        {
            s.erase(s.find(px2[hx2]));
            ini--;
        } 
        in[px2[hx2].id]=1;
        hx2++;
    }//zhe li zhu yi;
   // cout<<ini<<endl;
    if(!ini)return;
   // sta.y1=sta.y2;
    it=s.lower_bound((data){0,INF,0,0,0});
    //cout<<" csc"<<endl;
    nxt=*--it;
    //cout<<nxt.id<<endl;
    if(!nxt.id)return;
    work(nxt);
}
int main()
{
    freopen("climb.in","r",stdin);
    freopen("climb.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;++i)
    {
        scanf("%d%d%d%d",&p[i].x1,&p[i].y1,&p[i].x2,&p[i].y2);
        px1[i].x1=px2[i].x1=p[i].x1;
        px1[i].y1=px2[i].y1=p[i].y1;
        px1[i].x2=px2[i].x2=p[i].x2;
        px1[i].y2=px2[i].y2=p[i].y2;
        px1[i].id=px2[i].id=p[i].id=i;
    }
    sort(px1+1,px1+n+1,cmpx1);
    sort(px2+1,px2+n+1,cmpx2);
    s.insert((data){0,-INF,0,0,0});
    work(p[1]);
    printf("%d\n",ans);
    return 0;
}
