#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<algorithm>
using namespace std;
int n,gen,i,j,k,l,dp[50020],flag[50020],du[50020],top,fir[50020],to[100020],nex[100020],x,y;
int lj(int u,int v){
	top++;
	to[top]=v;
	nex[top]=fir[u];
	fir[u]=top;
}
int ss(int u,int v){
	int top1=fir[v],z=du[v];
	if(v!=gen)
		z--;
	if(z==0) return 0;
	z-=2;
	while(top1!=0){
		if(to[top1]!=u){
			ss(v,to[top1]);
			if(flag[to[top1]]==1)
				z--;
			dp[v]+=dp[to[top1]];
		}
		top1=nex[top1];
	}
	dp[v]+=4;
	if(z<0) flag[v]=1;
	else dp[v]+=z;
	return 0;
}
int main(){
	freopen("path.in","r",stdin);
	freopen("path.out","w",stdout);
	scanf("%d",&n);
	if(n==1) cout<<0<<endl;
	if(n==2) cout<<1<<endl;
	if(n<=2) return 0;
	for(i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		lj(x,y);
		lj(y,x);
		du[x]++;
		du[y]++;
	}
	for(i=1;i<=n;i++)
		if(du[i]>1){
			gen=i;
			break;
		}
	ss(gen,gen);
	cout<<dp[gen]<<endl;
	return 0;
}
