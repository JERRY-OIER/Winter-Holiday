#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<algorithm>
using namespace std;
int n,i,j,k,jsq,flag;
char a[2010];
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		cin>>a[i];
	i=1;j=n;
	while(i<=j){
		flag=0;
		for(k=0;i+k<j-k;k++)
			if(a[i+k]<a[j-k]){
				flag=1;
				break;
			}
			else if(a[i+k]>a[j-k])
				break;
		if(flag==0){
			cout<<a[j];
			jsq++;
			j--;
			if(jsq%80==0)
				cout<<endl;
		}
		else{
			cout<<a[i];
			i++;
			jsq++;
			if(jsq%80==0)
				cout<<endl;
		}
	}
	if(jsq%80!=0)
		cout<<endl;
	return 0;
}
