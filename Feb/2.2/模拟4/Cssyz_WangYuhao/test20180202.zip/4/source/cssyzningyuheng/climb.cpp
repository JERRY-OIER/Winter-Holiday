#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<algorithm>
using namespace std;
long long n,x[100020],y[100020],z[100020],w[100020],nex[100020],i,j,ans;
double k[100020],b[100020],max1[100020];
struct ll{
	long long p,q,r,s;
}o[100020];
bool cmp(ll u,ll v){
	return u.r<v.r;
}
int main(){
	freopen("climb.in","r",stdin);
	freopen("climb.out","w",stdout);
	scanf("%lld",&n);
	for(i=1;i<=n;i++)
		scanf("%lld%lld%lld%lld",&o[i].p,&o[i].q,&o[i].r,&o[i].s);
	sort(o+2,o+n+1,cmp);
	for(i=1;i<=n;i++){
		x[i]=o[i].p;
		y[i]=o[i].q;
		z[i]=o[i].r;
		w[i]=o[i].s;
	}
	for(i=1;i<=n;i++){
		k[i]=((w[i]-y[i])*1.0)/((z[i]-x[i])*1.0);
		b[i]=y[i]*1.0-k[i]*x[i]*1.0;
	}
	for(i=1;i!=0;i=nex[i]){
		ans++;
		for(j=i+1;j<=n;j++)
			if(k[j]*z[i]*1.0+b[j]<w[i]&&k[j]*z[i]*1.0+b[j]>=max1[i]&&z[j]>z[i]&&x[j]<=z[i]){
				max1[i]=k[j]*z[i]*1.0+b[j];
				nex[i]=j;
			}
	}
	cout<<ans<<endl;
	return 0;
}
