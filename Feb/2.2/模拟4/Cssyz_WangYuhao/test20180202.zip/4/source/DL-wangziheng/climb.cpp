#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef double dl;
const int N=1e5+5;
const dl eps=1e-6;
inline int read(){
	int X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
struct node{
	int x,y;
};
struct line{
	node l,r;
}a[N];
bool cmp(line a,line b){
	if(a.r.x==b.r.x)return a.r.y>b.r.y;
	return a.r.x<b.r.x;
}
dl jiao(dl x,line k){
	dl h=(dl)(k.l.y-k.r.y)/(dl)(k.l.x-k.r.x);
	dl b=(dl)k.l.y-(dl)h*k.l.x;
	return h*x+b;
}
bool pan(node a,line k){
	if(a.x<k.l.x||k.r.x<=a.x)return 0;
	dl m=jiao(a.x,k);
	if(eps<m-a.y)return 0;
	return 1;
}
int main(){
	freopen("climb.in","r",stdin);
	freopen("climb.out","w",stdout);
	int n=read();
	for(int i=1;i<=n;i++){
		a[i].l.x=read();a[i].l.y=read();
		a[i].r.x=read();a[i].r.y=read();
	}
	sort(a+1,a+n+1,cmp);
	int now=1,ans=1;
	while(a[now].l.x!=0||a[now].l.y!=0)now++;
	while(233){
		bool flag=1;
		for(int i=now+1;i<=n&&flag;i++){
			if(pan(a[now].r,a[i])){
				now=i;ans++;flag=0;
			}
		}
		if(flag){
			printf("%d\n",ans);
			return 0;
		}
	}
	return 0;
}
