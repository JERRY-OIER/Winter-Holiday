#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int n;
char a[2010],b[2010];
inline void getc(int k){
	char ch=0;
	while(ch<'A'||ch>'Z')ch=getchar();
	a[k]=ch;
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)getc(i);
	int l=1,r=n,t=0;
	while(l<=r){
		if(a[l]<a[r])b[++t]=a[l],l++;
		else b[++t]=a[r],r--;
	}
	for(int i=1;i<=t;i++){
		putchar(b[i]);
		if(i%80==0)putchar('\n');
	}
	return 0;
}
