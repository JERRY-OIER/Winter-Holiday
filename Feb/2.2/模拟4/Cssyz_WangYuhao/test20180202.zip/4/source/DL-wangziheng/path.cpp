#include<cmath>
#include<queue>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int N=5e4+5;
const ll INF=1e18;
inline int read(){
	int X=0,w=1;char ch=0;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')X=(X<<1)+(X<<3)+ch-'0',ch=getchar();
	return X*w;
}
struct node{
	int to,nxt;
}e[N*2];
int cnt,head[N],dep[N];
int c[N][2];
ll dp[N];
void add(int u,int v){
	e[++cnt].to=v;e[cnt].nxt=head[u];head[u]=cnt;
}
void dfs(int u,int f){
	int flag=0,lv;
	ll k=0;
	for(int i=head[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==f)continue;
		dfs(v,u);
		lv=v;
		k+=dp[v];
		flag++;
	}
	if(!flag)dp[u]=1;
	else{
		if(flag==1){
			ll q1=sqrt(dp[c[lv][0]]),q2=sqrt(dp[c[lv][1]]);
			dp[u]=dp[lv]-2*q1*q2-q1*q1-q2*q2+min((q1+1)*(q1+1)+q2*q2,(q2+1)*(q2+1)+q1*q1);
		}
		else{
			dp[u]=INF;
			for(int i=head[u];i;i=e[i].nxt){
				int v1=e[i].to;
				if(v1==f)continue;
				for(int j=head[u];j;j=e[j].nxt){
					int v2=e[j].to;
					if(v2==f||v1==v2)continue;
					ll q1=sqrt(dp[v1]),q2=sqrt(dp[v2]);
					if(dp[u]>k+2*q1*q2){
						dp[u]=k+2*q1*q2;
						c[u][0]=v1;
						c[u][1]=v2;
					}
				}
			}
		}
	}
	return;
}
int main(){
	freopen("path.in","r",stdin);
	freopen("path.out","w",stdout);
	int n=read();
	for(int i=1;i<n;i++){
		int u=read(),v=read();
		add(u,v);add(v,u);
	}
	dfs(1,0);
	printf("%lld\n",dp[1]);
	return 0;
}
