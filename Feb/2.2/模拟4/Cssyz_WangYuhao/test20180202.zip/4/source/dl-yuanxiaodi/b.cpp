#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <set>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;	
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);	
}

const int N = 100005, INF = 0x3f3f3f3f;
int n, lsts[N], lstt[N], nxt[N], stk[N], top;
bool ins[N];
struct point {
	int x, y;
	point(){}
	point(int _x, int _y): x(_x), y(_y){} 
};
struct line {
	int id;
	point s, t;
	line(){}
	line(point _s, point _t): s(_s), t(_t){}
} a[N];
set <line> st;
bool operator < (const point &p, const line &l){
	return (ll)(p.y - l.s.y) * (l.t.x - l.s.x) < (ll)(l.t.y - l.s.y) * (p.x - l.s.x);
}
bool operator < (const line &a, const line &b){
	if(a.s.x == b.s.x) return a.s.y < b.s.y;
	if(a.s.x > b.s.x) return a.s < b;
	else return !(b.s < a);
}
bool cmps(int x, int y){
	return a[x].s.x < a[y].s.x;
}
bool cmpt(int x, int y){
	return a[x].t.x < a[y].t.x;
}

double cross(int x, line l){
	return l.s.y + (l.t.y - l.s.y) * ((double)(x - l.s.x) / (l.t.x - l.s.x));
}
int getnxt(point p){
	double h = -1, ret = 0;
	for(int i = 1; i <= n; i++)
		if(a[i].s.x <= p.x && a[i].t.x > p.x){
			double th = cross(p.x, a[i]);
			if(th < p.y && th > h) h = th, ret = i;
		}
	return ret;
}

int main(){
	
	freopen("climb.in", "r", stdin);
	freopen("climb.out", "w", stdout);
	
	read(n);
	for(int i = 1; i <= n; i++){
		a[i].id = i;
		read(a[i].s.x), read(a[i].s.y), read(a[i].t.x), read(a[i].t.y);
		lsts[i] = lstt[i] = i;
	}
	if(n <= 7000){
		int cnt = 0;
		for(int i = 1; i; i = getnxt(a[i].t))
			cnt++;
		write(cnt), enter;
		return 0;
	}
	sort(lsts + 1, lsts + n + 1, cmps);
	sort(lstt + 1, lstt + n + 1, cmpt);
	for(int ps = 1, pt = 1; ps <= n || pt <= n;){
		int tx = INF;
		if(ps <= n) tx = min(tx, a[lsts[ps]].s.x);
		if(pt <= n) tx = min(tx, a[lstt[pt]].t.x);
		while(pt <= n && a[lstt[pt]].t.x <= tx){
			ins[lstt[pt]] = 0;
			st.erase(a[lstt[pt]]);
			stk[++top] = lstt[pt++];
		}
		while(ps <= n && a[lsts[ps]].s.x <= tx){
			ins[lsts[ps]] = 1;
			st.insert(a[lsts[ps++]]);
		}
		while(top){
			int u = stk[top--];
			set <line> :: iterator it = st.upper_bound(line(a[u].t, a[u].t));
			if(it == st.begin()) continue;
			it--;
			nxt[u] = it -> id;
		}
	}
	int cnt = 0;
	for(int i = 1; i; i = nxt[i]) cnt++;
	write(cnt), enter;
	
	return 0;
}
/*
4
0 0 5 6
1 0 2 1
7 2 8 5
3 0 7 7
*/
