#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <iostream>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;	
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);	
}

const int N = 2005;
int n;
char s[N];

bool judge(int l, int r){
	while(l < r){
		if(s[l] != s[r]) return s[l] < s[r];
		l++, r--;
	}
	return 0;
}

int main(){

	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	
	read(n);
	for(int i = 1; i <= n; i++)
		scanf("%s", s + i);
	for(int l = 1, r = n; l <= r;){
		if(judge(l, r)) putchar(s[l++]);
		else putchar(s[r--]);
	}
	
	return 0;
}
/*
6
A
C
D
B
C
B
*/
