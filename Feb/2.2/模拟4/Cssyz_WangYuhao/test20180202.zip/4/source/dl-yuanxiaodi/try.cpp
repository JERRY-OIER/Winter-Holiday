#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <set>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;	
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);	
}

const int N = 100005, INF = 0x3f3f3f3f;
int n, lsts[N], lstt[N], nxt[N], stk[N], top;
bool ins[N];
struct point {
	int x, y;
	point(){}
	point(int _x, int _y): x(_x), y(_y){} 
};
struct line {
	int id;
	point s, t;
	line(){}
	line(point _s, point _t): s(_s), t(_t){}
} a[N];
set <line> st;
bool operator < (const point &p, const line &l){
	return (ll)(p.y - l.s.y) * (l.t.x - l.s.x) < (ll)(l.t.y - l.s.y) * (p.x - l.s.x);
}
bool operator < (const line &a, const line &b){
	if(a.s.x == b.s.x) return a.s.y < b.s.y;
	if(a.s.x > b.s.x) return a.s < b;
	else return !(b.s < a);
}
bool cmps(int x, int y){
	return a[x].s.x < a[y].s.x;
}
bool cmpt(int x, int y){
	return a[x].t.x < a[y].t.x;
}

int main(){
	
	read(n);
	for(int i = 1; i <= n; i++){
		a[i].id = i;
		read(a[i].s.x), read(a[i].s.y), read(a[i].t.x), read(a[i].t.y);
		lsts[i] = lstt[i] = i;
	}
	st.insert(a[4]);
	line tmp(point(5, 6), point(5, 6));
	set <line> :: iterator it = st.upper_bound(tmp);
	it--;
	printf("it -> id = %d\n", it -> id);
	
	return 0;
}
/*
4
0 0 5 6
1 0 2 1
7 2 8 5
3 0 7 7
*/	
