#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <iostream>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;	
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);	
}

const int N = 100005;
int n, dep[N];
int ecnt, adj[N], nxt[N], go[N];

void add(int u, int v){
	go[++ecnt] = v;
	nxt[ecnt] = adj[u];
	adj[u] = ecnt;
}
void dfs(int u, int pre){
	dep[u] = dep[pre] + 1;
	for(int e = adj[u], v; e; e = nxt[e])
		if((v = go[e]) != pre)
			dfs(v, u);
}

int main(){
	
	freopen("path.in", "r", stdin);
	freopen("path.out", "w", stdout);
	
	read(n);
	for(int i = 1, u, v; i < n; i++)
		read(u), read(v), add(u, v), add(v, u);
	dep[1] = 1;
	dfs(1, 0);
	int root = 0;
	for(int i = 1; i <= n; i++)
		if(dep[i] > dep[root]) root = i;
	dep[root] = 1;
	dfs(root, 0); 
	int mxdep = 0;
	for(int i = 1; i <= n; i++)
		mxdep = max(mxdep, dep[i]);
	if(mxdep == n) write((ll)(n - 1) * (n - 1));
	else write(n - 3 + 4);
	
	return 0;
}
