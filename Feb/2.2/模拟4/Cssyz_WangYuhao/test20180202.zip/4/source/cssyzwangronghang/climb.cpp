#include <bits/stdc++.h>

using namespace std;

int n, xx, yy;

struct road {
    int x1, x2;
    int y1, y2;
}stet[100010];

bool cmp(road a, road b) {
    if(a.x2 == b.x2)
	return a.y2 > b.y2;
    return a.x2 < b.x2;
}

int cut(int lx, int ly, int rx, int ry, int key) {
    if(lx == key)
	return ly;
    if(rx == key)
	return ry;
    if(lx > key || rx < key)
	return -1;
    int midx = (lx + rx) / 2;
    int midy = (ly + ry) / 2;
    if(midx >= key)
	return cut(lx, ly, midx, midy, key);
    if(midx < key)
	return cut(midx, midy, rx, ry, key);
}   

int sch(int x, int y) {
    int ans = -1;
    int numnum = -1;
    for(int i = 1; i <= n; i++) {
	int cutcut = cut(stet[i].x1, stet[i].y1, stet[i].x2, stet[i].y2, x);
	if(cutcut >= 0 && cutcut < y)
	    if(cutcut > ans) {
		ans = cutcut;
		numnum = i;
	    }
    }
    return numnum;
}

int tot = 1;

void work(int x) {
    int result = sch(stet[x].x2, stet[x].y2);
    if(result == -1)
	return;
    tot++;
    work(result);
}

int main() {
    freopen("climb.in", "r", stdin);
    freopen("climb.out", "w", stdout);
    scanf("%d", &n);
    for(int i = 1; i <= n; i++) {
	scanf("%d", &stet[i].x1);
	scanf("%d", &stet[i].y1);
	scanf("%d", &stet[i].x2);
	scanf("%d", &stet[i].y2);
    }
    xx = stet[1].x2, yy = stet[1].y2;
    sort(stet + 1, stet + 1 + n, cmp);
    int book;
    for(int i = 1; i <= n; i++) {
	if(stet[i].x2 == xx && stet[i].y2 == yy) {
	    book = i;
	    break;
	}
    }
    work(book);
    printf("%d\n", tot);
    return 0;
}
