#include<bits/stdc++.h>

using namespace std;

int n;

char s[2018];

char cystr[2018];

int len, bg = 1, ed, hhw;

int main() {
    freopen ("string.in", "r", stdin);
    freopen ("string.out", "w", stdout);
    cin>>n;
    while(len < n) {
	char c = getchar();
	if (c >= 'A' && c <= 'Z')
	    s[++len] = c;
    }
    len = 0;
    ed = n;
    while(bg <= ed) {
	bool bl = true;
	for(int i = bg; i <= ed; i++) {
	    if(s[i] > s[bg + ed - i]) {
		bl = false;
		break;
	    } else if(s[i] < s[bg + ed - i]) {
		bl = true;
		break;
	    }
	} if(bl) {
	    cystr[++len] = s[bg++];
	    hhw++;
	} else {
	    cystr[++len] = s[ed--];
	    hhw++;
	}
    }
    for (int i = 1; i <= n; i++) {
	cout<<cystr[i];
	if(i % 80 == 0)
	    cout<<endl;
    }
    return 0;
}
