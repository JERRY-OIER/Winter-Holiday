#include <bits/stdc++.h>

using namespace std;

int n;

int x[50050];

int y[50050];

bool tree[50050];

int main() {
    freopen("path.in", "r", stdin);
    freopen("path.out", "w", stdout);
    scanf("%d", &n);
    for(int i = 1; i <= n; i++) {
	scanf("%d%d", &x[i], &y[i]);
    }
    printf("%d\n", (n - 1) * (n - 1));
    return 0;
}
