#include<iostream>
#include<cstdio>
using namespace std;
int n,tot;
char s[10101],t;
void js()
{
	tot++;
	if(tot%80==0)printf("\n");
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		cin>>s[i];
	int l=1,r=n;
	while(l<=r)
	{
		if(s[l]<s[r])
			printf("%c",s[l++]),js();
		else if(s[l]>s[r])
			printf("%c",s[r--]),js();
		else
		{
			int f=l,b=r;
			while(f<b&&s[f]==s[b]&&s[f]>=s[f+1]){f++;b--;}
			if(s[f+1]>s[b-1])
				for(;r>=b;r--)
					printf("%c",s[r]),js();
			else 
				for(;l<=f;l++)
					printf("%c",s[l]),js();
		}
	}
	return 0;
}
