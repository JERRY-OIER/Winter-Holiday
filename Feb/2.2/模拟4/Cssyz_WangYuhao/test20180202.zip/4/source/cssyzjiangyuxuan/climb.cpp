#include<iostream>
#include<cstdio>
using namespace std;
int n,ans;
struct d
{
	int x1,y1,x2,y2;
}a[101011];
void dfs(int id)
{
	double k=(a[id].y2-a[id].y1)/(a[id].x2-a[id].x1);
	double b=a[id].y2-k*a[id].x2,may=0;ans++;
	int nd=0;
	for(int i=1;i<=n;i++)
		if(a[i].x1<=a[id].x2&&a[i].x2>a[id].x2)
		{
			if(a[i].x1*k+b<a[i].y1) continue;
			double k1=(a[i].y2-a[i].y1)/(a[i].x2-a[i].x1);
			double b1=a[i].y1-k*a[i].x1;
			if(k1*a[id].x2+b1>may)
			{nd=i;may=k1*a[id].x2+b1;}
		}
	if(nd)
	dfs(nd);
}
int main()
{
	freopen("climb.in","r",stdin);
	freopen("climb.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%d%d%d%d",&a[i].x1,&a[i].y1,&a[i].x2,&a[i].y2);
	dfs(1);
	printf("%d",ans);
	return 0;
}
	
