#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
#define N 2005
char s[N];
int n,l,r,cnt;
bool better(int l,int r)
{
	for (;l<r;l++)
		if (s[l]!=s[r]) return s[l]<s[r];
	return 1;
}
char getC() {char j=getchar();while (j<'A' || j>'Z') j=getchar();return j;}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
		s[i]=getC();
	l=1,r=n;
	for (int i=1;i<=n;i++)
	{
		if (better(l,r)) putchar(s[l]),l++;
		else putchar(s[r]),r--;
		if (i%80==0) putchar('\n');
	}
	return 0;
}
/*
6
A
C
D
B
C
B
*/
