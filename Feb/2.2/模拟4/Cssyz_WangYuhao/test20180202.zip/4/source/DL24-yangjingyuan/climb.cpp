#include<cstdio>
#include<set>
#include<algorithm>
#define N 100010
using namespace std;
int read();
int n,ans=1,q[N];
struct hhh
{
	int x1,x2,y1,y2,num;
	hhh() : x1(0),x2(0),y1(0),y2(0),num(0) {}
	hhh(int a,int b,int c,int d) : x1(a),x2(c),y1(b),y2(d),num(0) {}
	bool operator < (const hhh &b) const
	{
		if (b.x1==x1) return y1<b.y1;
		if (b.x1>x1) return 1.0*(y2-y1)/(x2-x1)<1.0*(b.y1-y1)/(b.x1-x1);
		return 1.0*(b.y2-b.y1)/(b.x2-b.x1)>1.0*(y1-b.y1)/(x1-b.x1);
	}
	void getin()
	{
		x1=read();y1=read();
		x2=read();y2=read();
	}
}a[N],b[N];
set <hhh> st;
set <hhh> :: iterator it;

int read()
{
	int ans=0,fu=1;
	char j=getchar();
	for (;j<'0' || j>'9';j=getchar()) if (j=='-') fu=-1;
	for (;j>='0' && j<='9';j=getchar()) ans*=10,ans+=j-'0';
	return ans*fu;
}

double get(hhh x,int i)
{
	return 1.0*(i-x.x1)/(x.x2-x.x1)*(x.y2-x.y1)+x.y1;
}

void solve1()
{
	hhh now=a[1];
	double mx;
	int pos;
	while (1)
	{
		mx=-1;
		for (int i=1;i<=n;i++)
			if (a[i].x1<=now.x2 && a[i].x2>now.x2)
			{
				double g=get(a[i],now.x2);
				if (g>mx && g<=now.y2) mx=g,pos=i;
			}
		if (mx==-1) break;
		ans++;
		now=a[pos];
	}
}

bool cmp1(hhh i,hhh j)
{
	if (i.x1==j.x1) return i.y1<j.y1;
	return i.x1<j.x1;
}

bool cmp2(hhh i,hhh j)
{
	if (i.x2==j.x2) return i.y2<j.y2;
	return i.x2<j.x2;
}
int main()
{
	freopen("climb.in","r",stdin);
	freopen("climb.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++)
		a[i].getin(),a[i].num=i;
	solve1();
	printf("%d\n",ans);
	return 0;
}
/*
4
0 0 5 6
1 0 2 1
7 2 8 5
3 0 7 7
*/
