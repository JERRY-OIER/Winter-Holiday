#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 50005
using namespace std;
int n;
int main()
{
	freopen("path.in","r",stdin);
	freopen("path.out","w",stdout);
	scanf("%d",&n);
	printf("%d",n+1);
	return 0;
}
